<!DOCTYPE html>
<?php if (!defined('BASEPATH')) exit('No direct script access allowed');?>
<!-- 부트스트렙 사용시 위 독타입 필수 -->
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta name="keywords" content="<?php echo $site_keywords?>"/>
<meta name="description" content="<?php echo $site_description?>"/>
<html>
<head>
<title><?php echo $site_title?></title>
<!-- Bootstrap -->
<link href="<?php echo base_url()?>include/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
<!-- 반응형 네비게이션바 -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="<?php echo base_url()?>include/bootstrap/css/bootstrap-responsive.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>include/css/main.css" media="screen"/>
<script type="text/javascript"  src="<?php echo base_url()?>include/js/jquery.popup.js"></script>

</head>
<body>

<?php
	$this->db->where('popup_place', $_SERVER["REQUEST_URI"]);
	$this->db->where('popup_hidden', 1);
	$query = $this->db->get('popup');
	if ($query->num_rows() > 0)
	{
		$data = $query->row_array();

		$current_time = date("YmdHi",time());

		if($data['popup_term'] == 1 OR $data['popup_term'] == 0 && $current_time > $data['popup_start_date'] && $current_time < $data['popup_end_date'])
		{
			foreach($query->result_array() as $data)
			{
				echo 
				("
				<script type='text/javascript'>
				<!--
				var opts = {
				'url'    : './admin/popup/read/id/popup/page/1/no/{$data['popup_no']}' ,
				'type'   : '{$data['popup_type']}'   , //옵션 layer || browser
				'name'   : '{$data['popup_no']}' ,
				'width'  : '{$data['popup_size_width']}' ,
				'height' : '{$data['popup_size_height']}' ,
				'scrollbars' : '{$data['popup_scroll']}' ,
				'toolbar' : 'no'    ,
				'menubars' : 'no'   ,
				'locationbar' : 'no'  ,
				'statusbar'   : 'no'  ,
				'resizable'   : 'no' ,
				'titlebar'    : 'no'  ,
				'left'    : '{$data['popup_position_left']}'  ,
				'top'     : '{$data['popup_position_top']}'  ,
				'message' : '팝업차단을 해제해주세요.'  ,
				'center'  : false //true OR  false - 레이어적용시 false로 해야함
				};
				var p{$data['popup_no']} =  $.popup(opts);
				//-->
				</script>
				");
			}
		}
	}
?>

			<div class="container">
				<div class="row-fluid">
					<div class="span12">
						<div align=right>
	<?php if( $this->session->userdata('user_id') ) 
{
						// echo anchor('auth/unregister', '회원탈퇴', 'title="회원탈퇴"');?>&nbsp;&nbsp;
						<!-- 회원 케릭터 출력 -->
<?php
								$atts = array(
									'width'      => '630',
									'height'     => '550',
									'scrollbars' => 'yes',
									'status'     => 'yes',
									'resizable'  => 'yes',
									'screenx'    => '0',
									'screeny'    => '0'
								);
								echo anchor_popup('./memo/receive_list/id/memo/page/1', '쪽지', $atts);
?>
<?php if($this->session->userdata('file1')){?>
						<img src = "<?php echo base_url()?>file/users/<?php echo $this->session->userdata('file1')?>" width="15" height="15" border="0" >
<?php }else{?>
						<i class="icon-user"></i>
<?php }?>     
<?php echo $this->session->userdata('nickname')?>님 (<?php echo $this->session->userdata('level') ?>레벨) 환영합니다. 
						<a href ="<?php echo base_url()?>auth/modify"  class="btn btn-mini"><i class="icon-pencil"></i>회원정보수정</a>&nbsp;	
							<a href ="<?php echo base_url()?>auth/unregister"  class="btn btn-mini"><i class="icon-ban-circle"></i>회원탈퇴</a>&nbsp;
						<a href = "<?php echo base_url()?>auth/logout/"  class="btn btn-mini"><i class="icon-share"></i>로그아웃</a>&nbsp;
<?php
}else{?>&nbsp;
						<a href ="<?php echo base_url()?>auth/register1"  class="btn btn-mini"><i class="icon-pencil"></i>회원가입</a>&nbsp;
						<a href ="<?php echo base_url()?>/auth/forgot_password/"  class="btn btn-mini"><i class="icon-wrench"></i>비밀번호찾기</a>&nbsp;
						<a href ="<?php echo base_url()?>auth/login"  class="btn btn-mini"><i class="icon-check"></i>로그인</a>&nbsp;<?php
}
						if($this->session->userdata('level')==10){?>
							<a href ="<?php echo base_url()?>board/index/id/manual/page/1" class="btn btn-mini"><i class="icon-book"></i>매뉴얼</a>&nbsp;
							<a class="btn btn-info btn-mini" href ="<?php echo base_url()?>admin/site_config/index/"><i class="icon-cog  icon-white"></i>관리자</a>

<?php }?>
						</div>
					</div>
				</div>
			</div>

			<div class="container">
				<div class="row-fluid">
					<div class="span12">
						<div class="navbar navbar-inner">
							<div class="container">
								<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
								</a>
					<!-- 관리자/사이트관리/로고-->
					<a class="brand" href="<?php echo base_url()?>">
					<img src="<?php echo base_url()?>file/site_logo/<?php echo $site_logo?>" width="30">
					</a>

					<div class="nav-collapse collapse">
						<ul class="nav pull-right">
<?php		//상단 content 메뉴 출력
			$this->db->order_by('con_sequence desc');//메뉴출력순서
			$this->db->where('con_place', "main_top");//메뉴출력위치
			$this->db->where('con_use', 1);//메뉴출력여부
			$query = $this->db->get('contents');
			foreach ($query->result() as $row){?>
				<li class="dropdown">
				<a href="<?php echo base_url()?>admin/contents/read/id/contents/page/1/no/<?php echo $row->no?>"><?php echo $row->con_name?></a>
<!-- 서브메뉴 연구중 class="dropdown-toggle" data-toggle="dropdown"
 <ul class="dropdown-menu">
<li><a href="<?php echo base_url()?>admin/contents/read/id/contents/page/1/no/<?php echo $row->no?>"><?php echo $row->con_name?></a></li>
</ul>
 -->
				</li>
<?php }?>
<?php			//상단 게시판 메뉴 출력
				$this->db->order_by('board_sequence desc');//메뉴출력순서
				$this->db->where('board_place', "main_top");//메뉴출력위치
				$this->db->where('board_use', 1);//메뉴출력여부
				$query = $this->db->get('board_admin');
				foreach ($query->result() as $row){?>
				<li class="dropdown">
				<a href="<?php echo base_url()?>board/index/id/<?php echo $row->id?>/page/1" > <?php echo $row->board_title?></a>
				</li>
<?php }?>
		</ul>
					</div>
				</div>
			</div>
<div class="container">
	<div class="row-fluid">
<?php		//디렉토리안 이미지들 읽어와 배열에 넣어 랜덤 출력
				$top_images = directory_map("./images/sub_top/",1);
				shuffle($top_images);
				for ($i = 0; $i < 2; $i++) {?>
					<div class="span6">
						<img hspace=0 border=0 src="<?php echo base_url()?>images/sub_top/<?php echo $top_images[$i]?>">
					</div>
<?php }?>
	</div>
</div>

			<div class="container">
				<div class="row-fluid">
					<div class="span3">
						<ul class="nav nav-tabs nav-stacked">
							<br>
<?php						//좌측 게시판 메뉴 출력
							$this->db->order_by('board_sequence desc');//메뉴출력순서
							$this->db->where('board_place', "main_left");//메뉴출력위치
							$this->db->where('board_use', 1);//메뉴출력여부
							$query = $this->db->get('board_admin');
							foreach ($query->result() as $row){?>
							<li>
							<a href=<?php echo base_url()?>board/index/id/<?php echo $row->id?>/page/1> 

							<?php echo $row->board_title?>
							</a>

							</li>
<?php }?>

<?php							//좌측 content 메뉴 출력
								$this->db->order_by('con_sequence desc');//메뉴출력순서
								$this->db->where('con_place', "main_left");//메뉴출력위치
								$this->db->where('con_use', 1);//메뉴출력여부
								$query = $this->db->get('contents');
								 foreach ($query->result() as $row){?>
									<li><a href="<?php echo base_url()?>admin/contents/read/id/contents/page/1/no/<?php echo $row->no?>"><?php echo $row->con_name?></a></li>
<?php }?>
							</ul>

<?php			//베너 출력-베너 카운트 위해서 controllers로 링크후 redirect
						$this->db->order_by('banner_sequence desc');//출력순서
						$this->db->where('banner_place', "main_left");//베너위치
						$this->db->where('banner_use', 1);//사용여부
						$query = $this->db->get('banner');
						foreach ($query->result() as $row){?>
							<a href=<?php echo base_url()?>admin/banner/read/id/banner/no/<?php echo $row->banner_num?>/ target=<?php echo $row->banner_target?>>
							<img src=<?php echo base_url()?>file/banner/<?php echo $row->banner_image?> width=<?php echo $row->banner_width?> height=<?php echo $row->banner_height?>></a><br>
<?php }?>
		</div>

<?php			//상단html
				if(isset($this->head_image)){ ?>
					<div class="span9">
						<img src=<?php echo base_url()?>file/<?php echo $this->head_image?>><br>
<?php echo $this->head?>
					</div>
<?php }?>