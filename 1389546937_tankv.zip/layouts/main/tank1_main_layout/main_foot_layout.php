<?php if (!defined('BASEPATH')) exit('No direct script access allowed');?>

	<div class="row-fluid">
		<div class="span12">
<?php
//하단 html 
if(isset($this->foot))
{
	echo  $this->foot;
}
?>
		</div>
	</div>

		<div class="row-fluid">
			<div class="span12">
				<ul class="breadcrumb">
<?php			//하단 메뉴 출력
				$this->db->order_by('con_sequence desc');//메뉴출력순서
				$this->db->where('con_place', "main_foot");//메뉴출력위치
				$this->db->where('con_use', 1);//메뉴출력여부
				$query = $this->db->get('contents');
				foreach ($query->result() as $row){?>
					<li><a href="<?php echo base_url()?>admin/contents/read/id/contents/page/1/no/<?php echo $row->no?>"><?php echo $row->con_name?></a><span class="divider">|</span></li>
<?php }?>
<?php			//게시판 하단 메뉴 출력
				$this->db->order_by('board_sequence desc');//메뉴출력순서
				$this->db->where('board_place', "main_foot");//메뉴출력위치
				$this->db->where('board_use', 1);//메뉴출력여부
				$query = $this->db->get('board_admin');
				foreach ($query->result() as $row){?>
					<li><a href="<?php echo base_url()?>board/index/id/<?php echo $row->id?>/page/1"> <?php echo $row->board_title?></a><span class="divider">|</span></li>
<?php }?>
<div align=right>
<li><img src="<?php echo base_url()?>images/browser_logos.png" width="280" height="52" border="0" alt="">
</div>
				</ul>
			</div>
		</div>
<?php echo $site_copyright; ?>
<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<script src="<?php echo base_url()?>include/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>