<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-06-09 00:00:55 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:01:04 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\send_list_view.php 46
ERROR - 2013-06-09 00:01:05 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:01:28 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:01:31 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:01:32 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:01:33 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:01:34 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:01:35 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:01:35 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:01:36 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:01:37 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:01:37 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:01:38 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:01:39 --> Severity: Notice  --> Undefined index: memo_receive_date C:\AutoSet6\public_html\tankv\application\models\memo_model.php 69
ERROR - 2013-06-09 00:01:39 --> Severity: Notice  --> Undefined index: memo_receive_id C:\AutoSet6\public_html\tankv\application\models\memo_model.php 69
ERROR - 2013-06-09 00:01:39 --> Severity: Notice  --> Undefined index: memo_send_id C:\AutoSet6\public_html\tankv\application\controllers\memo.php 204
ERROR - 2013-06-09 00:01:39 --> Severity: Notice  --> Undefined index: memo_receive_id C:\AutoSet6\public_html\tankv\application\controllers\memo.php 204
ERROR - 2013-06-09 00:01:39 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:01:41 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:01:42 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:01:42 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:01:43 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:01:44 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:01:45 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:01:46 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:01:47 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:01:47 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:01:48 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:01:49 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:01:51 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:01:53 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:02:04 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:02:18 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:02:20 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:02:22 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\send_list_view.php 46
ERROR - 2013-06-09 00:02:22 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 00:02:23 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\send_list_view.php 46
ERROR - 2013-06-09 00:03:12 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 00:03:12 --> Severity: Notice  --> Undefined index: ip_address C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 00:03:12 --> Severity: Notice  --> Undefined index: user_agent C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 00:03:12 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 00:03:12 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 288
ERROR - 2013-06-09 00:03:12 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 289
ERROR - 2013-06-09 00:03:23 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 00:03:40 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 00:03:40 --> Severity: Notice  --> Undefined index: ip_address C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 00:03:40 --> Severity: Notice  --> Undefined index: user_agent C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 00:03:40 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 00:03:40 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 288
ERROR - 2013-06-09 00:03:40 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 289
ERROR - 2013-06-09 00:04:04 --> Severity: Warning  --> fopen(/dev/urandom): failed to open stream: No such file or directory C:\AutoSet6\public_html\tankv\phpass-0.1\PasswordHash.php 49
ERROR - 2013-06-09 00:04:04 --> Query error: Incorrect integer value: '' for column 're_mobile' at row 1
ERROR - 2013-06-09 00:08:21 --> Severity: Warning  --> fopen(/dev/urandom): failed to open stream: No such file or directory C:\AutoSet6\public_html\tankv\phpass-0.1\PasswordHash.php 49
ERROR - 2013-06-09 00:08:21 --> Query error: Data truncated for column 're_mobile' at row 1
ERROR - 2013-06-09 00:10:25 --> Severity: Warning  --> fopen(/dev/urandom): failed to open stream: No such file or directory C:\AutoSet6\public_html\tankv\phpass-0.1\PasswordHash.php 49
ERROR - 2013-06-09 00:12:46 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 00:12:46 --> Severity: Notice  --> Undefined index: ip_address C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 00:12:46 --> Severity: Notice  --> Undefined index: user_agent C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 00:12:46 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 00:12:46 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 288
ERROR - 2013-06-09 00:12:46 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 289
ERROR - 2013-06-09 00:21:53 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\bootstrap\list_skin.php 46
ERROR - 2013-06-09 00:29:04 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 00:30:39 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\bootstrap\list_skin.php 46
ERROR - 2013-06-09 00:30:42 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 00:30:56 --> Severity: Notice  --> Undefined variable: board_skin C:\AutoSet6\public_html\tankv\application\views\admin\board_write_form_view.php 35
ERROR - 2013-06-09 00:30:57 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 00:32:49 --> Severity: Notice  --> Undefined variable: board_skin C:\AutoSet6\public_html\tankv\application\views\admin\board_write_form_view.php 35
ERROR - 2013-06-09 00:32:50 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 00:32:51 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 00:32:52 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\bootstrap\list_skin.php 46
ERROR - 2013-06-09 00:33:55 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 00:33:55 --> Severity: Notice  --> Undefined index: ip_address C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 00:33:55 --> Severity: Notice  --> Undefined index: user_agent C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 00:33:55 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 00:33:55 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 288
ERROR - 2013-06-09 00:33:55 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 289
ERROR - 2013-06-09 00:42:18 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 01:13:34 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 01:13:45 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 01:13:47 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\bootstrap\list_skin.php 46
ERROR - 2013-06-09 01:16:38 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 01:16:40 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 01:17:33 --> Severity: Warning  --> unlink(./file/memo/memo/): Permission denied C:\AutoSet6\public_html\tankv\include\upload\upload.php 17
ERROR - 2013-06-09 01:17:33 --> Severity: Notice  --> Undefined property: Memo::$admin_mail_receive C:\AutoSet6\public_html\tankv\application\controllers\memo.php 141
ERROR - 2013-06-09 01:17:33 --> Severity: Notice  --> Undefined property: Memo::$board_mobile_receive C:\AutoSet6\public_html\tankv\application\controllers\memo.php 147
ERROR - 2013-06-09 01:17:33 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\send_list_view.php 46
ERROR - 2013-06-09 01:26:06 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\send_list_view.php 46
ERROR - 2013-06-09 01:26:22 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 01:26:22 --> Severity: Notice  --> Undefined index: ip_address C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 01:26:22 --> Severity: Notice  --> Undefined index: user_agent C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 01:26:22 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 01:26:22 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 288
ERROR - 2013-06-09 01:26:22 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 289
ERROR - 2013-06-09 01:26:32 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 01:26:33 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 01:26:33 --> Severity: Notice  --> Undefined index: ip_address C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 01:26:33 --> Severity: Notice  --> Undefined index: user_agent C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 01:26:33 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 01:26:33 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 288
ERROR - 2013-06-09 01:26:33 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 289
ERROR - 2013-06-09 01:26:44 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 01:26:48 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 01:29:09 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 01:29:10 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 01:29:34 --> Severity: Warning  --> mkdir(): File exists C:\AutoSet6\public_html\tankv\application\models\memo_model.php 90
ERROR - 2013-06-09 01:29:34 --> Severity: Warning  --> unlink(./file/memo/files/): Permission denied C:\AutoSet6\public_html\tankv\include\upload\upload.php 24
ERROR - 2013-06-09 01:29:34 --> Severity: Notice  --> Undefined property: Memo::$admin_mail_receive C:\AutoSet6\public_html\tankv\application\controllers\memo.php 141
ERROR - 2013-06-09 01:29:34 --> Severity: Notice  --> Undefined property: Memo::$board_mobile_receive C:\AutoSet6\public_html\tankv\application\controllers\memo.php 147
ERROR - 2013-06-09 01:29:34 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\send_list_view.php 46
ERROR - 2013-06-09 01:29:52 --> Severity: Warning  --> file_get_contents(./file/memo/memo/1370708974_11.png): failed to open stream: No such file or directory C:\AutoSet6\public_html\tankv\application\controllers\memo.php 180
ERROR - 2013-06-09 01:30:31 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 01:30:34 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 01:30:35 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\send_list_view.php 46
ERROR - 2013-06-09 01:31:30 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\send_list_view.php 46
ERROR - 2013-06-09 01:31:35 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 01:31:35 --> Severity: Notice  --> Undefined index: ip_address C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 01:31:35 --> Severity: Notice  --> Undefined index: user_agent C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 01:31:35 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 01:31:35 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 288
ERROR - 2013-06-09 01:31:35 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 289
ERROR - 2013-06-09 01:31:47 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 01:31:52 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 01:33:02 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 01:33:02 --> Severity: Notice  --> Undefined index: ip_address C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 01:33:02 --> Severity: Notice  --> Undefined index: user_agent C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 01:33:02 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 01:33:02 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 288
ERROR - 2013-06-09 01:33:02 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 289
ERROR - 2013-06-09 01:33:24 --> Severity: Notice  --> Use of undefined constant PHPASS_HASH_STRENGTH - assumed 'PHPASS_HASH_STRENGTH' C:\AutoSet6\public_html\tankv\application\controllers\auth.php 438
ERROR - 2013-06-09 01:33:24 --> Severity: Notice  --> Use of undefined constant PHPASS_HASH_PORTABLE - assumed 'PHPASS_HASH_PORTABLE' C:\AutoSet6\public_html\tankv\application\controllers\auth.php 438
ERROR - 2013-06-09 01:33:24 --> Severity: Warning  --> fopen(/dev/urandom): failed to open stream: No such file or directory C:\AutoSet6\public_html\tankv\phpass-0.1\PasswordHash.php 49
ERROR - 2013-06-09 01:33:24 --> Severity: Warning  --> unlink(./file/users/): Permission denied C:\AutoSet6\public_html\tankv\include\upload\upload.php 24
ERROR - 2013-06-09 01:33:39 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 01:33:39 --> Severity: Notice  --> Undefined index: ip_address C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 01:33:39 --> Severity: Notice  --> Undefined index: user_agent C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 01:33:39 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 01:33:39 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 288
ERROR - 2013-06-09 01:33:39 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 289
ERROR - 2013-06-09 01:53:25 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 01:53:25 --> Severity: Notice  --> Undefined index: ip_address C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 01:53:25 --> Severity: Notice  --> Undefined index: user_agent C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 01:53:25 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-09 01:53:25 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 288
ERROR - 2013-06-09 01:53:25 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 289
ERROR - 2013-06-09 01:53:42 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 01:53:44 --> Severity: Notice  --> Undefined index: $users_email_activation C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 22
ERROR - 2013-06-09 01:53:44 --> Severity: Notice  --> Undefined variable: users_register1 C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 93
ERROR - 2013-06-09 01:53:44 --> Severity: Notice  --> Undefined variable: users_register2 C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 97
ERROR - 2013-06-09 01:53:47 --> Severity: Notice  --> Undefined variable: activated C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 63
ERROR - 2013-06-09 01:53:47 --> Severity: Notice  --> Undefined variable: banned C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 71
ERROR - 2013-06-09 01:53:47 --> Severity: Notice  --> Undefined variable: users_out C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 79
ERROR - 2013-06-09 01:53:47 --> Severity: Notice  --> Undefined variable: level C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 95
ERROR - 2013-06-09 01:53:47 --> Severity: Notice  --> Undefined variable: address1 C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 119
ERROR - 2013-06-09 01:53:47 --> Severity: Notice  --> Undefined variable: sex C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 127
ERROR - 2013-06-09 01:53:47 --> Severity: Notice  --> Undefined variable: created C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 130
ERROR - 2013-06-09 01:53:47 --> Severity: Notice  --> Undefined variable: birthday C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 133
ERROR - 2013-06-09 01:54:29 --> Severity: Notice  --> Undefined variable: activated C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 63
ERROR - 2013-06-09 01:54:29 --> Severity: Notice  --> Undefined variable: banned C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 71
ERROR - 2013-06-09 01:54:29 --> Severity: Notice  --> Undefined variable: users_out C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 79
ERROR - 2013-06-09 01:54:29 --> Severity: Notice  --> Undefined variable: level C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 95
ERROR - 2013-06-09 01:54:29 --> Severity: Notice  --> Undefined variable: address1 C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 119
ERROR - 2013-06-09 01:54:29 --> Severity: Notice  --> Undefined variable: sex C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 127
ERROR - 2013-06-09 01:54:29 --> Severity: Notice  --> Undefined variable: created C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 130
ERROR - 2013-06-09 01:54:29 --> Severity: Notice  --> Undefined variable: birthday C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 133
ERROR - 2013-06-09 01:59:54 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 02:02:55 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 02:03:12 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 02:05:27 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 02:09:03 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 02:09:21 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 02:09:31 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 02:12:39 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 02:12:49 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 02:13:16 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 02:21:40 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 02:22:17 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 02:32:33 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\bootstrap\list_skin.php 46
ERROR - 2013-06-09 02:34:44 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\bootstrap\list_skin.php 46
ERROR - 2013-06-09 02:34:58 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\bootstrap\list_skin.php 46
ERROR - 2013-06-09 02:35:01 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 02:35:10 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 02:35:16 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 02:35:30 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 02:35:38 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 02:36:58 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\write_form_skin.php 35
ERROR - 2013-06-09 02:36:58 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 02:40:08 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 02:58:29 --> Severity: Warning  --> mkdir(): File exists C:\AutoSet6\public_html\tankv\application\models\board_model.php 84
ERROR - 2013-06-09 02:58:29 --> Severity: Warning  --> strpos(): Empty delimiter C:\AutoSet6\public_html\tankv\application\models\board_model.php 109
ERROR - 2013-06-09 02:58:29 --> Severity: Notice  --> Undefined property: Board::$admin_mail_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 118
ERROR - 2013-06-09 02:58:29 --> Severity: Notice  --> Undefined property: Board::$board_mobile_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 125
ERROR - 2013-06-09 02:58:29 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 03:00:44 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 03:00:58 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 03:01:19 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 03:01:36 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 03:01:45 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 03:01:59 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 03:02:29 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 03:02:31 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\write_form_skin.php 35
ERROR - 2013-06-09 03:02:32 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 03:02:48 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 03:03:54 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 03:07:05 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 03:09:42 --> Severity: Notice  --> Undefined index: $users_email_activation C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 22
ERROR - 2013-06-09 03:09:42 --> Severity: Notice  --> Undefined variable: users_register1 C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 93
ERROR - 2013-06-09 03:09:42 --> Severity: Notice  --> Undefined variable: users_register2 C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 97
ERROR - 2013-06-09 03:12:01 --> Severity: Notice  --> Undefined variable: activated C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 63
ERROR - 2013-06-09 03:12:01 --> Severity: Notice  --> Undefined variable: banned C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 71
ERROR - 2013-06-09 03:12:01 --> Severity: Notice  --> Undefined variable: users_out C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 79
ERROR - 2013-06-09 03:12:01 --> Severity: Notice  --> Undefined variable: level C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 95
ERROR - 2013-06-09 03:12:01 --> Severity: Notice  --> Undefined variable: address1 C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 119
ERROR - 2013-06-09 03:12:01 --> Severity: Notice  --> Undefined variable: sex C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 127
ERROR - 2013-06-09 03:12:01 --> Severity: Notice  --> Undefined variable: created C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 130
ERROR - 2013-06-09 03:12:01 --> Severity: Notice  --> Undefined variable: birthday C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 133
ERROR - 2013-06-09 03:14:14 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 03:17:02 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 03:17:43 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-09 03:17:48 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 03:17:53 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 03:17:58 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_receive_list_view.php 36
ERROR - 2013-06-09 03:17:59 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_send_list_view.php 36
ERROR - 2013-06-09 03:18:02 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 03:18:09 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_receive_list_view.php 36
ERROR - 2013-06-09 03:18:58 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 03:19:48 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 03:20:43 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\write_form_skin.php 35
ERROR - 2013-06-09 03:23:47 --> Severity: Warning  --> mkdir(): File exists C:\AutoSet6\public_html\tankv\application\models\board_model.php 84
ERROR - 2013-06-09 03:23:47 --> Severity: Warning  --> strpos(): Empty delimiter C:\AutoSet6\public_html\tankv\application\models\board_model.php 109
ERROR - 2013-06-09 03:23:47 --> Severity: Notice  --> Undefined property: Board::$admin_mail_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 118
ERROR - 2013-06-09 03:23:47 --> Severity: Notice  --> Undefined property: Board::$board_mobile_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 125
ERROR - 2013-06-09 03:23:47 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 03:24:25 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 03:24:46 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 03:25:09 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 03:25:43 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 03:25:47 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\write_form_skin.php 35
ERROR - 2013-06-09 03:25:47 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 03:36:22 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\write_form_skin.php 35
ERROR - 2013-06-09 03:36:22 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 03:36:22 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 03:36:22 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 03:50:01 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 03:50:18 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 03:50:36 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 03:50:48 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 03:51:00 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 03:51:02 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\write_form_skin.php 35
ERROR - 2013-06-09 03:51:02 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 03:54:07 --> Severity: Warning  --> mkdir(): File exists C:\AutoSet6\public_html\tankv\application\models\board_model.php 84
ERROR - 2013-06-09 03:54:07 --> Severity: Warning  --> strpos(): Empty delimiter C:\AutoSet6\public_html\tankv\application\models\board_model.php 109
ERROR - 2013-06-09 03:54:07 --> Severity: Notice  --> Undefined property: Board::$admin_mail_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 118
ERROR - 2013-06-09 03:54:07 --> Severity: Notice  --> Undefined property: Board::$board_mobile_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 125
ERROR - 2013-06-09 03:54:07 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 03:54:18 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 03:58:18 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 03:58:38 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 04:00:54 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 04:01:21 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 04:03:31 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 04:03:41 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 04:04:32 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 04:04:40 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 04:04:45 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 04:04:52 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 04:04:56 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 04:05:40 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 04:05:47 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 04:06:50 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 04:06:53 --> 404 Page Not Found --> file
ERROR - 2013-06-09 04:07:02 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 04:07:03 --> 404 Page Not Found --> file
ERROR - 2013-06-09 04:07:03 --> 404 Page Not Found --> file
ERROR - 2013-06-09 04:07:17 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 04:07:22 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 04:07:30 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 04:07:35 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 04:07:37 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\write_form_skin.php 35
ERROR - 2013-06-09 04:07:38 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 04:35:06 --> Severity: Warning  --> mkdir(): File exists C:\AutoSet6\public_html\tankv\application\models\board_model.php 84
ERROR - 2013-06-09 04:35:06 --> Severity: Warning  --> strpos(): Empty delimiter C:\AutoSet6\public_html\tankv\application\models\board_model.php 109
ERROR - 2013-06-09 04:35:06 --> Severity: Notice  --> Undefined property: Board::$admin_mail_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 118
ERROR - 2013-06-09 04:35:06 --> Severity: Notice  --> Undefined property: Board::$board_mobile_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 125
ERROR - 2013-06-09 04:35:06 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 04:35:13 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 04:35:32 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 04:35:44 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 04:36:51 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 04:37:36 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 04:37:46 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 04:37:52 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 04:38:00 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 04:38:34 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 04:38:54 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 04:40:01 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 04:40:42 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 04:40:56 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 04:41:05 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 04:46:45 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 04:47:03 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 04:47:15 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 04:48:22 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 04:48:25 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 04:48:32 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 04:48:34 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 04:48:54 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 04:48:55 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 04:49:02 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 04:49:13 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 04:49:19 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 04:49:35 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 04:49:40 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 04:49:44 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 04:50:14 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 04:50:53 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 04:50:58 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 04:51:10 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 04:51:13 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 04:51:18 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 05:10:37 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 05:11:08 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 05:11:11 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 05:12:10 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 05:12:19 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 05:12:32 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 05:13:51 --> Query error: Data too long for column 'content' at row 1
ERROR - 2013-06-09 05:14:20 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 05:18:00 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 05:18:13 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 05:18:17 --> 404 Page Not Found --> file
ERROR - 2013-06-09 05:18:21 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 05:18:23 --> 404 Page Not Found --> file
ERROR - 2013-06-09 05:18:43 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 16:25:03 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 16:25:44 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 16:26:55 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 16:26:55 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 16:27:16 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-09 16:32:36 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 17:18:16 --> Severity: Warning  --> mysql_pconnect(): Access denied for user ''@'localhost' (using password: NO) C:\AutoSet6\public_html\tankv\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-06-09 17:18:16 --> Unable to connect to the database
ERROR - 2013-06-09 17:18:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\AutoSet6\public_html\tankv\install\dbconfig.php:6) C:\AutoSet6\public_html\tankv\system\core\Common.php 442
ERROR - 2013-06-09 17:18:24 --> Severity: Warning  --> mysql_pconnect(): Access denied for user ''@'localhost' (using password: NO) C:\AutoSet6\public_html\tankv\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-06-09 17:18:24 --> Unable to connect to the database
ERROR - 2013-06-09 17:18:24 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\AutoSet6\public_html\tankv\install\dbconfig.php:6) C:\AutoSet6\public_html\tankv\system\core\Common.php 442
ERROR - 2013-06-09 17:19:00 --> Severity: Warning  --> mysql_pconnect(): Access denied for user ''@'localhost' (using password: NO) C:\AutoSet6\public_html\tankv\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-06-09 17:19:00 --> Unable to connect to the database
ERROR - 2013-06-09 17:19:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\AutoSet6\public_html\tankv\install\dbconfig.php:6) C:\AutoSet6\public_html\tankv\system\core\Common.php 442
ERROR - 2013-06-09 17:20:10 --> Severity: Warning  --> mysql_pconnect(): Access denied for user ''@'localhost' (using password: NO) C:\AutoSet6\public_html\tankv\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-06-09 17:20:10 --> Unable to connect to the database
ERROR - 2013-06-09 17:20:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\AutoSet6\public_html\tankv\install\dbconfig.php:6) C:\AutoSet6\public_html\tankv\system\core\Common.php 442
ERROR - 2013-06-09 17:21:13 --> Severity: Warning  --> mysql_pconnect(): Access denied for user ''@'localhost' (using password: NO) C:\AutoSet6\public_html\tankv\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-06-09 17:21:13 --> Unable to connect to the database
ERROR - 2013-06-09 17:21:23 --> Severity: Warning  --> mysql_pconnect(): Access denied for user ''@'localhost' (using password: NO) C:\AutoSet6\public_html\tankv\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-06-09 17:21:23 --> Unable to connect to the database
ERROR - 2013-06-09 17:38:57 --> Severity: Notice  --> Undefined variable: start_idx C:\AutoSet6\public_html\tankv\application\controllers\admin\banner.php 81
ERROR - 2013-06-09 17:38:57 --> Severity: Notice  --> Undefined variable: data C:\AutoSet6\public_html\tankv\application\controllers\admin\banner.php 81
ERROR - 2013-06-09 17:43:07 --> Severity: Notice  --> Undefined variable: start_idx C:\AutoSet6\public_html\tankv\application\controllers\admin\banner.php 81
ERROR - 2013-06-09 17:43:07 --> Severity: Notice  --> Undefined variable: data C:\AutoSet6\public_html\tankv\application\controllers\admin\banner.php 81
ERROR - 2013-06-09 17:43:10 --> Severity: Notice  --> Undefined variable: start_idx C:\AutoSet6\public_html\tankv\application\controllers\admin\banner.php 81
ERROR - 2013-06-09 17:43:10 --> Severity: Notice  --> Undefined variable: data C:\AutoSet6\public_html\tankv\application\controllers\admin\banner.php 81
ERROR - 2013-06-09 17:45:54 --> Severity: Notice  --> Undefined variable: start_idx C:\AutoSet6\public_html\tankv\application\controllers\admin\banner.php 81
ERROR - 2013-06-09 17:45:54 --> Severity: Notice  --> Undefined variable: data C:\AutoSet6\public_html\tankv\application\controllers\admin\banner.php 81
ERROR - 2013-06-09 17:45:55 --> Severity: Notice  --> Undefined variable: start_idx C:\AutoSet6\public_html\tankv\application\controllers\admin\banner.php 81
ERROR - 2013-06-09 17:45:55 --> Severity: Notice  --> Undefined variable: data C:\AutoSet6\public_html\tankv\application\controllers\admin\banner.php 81
ERROR - 2013-06-09 17:56:50 --> Severity: Warning  --> mysql_pconnect(): Access denied for user ''@'localhost' (using password: NO) C:\AutoSet6\public_html\tankv\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-06-09 17:56:50 --> Unable to connect to the database
ERROR - 2013-06-09 17:56:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\AutoSet6\public_html\tankv\install\dbconfig.php:6) C:\AutoSet6\public_html\tankv\system\core\Common.php 442
ERROR - 2013-06-09 17:57:01 --> Severity: Warning  --> mysql_pconnect(): Access denied for user ''@'localhost' (using password: NO) C:\AutoSet6\public_html\tankv\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2013-06-09 17:57:01 --> Unable to connect to the database
ERROR - 2013-06-09 17:57:01 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\AutoSet6\public_html\tankv\install\dbconfig.php:6) C:\AutoSet6\public_html\tankv\system\core\Common.php 442
ERROR - 2013-06-09 17:58:21 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 17:58:27 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 17:58:32 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 17:58:38 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 18:07:26 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 18:09:25 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 18:09:28 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 18:18:45 --> Severity: Warning  --> unlink(./file/banner/): Permission denied C:\AutoSet6\public_html\tankv\include\upload\upload.php 24
ERROR - 2013-06-09 18:19:21 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 18:24:30 --> Severity: Notice  --> Undefined variable: board_skin C:\AutoSet6\public_html\tankv\application\views\admin\board_write_form_view.php 35
ERROR - 2013-06-09 18:24:30 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 18:31:54 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 18:33:58 --> Severity: Notice  --> Undefined variable: board_skin C:\AutoSet6\public_html\tankv\application\views\admin\board_write_form_view.php 35
ERROR - 2013-06-09 18:33:58 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 18:34:18 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 18:34:26 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 18:34:40 --> Severity: Warning  --> scandir(./file/board/aaaaaaaaaa/,./file/board/aaaaaaaaaa/): ������ ������ ã�� �� �����ϴ�. (code: 2) C:\AutoSet6\public_html\tankv\application\models\admin\board_model.php 112
ERROR - 2013-06-09 18:34:40 --> Severity: Warning  --> scandir(./file/board/aaaaaaaaaa/): failed to open dir: No error C:\AutoSet6\public_html\tankv\application\models\admin\board_model.php 112
ERROR - 2013-06-09 18:34:40 --> Severity: Warning  --> scandir(): (errno 0): No error C:\AutoSet6\public_html\tankv\application\models\admin\board_model.php 112
ERROR - 2013-06-09 18:34:40 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\AutoSet6\public_html\tankv\application\models\admin\board_model.php 112
ERROR - 2013-06-09 18:34:40 --> Severity: Warning  --> rmdir(./file/board/aaaaaaaaaa/): No such file or directory C:\AutoSet6\public_html\tankv\application\models\admin\board_model.php 117
ERROR - 2013-06-09 18:37:47 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 18:43:44 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 18:43:50 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 18:45:20 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 18:45:28 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 18:45:33 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 18:48:40 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 19:13:11 --> Severity: Notice  --> Undefined index: $users_email_activation C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 22
ERROR - 2013-06-09 19:13:11 --> Severity: Notice  --> Undefined variable: users_register1 C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 93
ERROR - 2013-06-09 19:13:11 --> Severity: Notice  --> Undefined variable: users_register2 C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 97
ERROR - 2013-06-09 19:13:40 --> Severity: Notice  --> Undefined property: Member_config::$users_id C:\AutoSet6\public_html\tankv\application\controllers\admin\member_config.php 66
ERROR - 2013-06-09 19:13:40 --> Severity: Notice  --> Undefined property: Member_config::$users_page C:\AutoSet6\public_html\tankv\application\controllers\admin\member_config.php 66
ERROR - 2013-06-09 19:13:40 --> Severity: Notice  --> Undefined property: Member_config::$users_no C:\AutoSet6\public_html\tankv\application\controllers\admin\member_config.php 66
ERROR - 2013-06-09 19:13:40 --> Severity: Notice  --> Undefined index: $users_email_activation C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 22
ERROR - 2013-06-09 19:13:40 --> Severity: Notice  --> Undefined variable: users_register1 C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 93
ERROR - 2013-06-09 19:13:40 --> Severity: Notice  --> Undefined variable: users_register2 C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 97
ERROR - 2013-06-09 19:13:46 --> Severity: Notice  --> Undefined index: $users_email_activation C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 22
ERROR - 2013-06-09 19:13:46 --> Severity: Notice  --> Undefined variable: users_register1 C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 93
ERROR - 2013-06-09 19:13:46 --> Severity: Notice  --> Undefined variable: users_register2 C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 97
ERROR - 2013-06-09 19:13:49 --> Severity: Notice  --> Undefined index: $users_email_activation C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 22
ERROR - 2013-06-09 19:13:49 --> Severity: Notice  --> Undefined variable: users_register1 C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 93
ERROR - 2013-06-09 19:13:49 --> Severity: Notice  --> Undefined variable: users_register2 C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 97
ERROR - 2013-06-09 19:13:55 --> Severity: Notice  --> Undefined index: $users_email_activation C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 22
ERROR - 2013-06-09 19:13:55 --> Severity: Notice  --> Undefined variable: users_register1 C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 93
ERROR - 2013-06-09 19:13:55 --> Severity: Notice  --> Undefined variable: users_register2 C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 97
ERROR - 2013-06-09 19:13:59 --> Severity: Notice  --> Undefined property: Member_config::$users_id C:\AutoSet6\public_html\tankv\application\controllers\admin\member_config.php 66
ERROR - 2013-06-09 19:13:59 --> Severity: Notice  --> Undefined property: Member_config::$users_page C:\AutoSet6\public_html\tankv\application\controllers\admin\member_config.php 66
ERROR - 2013-06-09 19:13:59 --> Severity: Notice  --> Undefined property: Member_config::$users_no C:\AutoSet6\public_html\tankv\application\controllers\admin\member_config.php 66
ERROR - 2013-06-09 19:13:59 --> Severity: Notice  --> Undefined index: $users_email_activation C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 22
ERROR - 2013-06-09 19:13:59 --> Severity: Notice  --> Undefined variable: users_register1 C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 93
ERROR - 2013-06-09 19:13:59 --> Severity: Notice  --> Undefined variable: users_register2 C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 97
ERROR - 2013-06-09 19:14:30 --> Severity: Notice  --> Undefined variable: activated C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 63
ERROR - 2013-06-09 19:14:30 --> Severity: Notice  --> Undefined variable: banned C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 71
ERROR - 2013-06-09 19:14:30 --> Severity: Notice  --> Undefined variable: users_out C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 79
ERROR - 2013-06-09 19:14:30 --> Severity: Notice  --> Undefined variable: level C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 95
ERROR - 2013-06-09 19:14:30 --> Severity: Notice  --> Undefined variable: address1 C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 119
ERROR - 2013-06-09 19:14:30 --> Severity: Notice  --> Undefined variable: sex C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 127
ERROR - 2013-06-09 19:14:30 --> Severity: Notice  --> Undefined variable: created C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 130
ERROR - 2013-06-09 19:14:30 --> Severity: Notice  --> Undefined variable: birthday C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 133
ERROR - 2013-06-09 19:14:51 --> Severity: Notice  --> Undefined variable: activated C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 63
ERROR - 2013-06-09 19:14:51 --> Severity: Notice  --> Undefined variable: banned C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 71
ERROR - 2013-06-09 19:14:51 --> Severity: Notice  --> Undefined variable: users_out C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 79
ERROR - 2013-06-09 19:14:51 --> Severity: Notice  --> Undefined variable: level C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 95
ERROR - 2013-06-09 19:14:51 --> Severity: Notice  --> Undefined variable: address1 C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 119
ERROR - 2013-06-09 19:14:51 --> Severity: Notice  --> Undefined variable: sex C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 127
ERROR - 2013-06-09 19:14:51 --> Severity: Notice  --> Undefined variable: created C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 130
ERROR - 2013-06-09 19:14:51 --> Severity: Notice  --> Undefined variable: birthday C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 133
ERROR - 2013-06-09 19:15:03 --> Severity: Notice  --> Undefined variable: activated C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 63
ERROR - 2013-06-09 19:15:03 --> Severity: Notice  --> Undefined variable: banned C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 71
ERROR - 2013-06-09 19:15:03 --> Severity: Notice  --> Undefined variable: users_out C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 79
ERROR - 2013-06-09 19:15:03 --> Severity: Notice  --> Undefined variable: level C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 95
ERROR - 2013-06-09 19:15:03 --> Severity: Notice  --> Undefined variable: address1 C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 119
ERROR - 2013-06-09 19:15:03 --> Severity: Notice  --> Undefined variable: sex C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 127
ERROR - 2013-06-09 19:15:03 --> Severity: Notice  --> Undefined variable: created C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 130
ERROR - 2013-06-09 19:15:03 --> Severity: Notice  --> Undefined variable: birthday C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 133
ERROR - 2013-06-09 19:15:35 --> Severity: Notice  --> Use of undefined constant PHPASS_HASH_STRENGTH - assumed 'PHPASS_HASH_STRENGTH' C:\AutoSet6\public_html\tankv\application\models\admin\member_model.php 109
ERROR - 2013-06-09 19:15:35 --> Severity: Notice  --> Use of undefined constant PHPASS_HASH_PORTABLE - assumed 'PHPASS_HASH_PORTABLE' C:\AutoSet6\public_html\tankv\application\models\admin\member_model.php 109
ERROR - 2013-06-09 19:15:35 --> Severity: Warning  --> fopen(/dev/urandom): failed to open stream: No such file or directory C:\AutoSet6\public_html\tankv\phpass-0.1\PasswordHash.php 49
ERROR - 2013-06-09 19:15:35 --> Severity: Notice  --> Undefined variable: activated C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 63
ERROR - 2013-06-09 19:15:35 --> Severity: Notice  --> Undefined variable: banned C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 71
ERROR - 2013-06-09 19:15:35 --> Severity: Notice  --> Undefined variable: users_out C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 79
ERROR - 2013-06-09 19:15:35 --> Severity: Notice  --> Undefined variable: level C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 95
ERROR - 2013-06-09 19:15:35 --> Severity: Notice  --> Undefined variable: address1 C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 119
ERROR - 2013-06-09 19:15:35 --> Severity: Notice  --> Undefined variable: sex C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 127
ERROR - 2013-06-09 19:15:35 --> Severity: Notice  --> Undefined variable: created C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 130
ERROR - 2013-06-09 19:15:35 --> Severity: Notice  --> Undefined variable: birthday C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 133
ERROR - 2013-06-09 20:43:54 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_receive_list_view.php 36
ERROR - 2013-06-09 20:43:57 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 20:44:14 --> Severity: Warning  --> mkdir(): File exists C:\AutoSet6\public_html\tankv\application\models\admin\admin_memo_model.php 89
ERROR - 2013-06-09 20:44:14 --> Severity: Warning  --> unlink(./file/memo/memo/): Permission denied C:\AutoSet6\public_html\tankv\include\upload\upload.php 24
ERROR - 2013-06-09 20:44:14 --> Severity: Notice  --> Undefined property: Admin_memo::$admin_mail_receive C:\AutoSet6\public_html\tankv\application\controllers\admin\admin_memo.php 141
ERROR - 2013-06-09 20:44:14 --> Severity: Notice  --> Undefined property: Admin_memo::$board_mobile_receive C:\AutoSet6\public_html\tankv\application\controllers\admin\admin_memo.php 148
ERROR - 2013-06-09 20:44:14 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_send_list_view.php 36
ERROR - 2013-06-09 20:44:50 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_receive_list_view.php 36
ERROR - 2013-06-09 20:44:53 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_send_list_view.php 36
ERROR - 2013-06-09 20:44:57 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_receive_list_view.php 36
ERROR - 2013-06-09 20:44:58 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_send_list_view.php 36
ERROR - 2013-06-09 20:45:00 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 20:45:02 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_send_list_view.php 36
ERROR - 2013-06-09 20:45:04 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 20:45:05 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_send_list_view.php 36
ERROR - 2013-06-09 20:45:12 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_send_list_view.php 36
ERROR - 2013-06-09 20:45:16 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_send_list_view.php 36
ERROR - 2013-06-09 20:45:18 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_receive_list_view.php 36
ERROR - 2013-06-09 20:45:22 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_receive_list_view.php 36
ERROR - 2013-06-09 20:45:24 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_receive_list_view.php 36
ERROR - 2013-06-09 20:45:25 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_send_list_view.php 36
ERROR - 2013-06-09 20:45:32 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_send_list_view.php 36
ERROR - 2013-06-09 20:45:37 --> 404 Page Not Found --> editor
ERROR - 2013-06-09 20:45:38 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_send_list_view.php 36
ERROR - 2013-06-09 20:45:38 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_receive_list_view.php 36
ERROR - 2013-06-09 23:46:45 --> Severity: Notice  --> Undefined index: view C:\AutoSet6\public_html\tankv\application\models\board_model.php 65
ERROR - 2013-06-09 23:46:45 --> Severity: Notice  --> Undefined index: bad_count C:\AutoSet6\public_html\tankv\application\controllers\board.php 187
ERROR - 2013-06-09 23:46:45 --> Severity: Notice  --> Undefined index: view C:\AutoSet6\public_html\tankv\application\models\board_model.php 65
ERROR - 2013-06-09 23:46:45 --> Severity: Notice  --> Undefined index: bad_count C:\AutoSet6\public_html\tankv\application\controllers\board.php 187
ERROR - 2013-06-09 23:46:45 --> Severity: Notice  --> Undefined index: view C:\AutoSet6\public_html\tankv\application\models\board_model.php 65
ERROR - 2013-06-09 23:46:45 --> Severity: Notice  --> Undefined index: bad_count C:\AutoSet6\public_html\tankv\application\controllers\board.php 187
ERROR - 2013-06-09 23:46:45 --> Severity: Notice  --> Undefined index: view C:\AutoSet6\public_html\tankv\application\models\board_model.php 65
ERROR - 2013-06-09 23:46:45 --> Severity: Notice  --> Undefined index: bad_count C:\AutoSet6\public_html\tankv\application\controllers\board.php 187
ERROR - 2013-06-09 23:46:46 --> Severity: Notice  --> Undefined index: view C:\AutoSet6\public_html\tankv\application\models\board_model.php 65
ERROR - 2013-06-09 23:46:46 --> Severity: Notice  --> Undefined index: bad_count C:\AutoSet6\public_html\tankv\application\controllers\board.php 187
ERROR - 2013-06-09 23:46:46 --> Severity: Notice  --> Undefined index: view C:\AutoSet6\public_html\tankv\application\models\board_model.php 65
ERROR - 2013-06-09 23:46:46 --> Severity: Notice  --> Undefined index: bad_count C:\AutoSet6\public_html\tankv\application\controllers\board.php 187
ERROR - 2013-06-09 23:46:46 --> Severity: Notice  --> Undefined index: view C:\AutoSet6\public_html\tankv\application\models\board_model.php 65
ERROR - 2013-06-09 23:46:46 --> Severity: Notice  --> Undefined index: bad_count C:\AutoSet6\public_html\tankv\application\controllers\board.php 187
ERROR - 2013-06-09 23:46:46 --> Severity: Notice  --> Undefined index: view C:\AutoSet6\public_html\tankv\application\models\board_model.php 65
ERROR - 2013-06-09 23:46:46 --> Severity: Notice  --> Undefined index: bad_count C:\AutoSet6\public_html\tankv\application\controllers\board.php 187
ERROR - 2013-06-09 23:46:46 --> Severity: Notice  --> Undefined index: view C:\AutoSet6\public_html\tankv\application\models\board_model.php 65
ERROR - 2013-06-09 23:46:46 --> Severity: Notice  --> Undefined index: bad_count C:\AutoSet6\public_html\tankv\application\controllers\board.php 187
ERROR - 2013-06-09 23:46:46 --> Severity: Notice  --> Undefined index: view C:\AutoSet6\public_html\tankv\application\models\board_model.php 65
ERROR - 2013-06-09 23:46:46 --> Severity: Notice  --> Undefined index: bad_count C:\AutoSet6\public_html\tankv\application\controllers\board.php 187
ERROR - 2013-06-09 23:46:51 --> Severity: Notice  --> Undefined variable: start_idx C:\AutoSet6\public_html\tankv\application\controllers\board.php 87
ERROR - 2013-06-09 23:46:51 --> Severity: Notice  --> Undefined variable: data C:\AutoSet6\public_html\tankv\application\controllers\board.php 87
ERROR - 2013-06-09 23:46:52 --> Severity: Notice  --> Undefined variable: start_idx C:\AutoSet6\public_html\tankv\application\controllers\board.php 87
ERROR - 2013-06-09 23:46:52 --> Severity: Notice  --> Undefined variable: data C:\AutoSet6\public_html\tankv\application\controllers\board.php 87
ERROR - 2013-06-09 23:46:52 --> Severity: Notice  --> Undefined variable: start_idx C:\AutoSet6\public_html\tankv\application\controllers\board.php 87
ERROR - 2013-06-09 23:46:52 --> Severity: Notice  --> Undefined variable: data C:\AutoSet6\public_html\tankv\application\controllers\board.php 87
ERROR - 2013-06-09 23:46:52 --> Severity: Notice  --> Undefined variable: start_idx C:\AutoSet6\public_html\tankv\application\controllers\board.php 87
ERROR - 2013-06-09 23:46:52 --> Severity: Notice  --> Undefined variable: data C:\AutoSet6\public_html\tankv\application\controllers\board.php 87
ERROR - 2013-06-09 23:46:52 --> Severity: Notice  --> Undefined variable: start_idx C:\AutoSet6\public_html\tankv\application\controllers\board.php 87
ERROR - 2013-06-09 23:46:52 --> Severity: Notice  --> Undefined variable: data C:\AutoSet6\public_html\tankv\application\controllers\board.php 87
ERROR - 2013-06-09 23:46:52 --> Severity: Notice  --> Undefined variable: start_idx C:\AutoSet6\public_html\tankv\application\controllers\board.php 87
ERROR - 2013-06-09 23:46:52 --> Severity: Notice  --> Undefined variable: data C:\AutoSet6\public_html\tankv\application\controllers\board.php 87
ERROR - 2013-06-09 23:46:52 --> Severity: Notice  --> Undefined variable: start_idx C:\AutoSet6\public_html\tankv\application\controllers\board.php 87
ERROR - 2013-06-09 23:46:52 --> Severity: Notice  --> Undefined variable: data C:\AutoSet6\public_html\tankv\application\controllers\board.php 87
ERROR - 2013-06-09 23:46:52 --> Severity: Notice  --> Undefined variable: start_idx C:\AutoSet6\public_html\tankv\application\controllers\board.php 87
ERROR - 2013-06-09 23:46:52 --> Severity: Notice  --> Undefined variable: data C:\AutoSet6\public_html\tankv\application\controllers\board.php 87
ERROR - 2013-06-09 23:46:52 --> Severity: Notice  --> Undefined variable: start_idx C:\AutoSet6\public_html\tankv\application\controllers\board.php 87
ERROR - 2013-06-09 23:46:52 --> Severity: Notice  --> Undefined variable: data C:\AutoSet6\public_html\tankv\application\controllers\board.php 87
ERROR - 2013-06-09 23:46:52 --> Severity: Notice  --> Undefined variable: start_idx C:\AutoSet6\public_html\tankv\application\controllers\board.php 87
ERROR - 2013-06-09 23:46:52 --> Severity: Notice  --> Undefined variable: data C:\AutoSet6\public_html\tankv\application\controllers\board.php 87
ERROR - 2013-06-09 23:46:52 --> Severity: Notice  --> Undefined variable: start_idx C:\AutoSet6\public_html\tankv\application\controllers\board.php 87
ERROR - 2013-06-09 23:46:52 --> Severity: Notice  --> Undefined variable: data C:\AutoSet6\public_html\tankv\application\controllers\board.php 87
