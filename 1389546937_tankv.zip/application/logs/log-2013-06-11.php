<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-06-11 00:22:35 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 00:38:12 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-11 00:38:16 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-11 00:38:16 --> Severity: Notice  --> Undefined index: ip_address C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-11 00:38:16 --> Severity: Notice  --> Undefined index: user_agent C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-11 00:38:16 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-11 00:38:16 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 288
ERROR - 2013-06-11 00:38:16 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 289
ERROR - 2013-06-11 00:42:55 --> Severity: Notice  --> Undefined variable: login_by_username C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 39
ERROR - 2013-06-11 00:42:55 --> Severity: Notice  --> Undefined variable: login_by_username C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 41
ERROR - 2013-06-11 00:42:55 --> Severity: Notice  --> Undefined variable: users_skin C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 73
ERROR - 2013-06-11 00:42:55 --> Severity: Notice  --> Undefined variable: show_captcha C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 86
ERROR - 2013-06-11 00:44:30 --> Severity: Notice  --> Undefined variable: login_by_username C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 39
ERROR - 2013-06-11 00:44:30 --> Severity: Notice  --> Undefined variable: login_by_username C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 41
ERROR - 2013-06-11 00:44:30 --> Severity: Notice  --> Undefined variable: users_skin C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 73
ERROR - 2013-06-11 00:44:30 --> Severity: Notice  --> Undefined variable: show_captcha C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 86
ERROR - 2013-06-11 00:44:31 --> Severity: Notice  --> Undefined variable: login_by_username C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 39
ERROR - 2013-06-11 00:44:31 --> Severity: Notice  --> Undefined variable: login_by_username C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 41
ERROR - 2013-06-11 00:44:31 --> Severity: Notice  --> Undefined variable: users_skin C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 73
ERROR - 2013-06-11 00:44:31 --> Severity: Notice  --> Undefined variable: show_captcha C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 86
ERROR - 2013-06-11 00:44:32 --> Severity: Notice  --> Undefined variable: login_by_username C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 39
ERROR - 2013-06-11 00:44:32 --> Severity: Notice  --> Undefined variable: login_by_username C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 41
ERROR - 2013-06-11 00:44:32 --> Severity: Notice  --> Undefined variable: users_skin C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 73
ERROR - 2013-06-11 00:44:32 --> Severity: Notice  --> Undefined variable: show_captcha C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 86
ERROR - 2013-06-11 00:46:16 --> Severity: Notice  --> Undefined variable: login_by_username C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 39
ERROR - 2013-06-11 00:46:16 --> Severity: Notice  --> Undefined variable: login_by_username C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 41
ERROR - 2013-06-11 00:46:16 --> Severity: Notice  --> Undefined variable: users_skin C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 73
ERROR - 2013-06-11 00:46:16 --> Severity: Notice  --> Undefined variable: show_captcha C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 86
ERROR - 2013-06-11 00:47:27 --> Severity: Notice  --> Undefined variable: login_by_username C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 39
ERROR - 2013-06-11 00:47:27 --> Severity: Notice  --> Undefined variable: login_by_username C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 41
ERROR - 2013-06-11 00:47:27 --> Severity: Notice  --> Undefined variable: users_skin C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 73
ERROR - 2013-06-11 00:47:27 --> Severity: Notice  --> Undefined variable: show_captcha C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 86
ERROR - 2013-06-11 00:49:56 --> Severity: Notice  --> Undefined variable: login_by_username C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 39
ERROR - 2013-06-11 00:49:56 --> Severity: Notice  --> Undefined variable: login_by_username C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 41
ERROR - 2013-06-11 00:49:56 --> Severity: Notice  --> Undefined variable: users_skin C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 73
ERROR - 2013-06-11 00:49:56 --> Severity: Notice  --> Undefined variable: show_captcha C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 86
ERROR - 2013-06-11 00:49:56 --> Severity: Notice  --> Undefined variable: login_by_username C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 39
ERROR - 2013-06-11 00:49:56 --> Severity: Notice  --> Undefined variable: login_by_username C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 41
ERROR - 2013-06-11 00:49:56 --> Severity: Notice  --> Undefined variable: users_skin C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 73
ERROR - 2013-06-11 00:49:56 --> Severity: Notice  --> Undefined variable: show_captcha C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 86
ERROR - 2013-06-11 00:51:01 --> Severity: Notice  --> Undefined variable: login_by_username C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 39
ERROR - 2013-06-11 00:51:01 --> Severity: Notice  --> Undefined variable: login_by_username C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 41
ERROR - 2013-06-11 00:51:01 --> Severity: Notice  --> Undefined variable: users_skin C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 73
ERROR - 2013-06-11 00:51:36 --> Severity: Notice  --> Undefined variable: login_by_username C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 39
ERROR - 2013-06-11 00:51:36 --> Severity: Notice  --> Undefined variable: login_by_username C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 41
ERROR - 2013-06-11 00:51:36 --> Severity: Notice  --> Undefined variable: login_by_username C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 39
ERROR - 2013-06-11 00:51:36 --> Severity: Notice  --> Undefined variable: login_by_username C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 41
ERROR - 2013-06-11 00:52:25 --> Severity: Notice  --> Undefined variable: login_label C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 67
ERROR - 2013-06-11 00:53:49 --> Severity: Notice  --> Undefined variable: 아이디 C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 67
ERROR - 2013-06-11 00:53:49 --> Severity: Notice  --> Undefined variable: 아이디 C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 67
ERROR - 2013-06-11 01:06:27 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-11 01:06:27 --> Severity: Notice  --> Undefined index: ip_address C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-11 01:06:27 --> Severity: Notice  --> Undefined index: user_agent C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-11 01:06:27 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-11 01:06:27 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 288
ERROR - 2013-06-11 01:06:27 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 289
ERROR - 2013-06-11 01:07:11 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-11 01:07:11 --> Severity: Notice  --> Undefined index: ip_address C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-11 01:07:11 --> Severity: Notice  --> Undefined index: user_agent C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-11 01:07:11 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-11 01:07:11 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 288
ERROR - 2013-06-11 01:07:11 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 289
ERROR - 2013-06-11 01:11:44 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-11 01:11:48 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 01:11:52 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_receive_list_view.php 36
ERROR - 2013-06-11 01:11:55 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_send_list_view.php 36
ERROR - 2013-06-11 01:11:57 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 01:11:58 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_send_list_view.php 36
ERROR - 2013-06-11 01:11:59 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_receive_list_view.php 36
ERROR - 2013-06-11 01:21:34 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-11 01:21:36 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-11 01:21:37 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\send_list_view.php 46
ERROR - 2013-06-11 01:21:38 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 01:21:39 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\send_list_view.php 46
ERROR - 2013-06-11 01:21:40 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-11 01:21:42 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\send_list_view.php 46
ERROR - 2013-06-11 01:21:42 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 01:21:43 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\send_list_view.php 46
ERROR - 2013-06-11 01:21:44 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-11 01:21:45 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\send_list_view.php 46
ERROR - 2013-06-11 01:21:47 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 01:21:48 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\send_list_view.php 46
ERROR - 2013-06-11 01:21:50 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-11 01:21:54 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 01:22:26 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-11 01:22:36 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-11 01:22:53 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 01:22:56 --> Severity: Warning  --> strpos(): Empty delimiter C:\AutoSet6\public_html\tankv\application\models\board_model.php 109
ERROR - 2013-06-11 01:22:56 --> Severity: Notice  --> Undefined property: Board::$admin_mail_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 118
ERROR - 2013-06-11 01:22:56 --> Severity: Notice  --> Undefined property: Board::$board_mobile_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 125
ERROR - 2013-06-11 01:22:58 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 01:23:02 --> Severity: Warning  --> strpos(): Empty delimiter C:\AutoSet6\public_html\tankv\application\models\board_model.php 109
ERROR - 2013-06-11 01:23:02 --> Severity: Notice  --> Undefined property: Board::$admin_mail_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 118
ERROR - 2013-06-11 01:23:02 --> Severity: Notice  --> Undefined property: Board::$board_mobile_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 125
ERROR - 2013-06-11 01:23:04 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 01:23:07 --> Severity: Warning  --> strpos(): Empty delimiter C:\AutoSet6\public_html\tankv\application\models\board_model.php 109
ERROR - 2013-06-11 01:23:07 --> Severity: Notice  --> Undefined property: Board::$admin_mail_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 118
ERROR - 2013-06-11 01:23:07 --> Severity: Notice  --> Undefined property: Board::$board_mobile_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 125
ERROR - 2013-06-11 01:23:09 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 01:23:12 --> Severity: Warning  --> strpos(): Empty delimiter C:\AutoSet6\public_html\tankv\application\models\board_model.php 109
ERROR - 2013-06-11 01:23:12 --> Severity: Notice  --> Undefined property: Board::$admin_mail_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 118
ERROR - 2013-06-11 01:23:12 --> Severity: Notice  --> Undefined property: Board::$board_mobile_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 125
ERROR - 2013-06-11 01:23:15 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 01:23:18 --> Severity: Warning  --> strpos(): Empty delimiter C:\AutoSet6\public_html\tankv\application\models\board_model.php 109
ERROR - 2013-06-11 01:23:18 --> Severity: Notice  --> Undefined property: Board::$admin_mail_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 118
ERROR - 2013-06-11 01:23:18 --> Severity: Notice  --> Undefined property: Board::$board_mobile_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 125
ERROR - 2013-06-11 01:23:20 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 01:23:23 --> Severity: Warning  --> strpos(): Empty delimiter C:\AutoSet6\public_html\tankv\application\models\board_model.php 109
ERROR - 2013-06-11 01:23:23 --> Severity: Notice  --> Undefined property: Board::$admin_mail_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 118
ERROR - 2013-06-11 01:23:23 --> Severity: Notice  --> Undefined property: Board::$board_mobile_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 125
ERROR - 2013-06-11 01:23:27 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 01:23:30 --> Severity: Warning  --> strpos(): Empty delimiter C:\AutoSet6\public_html\tankv\application\models\board_model.php 109
ERROR - 2013-06-11 01:23:30 --> Severity: Notice  --> Undefined property: Board::$admin_mail_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 118
ERROR - 2013-06-11 01:23:30 --> Severity: Notice  --> Undefined property: Board::$board_mobile_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 125
ERROR - 2013-06-11 01:39:21 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 01:39:59 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 01:40:17 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-11 01:41:03 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 58
ERROR - 2013-06-11 01:41:42 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 58
ERROR - 2013-06-11 01:45:30 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 01:45:43 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 01:46:11 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 02:04:28 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 02:04:48 --> Severity: Warning  --> include(include/pagination/boot_pagination.php): failed to open stream: No such file or directory C:\AutoSet6\public_html\tankv\application\controllers\board.php 86
ERROR - 2013-06-11 02:04:48 --> Severity: Warning  --> include(include/pagination/boot_pagination.php): failed to open stream: No such file or directory C:\AutoSet6\public_html\tankv\application\controllers\board.php 86
ERROR - 2013-06-11 02:04:48 --> Severity: Warning  --> include(): Failed opening 'include/pagination/boot_pagination.php' for inclusion (include_path='.') C:\AutoSet6\public_html\tankv\application\controllers\board.php 86
ERROR - 2013-06-11 02:04:48 --> Severity: Notice  --> Undefined variable: start_idx C:\AutoSet6\public_html\tankv\application\controllers\board.php 94
ERROR - 2013-06-11 02:04:48 --> Severity: Notice  --> Undefined variable: data C:\AutoSet6\public_html\tankv\application\controllers\board.php 94
ERROR - 2013-06-11 02:04:48 --> Severity: Notice  --> Undefined variable: act_url C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 23
ERROR - 2013-06-11 02:04:48 --> Severity: Notice  --> Undefined variable: total_record C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 52
ERROR - 2013-06-11 02:04:48 --> Severity: Notice  --> Undefined variable: page C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 52
ERROR - 2013-06-11 02:04:48 --> Severity: Notice  --> Undefined variable: total_page C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 52
ERROR - 2013-06-11 02:04:48 --> Severity: Notice  --> Undefined variable: pagenum C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 125
ERROR - 2013-06-11 02:04:53 --> Severity: Warning  --> include(include/pagination/boot_pagination.php): failed to open stream: No such file or directory C:\AutoSet6\public_html\tankv\application\controllers\board.php 86
ERROR - 2013-06-11 02:04:53 --> Severity: Warning  --> include(include/pagination/boot_pagination.php): failed to open stream: No such file or directory C:\AutoSet6\public_html\tankv\application\controllers\board.php 86
ERROR - 2013-06-11 02:04:53 --> Severity: Warning  --> include(): Failed opening 'include/pagination/boot_pagination.php' for inclusion (include_path='.') C:\AutoSet6\public_html\tankv\application\controllers\board.php 86
ERROR - 2013-06-11 02:04:53 --> Severity: Notice  --> Undefined variable: start_idx C:\AutoSet6\public_html\tankv\application\controllers\board.php 94
ERROR - 2013-06-11 02:04:53 --> Severity: Notice  --> Undefined variable: data C:\AutoSet6\public_html\tankv\application\controllers\board.php 94
ERROR - 2013-06-11 02:04:53 --> Severity: Notice  --> Undefined variable: act_url C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 23
ERROR - 2013-06-11 02:04:53 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 02:04:53 --> Severity: Notice  --> Undefined variable: total_record C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 52
ERROR - 2013-06-11 02:04:53 --> Severity: Notice  --> Undefined variable: page C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 52
ERROR - 2013-06-11 02:04:53 --> Severity: Notice  --> Undefined variable: total_page C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 52
ERROR - 2013-06-11 02:04:53 --> Severity: Notice  --> Undefined variable: pagenum C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 125
ERROR - 2013-06-11 02:05:07 --> Severity: Warning  --> include(include/pagination/boot_pagination.php): failed to open stream: No such file or directory C:\AutoSet6\public_html\tankv\application\controllers\board.php 86
ERROR - 2013-06-11 02:05:07 --> Severity: Warning  --> include(include/pagination/boot_pagination.php): failed to open stream: No such file or directory C:\AutoSet6\public_html\tankv\application\controllers\board.php 86
ERROR - 2013-06-11 02:05:07 --> Severity: Warning  --> include(): Failed opening 'include/pagination/boot_pagination.php' for inclusion (include_path='.') C:\AutoSet6\public_html\tankv\application\controllers\board.php 86
ERROR - 2013-06-11 02:05:07 --> Severity: Notice  --> Undefined variable: start_idx C:\AutoSet6\public_html\tankv\application\controllers\board.php 94
ERROR - 2013-06-11 02:05:07 --> Severity: Notice  --> Undefined variable: data C:\AutoSet6\public_html\tankv\application\controllers\board.php 94
ERROR - 2013-06-11 02:05:07 --> Severity: Notice  --> Undefined variable: act_url C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 23
ERROR - 2013-06-11 02:05:07 --> Severity: Notice  --> Undefined variable: total_record C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 52
ERROR - 2013-06-11 02:05:07 --> Severity: Notice  --> Undefined variable: page C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 52
ERROR - 2013-06-11 02:05:07 --> Severity: Notice  --> Undefined variable: total_page C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 52
ERROR - 2013-06-11 02:05:07 --> Severity: Notice  --> Undefined variable: pagenum C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 125
ERROR - 2013-06-11 02:07:27 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 02:07:53 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 02:08:02 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 02:08:08 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 02:08:22 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 02:20:20 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 02:23:11 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_receive_list_view.php 36
ERROR - 2013-06-11 02:23:13 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_send_list_view.php 36
ERROR - 2013-06-11 02:23:15 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 02:23:16 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_send_list_view.php 36
ERROR - 2013-06-11 02:23:17 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_receive_list_view.php 36
ERROR - 2013-06-11 02:23:19 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_send_list_view.php 36
ERROR - 2013-06-11 02:23:21 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 02:34:22 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 02:34:38 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 02:35:16 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 02:35:45 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 02:35:55 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 02:37:20 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 02:42:39 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 02:42:47 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 02:42:50 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 02:42:54 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 02:44:03 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 02:44:04 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 02:44:05 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 02:44:06 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 02:44:46 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 02:44:48 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 02:44:55 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 02:45:49 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 02:45:55 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 02:47:12 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\write_form_skin.php 35
ERROR - 2013-06-11 02:47:12 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 02:47:20 --> Severity: Warning  --> mkdir(): File exists C:\AutoSet6\public_html\tankv\application\models\board_model.php 84
ERROR - 2013-06-11 02:47:20 --> Severity: Warning  --> strpos(): Empty delimiter C:\AutoSet6\public_html\tankv\application\models\board_model.php 109
ERROR - 2013-06-11 02:47:20 --> Severity: Notice  --> Undefined property: Board::$admin_mail_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 125
ERROR - 2013-06-11 02:47:20 --> Severity: Notice  --> Undefined property: Board::$board_mobile_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 132
ERROR - 2013-06-11 02:47:21 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 02:47:34 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 02:47:35 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\write_form_skin.php 35
ERROR - 2013-06-11 02:47:36 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 02:47:39 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\write_form_skin.php 35
ERROR - 2013-06-11 02:47:40 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 02:50:40 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\write_form_skin.php 35
ERROR - 2013-06-11 02:50:41 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 02:50:44 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 02:50:57 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 02:52:10 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 02:52:14 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 03:27:10 --> Severity: Warning  --> include_once(analyticstracking.php): failed to open stream: No such file or directory C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 2
ERROR - 2013-06-11 03:27:10 --> Severity: Warning  --> include_once(): Failed opening 'analyticstracking.php' for inclusion (include_path='.') C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 2
ERROR - 2013-06-11 03:40:21 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 03:43:43 --> Severity: Notice  --> Undefined variable: analytics C:\AutoSet6\public_html\tankv\application\views\admin\site_config_form_view.php 139
ERROR - 2013-06-11 03:43:43 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 03:45:13 --> Severity: Notice  --> Undefined variable: analytics C:\AutoSet6\public_html\tankv\application\views\admin\site_config_form_view.php 133
ERROR - 2013-06-11 03:45:14 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 03:45:31 --> Severity: Notice  --> Undefined variable: analytics C:\AutoSet6\public_html\tankv\application\views\admin\site_config_form_view.php 133
ERROR - 2013-06-11 03:45:31 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 03:47:03 --> Severity: Notice  --> Undefined variable: analytics C:\AutoSet6\public_html\tankv\application\views\admin\site_config_form_view.php 133
ERROR - 2013-06-11 03:47:03 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 03:49:40 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 03:50:48 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 03:53:17 --> Severity: Notice  --> Undefined variable: nalytics C:\AutoSet6\public_html\tankv\layouts\main\bootstrap\main_top_layout.php 10
ERROR - 2013-06-11 03:59:44 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 03:59:58 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 04:00:15 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 04:00:18 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 04:01:31 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 04:01:37 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 04:03:12 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 04:03:13 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 04:03:35 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 04:03:41 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 04:04:23 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 04:04:28 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 04:05:01 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 04:05:19 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 04:09:23 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 04:14:34 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 04:14:40 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 04:15:32 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 04:15:46 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 04:16:01 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 04:16:10 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 04:16:36 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 04:17:33 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 04:19:55 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 04:20:03 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 04:22:52 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 04:23:19 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 04:23:35 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 04:24:25 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 04:25:07 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 04:37:38 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 04:38:44 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 04:39:12 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 04:40:47 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 04:42:04 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 04:42:11 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 04:43:14 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 04:43:25 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 04:43:33 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 04:43:45 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 04:44:15 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 04:47:58 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 04:48:05 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 04:48:10 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 04:52:43 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 04:53:03 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 04:56:22 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 04:57:05 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 04:59:03 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 04:59:23 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 05:00:10 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 05:00:29 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 05:01:06 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 05:01:22 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 05:01:34 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 05:04:05 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 05:04:35 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 05:04:58 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 05:05:21 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 05:06:20 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 05:06:22 --> Severity: Notice  --> Undefined index: $users_email_activation C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 22
ERROR - 2013-06-11 05:06:22 --> Severity: Notice  --> Undefined variable: users_register1 C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 93
ERROR - 2013-06-11 05:06:22 --> Severity: Notice  --> Undefined variable: users_register2 C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 97
ERROR - 2013-06-11 05:06:26 --> Severity: Notice  --> Undefined variable: activated C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 63
ERROR - 2013-06-11 05:06:26 --> Severity: Notice  --> Undefined variable: banned C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 71
ERROR - 2013-06-11 05:06:26 --> Severity: Notice  --> Undefined variable: users_out C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 79
ERROR - 2013-06-11 05:06:26 --> Severity: Notice  --> Undefined variable: level C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 95
ERROR - 2013-06-11 05:06:26 --> Severity: Notice  --> Undefined variable: address1 C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 119
ERROR - 2013-06-11 05:06:26 --> Severity: Notice  --> Undefined variable: sex C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 127
ERROR - 2013-06-11 05:06:26 --> Severity: Notice  --> Undefined variable: created C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 130
ERROR - 2013-06-11 05:06:26 --> Severity: Notice  --> Undefined variable: birthday C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 133
ERROR - 2013-06-11 05:09:04 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 05:09:34 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 05:12:21 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 05:12:50 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 05:13:08 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 05:13:17 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 05:14:02 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 05:14:20 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 05:14:37 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 05:16:28 --> 404 Page Not Found --> editor
ERROR - 2013-06-11 05:16:45 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 05:17:30 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
ERROR - 2013-06-11 05:17:34 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 48
