<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-06-10 02:34:19 --> Severity: Notice  --> Undefined variable: start_idx C:\AutoSet6\public_html\tankv\application\controllers\board.php 87
ERROR - 2013-06-10 02:34:19 --> Severity: Notice  --> Undefined variable: data C:\AutoSet6\public_html\tankv\application\controllers\board.php 87
ERROR - 2013-06-10 02:34:19 --> Severity: Notice  --> Undefined variable: act_url C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 22
ERROR - 2013-06-10 02:34:19 --> Severity: Notice  --> Undefined variable: total_record C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 51
ERROR - 2013-06-10 02:34:19 --> Severity: Notice  --> Undefined variable: page C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 51
ERROR - 2013-06-10 02:34:19 --> Severity: Notice  --> Undefined variable: total_page C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 51
ERROR - 2013-06-10 02:34:19 --> Severity: Notice  --> Undefined variable: pagenum C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 122
ERROR - 2013-06-10 02:35:34 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 02:35:42 --> Severity: Notice  --> Undefined variable: attributes C:\AutoSet6\public_html\tankv\skin\board\boot_smart\reply_form_skin.php 18
ERROR - 2013-06-10 02:35:42 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 02:37:18 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 02:37:32 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 02:37:36 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 02:37:47 --> Severity: Notice  --> Undefined variable: cookie_good_coun C:\AutoSet6\public_html\tankv\application\models\board_model.php 276
ERROR - 2013-06-10 02:37:50 --> Severity: Notice  --> Undefined property: Board::$admin_write_level C:\AutoSet6\public_html\tankv\application\controllers\board.php 289
ERROR - 2013-06-10 02:38:05 --> Severity: Notice  --> Undefined property: Board::$admin_write_level C:\AutoSet6\public_html\tankv\application\controllers\board.php 289
ERROR - 2013-06-10 02:38:08 --> Severity: Notice  --> Undefined index: comments C:\AutoSet6\public_html\tankv\application\models\board_model.php 421
ERROR - 2013-06-10 02:38:19 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 02:38:30 --> Severity: Warning  --> unlink(./file/board/notice/): Permission denied C:\AutoSet6\public_html\tankv\include\upload\upload.php 24
ERROR - 2013-06-10 02:38:30 --> Severity: Warning  --> strpos(): Empty delimiter C:\AutoSet6\public_html\tankv\application\models\board_model.php 109
ERROR - 2013-06-10 02:38:30 --> Severity: Notice  --> Undefined property: Board::$admin_mail_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 118
ERROR - 2013-06-10 02:38:30 --> Severity: Notice  --> Undefined property: Board::$board_mobile_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 125
ERROR - 2013-06-10 02:38:40 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 02:38:42 --> Severity: Notice  --> Undefined property: Board::$admin_mail_send C:\AutoSet6\public_html\tankv\application\controllers\board.php 160
ERROR - 2013-06-10 02:38:42 --> Severity: Notice  --> Undefined property: Board::$board_mobile_send C:\AutoSet6\public_html\tankv\application\controllers\board.php 167
ERROR - 2013-06-10 02:38:46 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 02:39:20 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 02:39:31 --> Severity: Warning  --> mkdir(): File exists C:\AutoSet6\public_html\tankv\application\controllers\admin\board.php 186
ERROR - 2013-06-10 02:39:31 --> Severity: Warning  --> mkdir(): File exists C:\AutoSet6\public_html\tankv\application\controllers\admin\board.php 187
ERROR - 2013-06-10 02:39:31 --> Severity: Warning  --> mkdir(): File exists C:\AutoSet6\public_html\tankv\application\controllers\admin\board.php 188
ERROR - 2013-06-10 02:39:31 --> Severity: Warning  --> mkdir(): File exists C:\AutoSet6\public_html\tankv\application\controllers\admin\board.php 189
ERROR - 2013-06-10 02:39:40 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 02:39:45 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 02:39:54 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 02:40:05 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 02:42:22 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 02:42:55 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 02:43:37 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 02:43:46 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 02:43:49 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 02:43:53 --> Severity: Notice  --> Undefined variable: board_skin C:\AutoSet6\public_html\tankv\application\views\admin\board_write_form_view.php 35
ERROR - 2013-06-10 02:43:53 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 02:44:08 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 02:44:18 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 02:44:24 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 02:44:27 --> Severity: Notice  --> Undefined index: $users_email_activation C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 22
ERROR - 2013-06-10 02:44:27 --> Severity: Notice  --> Undefined variable: users_register1 C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 93
ERROR - 2013-06-10 02:44:27 --> Severity: Notice  --> Undefined variable: users_register2 C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 97
ERROR - 2013-06-10 02:44:37 --> Severity: Notice  --> Undefined variable: activated C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 63
ERROR - 2013-06-10 02:44:37 --> Severity: Notice  --> Undefined variable: banned C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 71
ERROR - 2013-06-10 02:44:37 --> Severity: Notice  --> Undefined variable: users_out C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 79
ERROR - 2013-06-10 02:44:37 --> Severity: Notice  --> Undefined variable: level C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 95
ERROR - 2013-06-10 02:44:37 --> Severity: Notice  --> Undefined variable: address1 C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 119
ERROR - 2013-06-10 02:44:37 --> Severity: Notice  --> Undefined variable: sex C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 127
ERROR - 2013-06-10 02:44:37 --> Severity: Notice  --> Undefined variable: created C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 130
ERROR - 2013-06-10 02:44:37 --> Severity: Notice  --> Undefined variable: birthday C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 133
ERROR - 2013-06-10 02:44:44 --> Severity: Notice  --> Undefined variable: activated C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 63
ERROR - 2013-06-10 02:44:44 --> Severity: Notice  --> Undefined variable: banned C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 71
ERROR - 2013-06-10 02:44:44 --> Severity: Notice  --> Undefined variable: users_out C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 79
ERROR - 2013-06-10 02:44:44 --> Severity: Notice  --> Undefined variable: level C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 95
ERROR - 2013-06-10 02:44:44 --> Severity: Notice  --> Undefined variable: address1 C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 119
ERROR - 2013-06-10 02:44:44 --> Severity: Notice  --> Undefined variable: sex C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 127
ERROR - 2013-06-10 02:44:44 --> Severity: Notice  --> Undefined variable: created C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 130
ERROR - 2013-06-10 02:44:44 --> Severity: Notice  --> Undefined variable: birthday C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 133
ERROR - 2013-06-10 02:45:04 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 02:45:10 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 02:45:16 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 02:45:22 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 02:45:24 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_receive_list_view.php 36
ERROR - 2013-06-10 02:45:26 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 02:45:30 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_send_list_view.php 36
ERROR - 2013-06-10 02:45:33 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_receive_list_view.php 36
ERROR - 2013-06-10 02:45:34 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_send_list_view.php 36
ERROR - 2013-06-10 02:45:35 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 02:45:41 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 02:45:50 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 02:46:00 --> Severity: Notice  --> Undefined variable: users_sms C:\AutoSet6\public_html\tankv\application\views\admin\sms_read_view.php 30
ERROR - 2013-06-10 02:46:18 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 02:46:21 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 02:46:27 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:05:24 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 03:05:25 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:07:00 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:07:07 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:07:17 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:07:27 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:09:37 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:10:00 --> Severity: Notice  --> Undefined variable: board_skin C:\AutoSet6\public_html\tankv\application\views\admin\board_write_form_view.php 35
ERROR - 2013-06-10 03:10:00 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:10:00 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:10:54 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:11:02 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:11:18 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:11:39 --> Severity: Warning  --> mkdir(): File exists C:\AutoSet6\public_html\tankv\application\models\board_model.php 84
ERROR - 2013-06-10 03:11:39 --> Severity: Warning  --> unlink(./file/board/free_board/): Permission denied C:\AutoSet6\public_html\tankv\include\upload\upload.php 24
ERROR - 2013-06-10 03:11:39 --> Severity: Warning  --> strpos(): Empty delimiter C:\AutoSet6\public_html\tankv\application\models\board_model.php 109
ERROR - 2013-06-10 03:11:39 --> Severity: Notice  --> Undefined property: Board::$admin_mail_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 118
ERROR - 2013-06-10 03:11:39 --> Severity: Notice  --> Undefined property: Board::$board_mobile_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 125
ERROR - 2013-06-10 03:11:44 --> Severity: Notice  --> Undefined property: Board::$admin_write_level C:\AutoSet6\public_html\tankv\application\controllers\board.php 289
ERROR - 2013-06-10 03:11:46 --> Severity: Notice  --> Undefined property: Board::$admin_write_level C:\AutoSet6\public_html\tankv\application\controllers\board.php 289
ERROR - 2013-06-10 03:12:05 --> Severity: Notice  --> Undefined index: comments C:\AutoSet6\public_html\tankv\application\models\board_model.php 421
ERROR - 2013-06-10 03:18:36 --> Severity: Notice  --> Undefined property: Board::$admin_write_level C:\AutoSet6\public_html\tankv\application\controllers\board.php 289
ERROR - 2013-06-10 03:18:49 --> Severity: Notice  --> Undefined index: comments C:\AutoSet6\public_html\tankv\application\models\board_model.php 422
ERROR - 2013-06-10 03:21:22 --> Severity: Notice  --> Undefined property: Board::$admin_write_level C:\AutoSet6\public_html\tankv\application\controllers\board.php 289
ERROR - 2013-06-10 03:21:26 --> Severity: Notice  --> Undefined index: comments C:\AutoSet6\public_html\tankv\application\models\board_model.php 422
ERROR - 2013-06-10 03:22:23 --> Severity: Notice  --> Undefined index: comments C:\AutoSet6\public_html\tankv\application\models\board_model.php 422
ERROR - 2013-06-10 03:26:57 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:27:05 --> Severity: Warning  --> strpos(): Empty delimiter C:\AutoSet6\public_html\tankv\application\models\board_model.php 109
ERROR - 2013-06-10 03:27:05 --> Severity: Notice  --> Undefined property: Board::$admin_mail_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 118
ERROR - 2013-06-10 03:27:05 --> Severity: Notice  --> Undefined property: Board::$board_mobile_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 125
ERROR - 2013-06-10 03:27:10 --> Severity: Notice  --> Undefined property: Board::$admin_write_level C:\AutoSet6\public_html\tankv\application\controllers\board.php 289
ERROR - 2013-06-10 03:27:12 --> Severity: Notice  --> Undefined property: Board::$admin_write_level C:\AutoSet6\public_html\tankv\application\controllers\board.php 289
ERROR - 2013-06-10 03:27:14 --> Severity: Notice  --> Undefined property: Board::$admin_write_level C:\AutoSet6\public_html\tankv\application\controllers\board.php 289
ERROR - 2013-06-10 03:27:21 --> Severity: Notice  --> Undefined index: comments C:\AutoSet6\public_html\tankv\application\models\board_model.php 422
ERROR - 2013-06-10 03:27:33 --> Severity: Notice  --> Undefined index: comments C:\AutoSet6\public_html\tankv\application\models\board_model.php 422
ERROR - 2013-06-10 03:28:24 --> Severity: Notice  --> Undefined property: Board::$admin_write_level C:\AutoSet6\public_html\tankv\application\controllers\board.php 289
ERROR - 2013-06-10 03:28:26 --> Severity: Notice  --> Undefined index: comments C:\AutoSet6\public_html\tankv\application\models\board_model.php 422
ERROR - 2013-06-10 03:30:34 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 03:30:38 --> Severity: Notice  --> Undefined property: Board::$admin_write_level C:\AutoSet6\public_html\tankv\application\controllers\board.php 289
ERROR - 2013-06-10 03:30:41 --> Severity: Notice  --> Undefined property: Board::$admin_write_level C:\AutoSet6\public_html\tankv\application\controllers\board.php 289
ERROR - 2013-06-10 03:30:43 --> Severity: Notice  --> Undefined property: Board::$admin_write_level C:\AutoSet6\public_html\tankv\application\controllers\board.php 289
ERROR - 2013-06-10 03:40:57 --> Severity: Notice  --> Undefined property: Board::$admin_write_level C:\AutoSet6\public_html\tankv\application\controllers\board.php 316
ERROR - 2013-06-10 03:41:34 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 03:41:48 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 03:41:59 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 03:42:12 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 03:42:20 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 03:42:28 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 03:42:54 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 03:43:00 --> Severity: Notice  --> Undefined property: Board::$admin_write_level C:\AutoSet6\public_html\tankv\application\controllers\board.php 289
ERROR - 2013-06-10 03:43:03 --> Severity: Notice  --> Undefined property: Board::$admin_write_level C:\AutoSet6\public_html\tankv\application\controllers\board.php 289
ERROR - 2013-06-10 03:43:05 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 03:43:13 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 03:43:59 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:44:02 --> Severity: Notice  --> Undefined variable: board_skin C:\AutoSet6\public_html\tankv\application\views\admin\board_write_form_view.php 35
ERROR - 2013-06-10 03:44:03 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:44:07 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:44:16 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:44:44 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:44:49 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:44:57 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:45:01 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:45:19 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:45:59 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:46:08 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:46:22 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:46:46 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:46:58 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:47:03 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:47:16 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:47:19 --> Severity: Notice  --> Undefined index: $users_email_activation C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 22
ERROR - 2013-06-10 03:47:19 --> Severity: Notice  --> Undefined variable: users_register1 C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 93
ERROR - 2013-06-10 03:47:19 --> Severity: Notice  --> Undefined variable: users_register2 C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 97
ERROR - 2013-06-10 03:47:25 --> Severity: Notice  --> Undefined variable: activated C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 63
ERROR - 2013-06-10 03:47:25 --> Severity: Notice  --> Undefined variable: banned C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 71
ERROR - 2013-06-10 03:47:25 --> Severity: Notice  --> Undefined variable: users_out C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 79
ERROR - 2013-06-10 03:47:25 --> Severity: Notice  --> Undefined variable: level C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 95
ERROR - 2013-06-10 03:47:25 --> Severity: Notice  --> Undefined variable: address1 C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 119
ERROR - 2013-06-10 03:47:25 --> Severity: Notice  --> Undefined variable: sex C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 127
ERROR - 2013-06-10 03:47:25 --> Severity: Notice  --> Undefined variable: created C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 130
ERROR - 2013-06-10 03:47:25 --> Severity: Notice  --> Undefined variable: birthday C:\AutoSet6\public_html\tankv\application\views\admin\member_list_view.php 133
ERROR - 2013-06-10 03:47:50 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:49:29 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 03:49:39 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 03:52:01 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 03:52:03 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:53:08 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:53:12 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-10 03:53:13 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\send_list_view.php 46
ERROR - 2013-06-10 03:53:14 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:53:16 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-10 03:53:18 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\send_list_view.php 46
ERROR - 2013-06-10 03:53:19 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 03:53:22 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\send_list_view.php 46
ERROR - 2013-06-10 03:55:03 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-10 03:55:05 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\send_list_view.php 46
ERROR - 2013-06-10 03:55:18 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\send_list_view.php 46
ERROR - 2013-06-10 03:55:20 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-10 03:55:21 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\send_list_view.php 46
ERROR - 2013-06-10 03:55:29 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-10 03:55:31 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\send_list_view.php 46
ERROR - 2013-06-10 04:06:54 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 04:07:02 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 04:07:07 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 04:07:12 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 04:07:14 --> Severity: Notice  --> Undefined property: CI_Loader::$admin_read_level C:\AutoSet6\public_html\tankv\layouts\main\default2\main_foot_layout.php 45
ERROR - 2013-06-10 04:07:19 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 04:07:23 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 04:07:24 --> Severity: Notice  --> Undefined property: CI_Loader::$admin_read_level C:\AutoSet6\public_html\tankv\layouts\main\default3\main_foot_layout.php 45
ERROR - 2013-06-10 04:07:33 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 04:07:41 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 04:07:49 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 04:07:54 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 04:08:03 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 04:08:04 --> Severity: Notice  --> Undefined property: CI_Loader::$admin_read_level C:\AutoSet6\public_html\tankv\layouts\main\default2\main_foot_layout.php 45
ERROR - 2013-06-10 04:08:17 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 04:08:25 --> Severity: Notice  --> Undefined property: CI_Loader::$admin_read_level C:\AutoSet6\public_html\tankv\layouts\main\default2\main_foot_layout.php 45
ERROR - 2013-06-10 04:08:39 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 04:08:54 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 04:08:55 --> Severity: Notice  --> Undefined property: CI_Loader::$admin_read_level C:\AutoSet6\public_html\tankv\layouts\main\default2\main_foot_layout.php 45
ERROR - 2013-06-10 04:08:56 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 04:09:01 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 04:09:04 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 04:09:07 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 04:10:30 --> Severity: Warning  --> include(./layouts/main/default2/main_top_layout.php): failed to open stream: No such file or directory C:\AutoSet6\public_html\tankv\application\views\main_top_view.php 4
ERROR - 2013-06-10 04:10:30 --> Severity: Warning  --> include(./layouts/main/default2/main_top_layout.php): failed to open stream: No such file or directory C:\AutoSet6\public_html\tankv\application\views\main_top_view.php 4
ERROR - 2013-06-10 04:10:30 --> Severity: Warning  --> include(): Failed opening './layouts/main/default2/main_top_layout.php' for inclusion (include_path='.') C:\AutoSet6\public_html\tankv\application\views\main_top_view.php 4
ERROR - 2013-06-10 04:10:30 --> Severity: Warning  --> include(./skin/main/default2/main_skin.php): failed to open stream: No such file or directory C:\AutoSet6\public_html\tankv\application\views\main_view.php 4
ERROR - 2013-06-10 04:10:30 --> Severity: Warning  --> include(./skin/main/default2/main_skin.php): failed to open stream: No such file or directory C:\AutoSet6\public_html\tankv\application\views\main_view.php 4
ERROR - 2013-06-10 04:10:30 --> Severity: Warning  --> include(): Failed opening './skin/main/default2/main_skin.php' for inclusion (include_path='.') C:\AutoSet6\public_html\tankv\application\views\main_view.php 4
ERROR - 2013-06-10 04:10:30 --> Severity: Warning  --> include(./layouts/main/default2/main_foot_layout.php): failed to open stream: No such file or directory C:\AutoSet6\public_html\tankv\application\views\main_foot_view.php 4
ERROR - 2013-06-10 04:10:30 --> Severity: Warning  --> include(./layouts/main/default2/main_foot_layout.php): failed to open stream: No such file or directory C:\AutoSet6\public_html\tankv\application\views\main_foot_view.php 4
ERROR - 2013-06-10 04:10:30 --> Severity: Warning  --> include(): Failed opening './layouts/main/default2/main_foot_layout.php' for inclusion (include_path='.') C:\AutoSet6\public_html\tankv\application\views\main_foot_view.php 4
ERROR - 2013-06-10 04:10:32 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 04:10:34 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 04:10:42 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 04:10:44 --> Severity: Notice  --> Undefined property: CI_Loader::$admin_read_level C:\AutoSet6\public_html\tankv\layouts\main\default1\main_foot_layout.php 45
ERROR - 2013-06-10 04:12:00 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 04:12:04 --> Severity: Notice  --> Undefined property: CI_Loader::$admin_read_level C:\AutoSet6\public_html\tankv\layouts\main\default1\main_foot_layout.php 45
ERROR - 2013-06-10 04:12:08 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 04:12:10 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\write_form_skin.php 35
ERROR - 2013-06-10 04:12:10 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 04:12:29 --> Severity: Warning  --> mkdir(): File exists C:\AutoSet6\public_html\tankv\application\models\board_model.php 84
ERROR - 2013-06-10 04:12:29 --> Severity: Warning  --> strpos(): Empty delimiter C:\AutoSet6\public_html\tankv\application\models\board_model.php 109
ERROR - 2013-06-10 04:12:29 --> Severity: Notice  --> Undefined property: Board::$admin_mail_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 118
ERROR - 2013-06-10 04:12:29 --> Severity: Notice  --> Undefined property: Board::$board_mobile_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 125
ERROR - 2013-06-10 04:12:29 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 04:12:44 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 04:14:39 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 04:16:04 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 04:16:35 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 04:16:39 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 04:16:49 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 04:17:00 --> Severity: Notice  --> Undefined property: CI_Loader::$admin_read_level C:\AutoSet6\public_html\tankv\layouts\main\default1\main_foot_layout.php 45
ERROR - 2013-06-10 04:17:13 --> Severity: Notice  --> Undefined property: CI_Loader::$admin_read_level C:\AutoSet6\public_html\tankv\layouts\main\default1\main_foot_layout.php 45
ERROR - 2013-06-10 04:18:06 --> Severity: Notice  --> Undefined property: CI_Loader::$admin_read_level C:\AutoSet6\public_html\tankv\layouts\main\default1\main_foot_layout.php 45
ERROR - 2013-06-10 04:18:54 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 04:19:00 --> Severity: Notice  --> Undefined property: CI_Loader::$admin_read_level C:\AutoSet6\public_html\tankv\layouts\main\default1\main_foot_layout.php 45
ERROR - 2013-06-10 04:23:19 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 04:23:33 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 04:23:39 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 04:24:12 --> 404 Page Not Found --> editor
ERROR - 2013-06-10 04:24:54 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-10 04:24:54 --> Severity: Notice  --> Undefined index: ip_address C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-10 04:24:54 --> Severity: Notice  --> Undefined index: user_agent C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-10 04:24:54 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-10 04:24:54 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 288
ERROR - 2013-06-10 04:24:54 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 289
ERROR - 2013-06-10 04:27:06 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 04:27:21 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 04:27:25 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 04:27:40 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
ERROR - 2013-06-10 04:27:43 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\boot_smart\list_skin.php 47
