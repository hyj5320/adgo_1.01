<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2013-06-08 20:43:23 --> Query error: Table 'kkboard.galley' doesn't exist
ERROR - 2013-06-08 20:44:57 --> Query error: Table 'kkboard.galley' doesn't exist
ERROR - 2013-06-08 20:44:59 --> Query error: Table 'kkboard.galley' doesn't exist
ERROR - 2013-06-08 20:45:47 --> Query error: Table 'kkboard.galley' doesn't exist
ERROR - 2013-06-08 20:45:49 --> Query error: Table 'kkboard.galley' doesn't exist
ERROR - 2013-06-08 20:48:58 --> Severity: Notice  --> Undefined variable: result C:\AutoSet6\public_html\board_tank\skin\main\bootstrap\main_skin.php 20
ERROR - 2013-06-08 20:48:58 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\AutoSet6\public_html\board_tank\skin\main\bootstrap\main_skin.php 20
ERROR - 2013-06-08 20:48:58 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:49:20 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:49:20 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 20:49:23 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:49:35 --> Severity: Notice  --> Undefined variable: board_skin C:\AutoSet6\public_html\board_tank\application\views\admin\board_write_form_view.php 35
ERROR - 2013-06-08 20:49:35 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:49:35 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 20:51:04 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:51:04 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:51:48 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:52:01 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:52:08 --> Severity: Notice  --> Undefined index: view_article C:\AutoSet6\public_html\board_tank\application\controllers\board.php 77
ERROR - 2013-06-08 20:52:08 --> Query error: Table 'kkboard.galley' doesn't exist
ERROR - 2013-06-08 20:52:24 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:52:26 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:52:49 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:52:51 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:53:41 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:53:43 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:53:43 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 20:54:01 --> Severity: Warning  --> mkdir(): File exists C:\AutoSet6\public_html\board_tank\application\models\board_model.php 84
ERROR - 2013-06-08 20:54:01 --> Severity: Warning  --> unlink(./file/board/notice/): Permission denied C:\AutoSet6\public_html\board_tank\include\upload\upload.php 17
ERROR - 2013-06-08 20:54:01 --> Severity: Warning  --> strpos(): Empty delimiter C:\AutoSet6\public_html\board_tank\application\models\board_model.php 109
ERROR - 2013-06-08 20:54:01 --> Severity: Notice  --> Undefined property: Board::$admin_mail_receive C:\AutoSet6\public_html\board_tank\application\controllers\board.php 118
ERROR - 2013-06-08 20:54:01 --> Severity: Notice  --> Undefined property: Board::$board_mobile_receive C:\AutoSet6\public_html\board_tank\application\controllers\board.php 125
ERROR - 2013-06-08 20:54:02 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:54:02 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:54:09 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:54:23 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:54:23 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 20:54:33 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:54:36 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:54:38 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:54:39 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 20:54:46 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:54:46 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:54:46 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 20:54:48 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:54:49 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:54:51 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:55:33 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:55:34 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 20:55:38 --> Severity: Notice  --> Undefined variable: activated C:\AutoSet6\public_html\board_tank\application\views\admin\member_list_view.php 63
ERROR - 2013-06-08 20:55:38 --> Severity: Notice  --> Undefined variable: banned C:\AutoSet6\public_html\board_tank\application\views\admin\member_list_view.php 71
ERROR - 2013-06-08 20:55:38 --> Severity: Notice  --> Undefined variable: users_out C:\AutoSet6\public_html\board_tank\application\views\admin\member_list_view.php 79
ERROR - 2013-06-08 20:55:38 --> Severity: Notice  --> Undefined variable: level C:\AutoSet6\public_html\board_tank\application\views\admin\member_list_view.php 95
ERROR - 2013-06-08 20:55:38 --> Severity: Notice  --> Undefined variable: address1 C:\AutoSet6\public_html\board_tank\application\views\admin\member_list_view.php 119
ERROR - 2013-06-08 20:55:38 --> Severity: Notice  --> Undefined variable: sex C:\AutoSet6\public_html\board_tank\application\views\admin\member_list_view.php 127
ERROR - 2013-06-08 20:55:38 --> Severity: Notice  --> Undefined variable: created C:\AutoSet6\public_html\board_tank\application\views\admin\member_list_view.php 130
ERROR - 2013-06-08 20:55:38 --> Severity: Notice  --> Undefined variable: birthday C:\AutoSet6\public_html\board_tank\application\views\admin\member_list_view.php 133
ERROR - 2013-06-08 20:55:38 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:55:40 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:55:52 --> Severity: Warning  --> unlink(./file/users/1369940612_ci_logo.gif): No such file or directory C:\AutoSet6\public_html\board_tank\include\upload\upload.php 17
ERROR - 2013-06-08 20:55:52 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:55:52 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:55:54 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:55:56 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:55:57 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:56:13 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:56:13 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 20:56:28 --> Severity: Notice  --> Undefined variable: activated C:\AutoSet6\public_html\board_tank\application\views\admin\member_list_view.php 63
ERROR - 2013-06-08 20:56:28 --> Severity: Notice  --> Undefined variable: banned C:\AutoSet6\public_html\board_tank\application\views\admin\member_list_view.php 71
ERROR - 2013-06-08 20:56:28 --> Severity: Notice  --> Undefined variable: users_out C:\AutoSet6\public_html\board_tank\application\views\admin\member_list_view.php 79
ERROR - 2013-06-08 20:56:28 --> Severity: Notice  --> Undefined variable: level C:\AutoSet6\public_html\board_tank\application\views\admin\member_list_view.php 95
ERROR - 2013-06-08 20:56:28 --> Severity: Notice  --> Undefined variable: address1 C:\AutoSet6\public_html\board_tank\application\views\admin\member_list_view.php 119
ERROR - 2013-06-08 20:56:28 --> Severity: Notice  --> Undefined variable: sex C:\AutoSet6\public_html\board_tank\application\views\admin\member_list_view.php 127
ERROR - 2013-06-08 20:56:28 --> Severity: Notice  --> Undefined variable: created C:\AutoSet6\public_html\board_tank\application\views\admin\member_list_view.php 130
ERROR - 2013-06-08 20:56:28 --> Severity: Notice  --> Undefined variable: birthday C:\AutoSet6\public_html\board_tank\application\views\admin\member_list_view.php 133
ERROR - 2013-06-08 20:56:28 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:56:31 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:56:57 --> Severity: Notice  --> Undefined variable: activated C:\AutoSet6\public_html\board_tank\application\views\admin\member_list_view.php 63
ERROR - 2013-06-08 20:56:57 --> Severity: Notice  --> Undefined variable: banned C:\AutoSet6\public_html\board_tank\application\views\admin\member_list_view.php 71
ERROR - 2013-06-08 20:56:57 --> Severity: Notice  --> Undefined variable: users_out C:\AutoSet6\public_html\board_tank\application\views\admin\member_list_view.php 79
ERROR - 2013-06-08 20:56:57 --> Severity: Notice  --> Undefined variable: level C:\AutoSet6\public_html\board_tank\application\views\admin\member_list_view.php 95
ERROR - 2013-06-08 20:56:57 --> Severity: Notice  --> Undefined variable: address1 C:\AutoSet6\public_html\board_tank\application\views\admin\member_list_view.php 119
ERROR - 2013-06-08 20:56:57 --> Severity: Notice  --> Undefined variable: sex C:\AutoSet6\public_html\board_tank\application\views\admin\member_list_view.php 127
ERROR - 2013-06-08 20:56:57 --> Severity: Notice  --> Undefined variable: created C:\AutoSet6\public_html\board_tank\application\views\admin\member_list_view.php 130
ERROR - 2013-06-08 20:56:57 --> Severity: Notice  --> Undefined variable: birthday C:\AutoSet6\public_html\board_tank\application\views\admin\member_list_view.php 133
ERROR - 2013-06-08 20:57:01 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:57:02 --> Query error: Table 'kkboard.galley' doesn't exist
ERROR - 2013-06-08 20:57:07 --> Query error: Table 'kkboard.galley' doesn't exist
ERROR - 2013-06-08 20:57:10 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:57:12 --> 404 Page Not Found --> file
ERROR - 2013-06-08 20:57:43 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\board_tank\system\libraries\Session.php 272
ERROR - 2013-06-08 20:57:43 --> Severity: Notice  --> Undefined index: ip_address C:\AutoSet6\public_html\board_tank\system\libraries\Session.php 272
ERROR - 2013-06-08 20:57:43 --> Severity: Notice  --> Undefined index: user_agent C:\AutoSet6\public_html\board_tank\system\libraries\Session.php 272
ERROR - 2013-06-08 20:57:43 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\board_tank\system\libraries\Session.php 272
ERROR - 2013-06-08 20:57:43 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\board_tank\system\libraries\Session.php 288
ERROR - 2013-06-08 20:57:43 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\board_tank\system\libraries\Session.php 289
ERROR - 2013-06-08 20:59:12 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 20:59:22 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 20:59:32 --> Severity: Warning  --> strpos(): Empty delimiter C:\AutoSet6\public_html\board_tank\application\models\board_model.php 109
ERROR - 2013-06-08 20:59:32 --> Severity: Notice  --> Undefined property: Board::$admin_mail_receive C:\AutoSet6\public_html\board_tank\application\controllers\board.php 118
ERROR - 2013-06-08 20:59:32 --> Severity: Notice  --> Undefined property: Board::$board_mobile_receive C:\AutoSet6\public_html\board_tank\application\controllers\board.php 125
ERROR - 2013-06-08 20:59:34 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 20:59:45 --> Severity: Warning  --> strpos(): Empty delimiter C:\AutoSet6\public_html\board_tank\application\models\board_model.php 109
ERROR - 2013-06-08 20:59:45 --> Severity: Notice  --> Undefined property: Board::$admin_mail_receive C:\AutoSet6\public_html\board_tank\application\controllers\board.php 118
ERROR - 2013-06-08 20:59:45 --> Severity: Notice  --> Undefined property: Board::$board_mobile_receive C:\AutoSet6\public_html\board_tank\application\controllers\board.php 125
ERROR - 2013-06-08 20:59:48 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 20:59:51 --> Severity: Warning  --> strpos(): Empty delimiter C:\AutoSet6\public_html\board_tank\application\models\board_model.php 109
ERROR - 2013-06-08 20:59:51 --> Severity: Notice  --> Undefined property: Board::$admin_mail_receive C:\AutoSet6\public_html\board_tank\application\controllers\board.php 118
ERROR - 2013-06-08 20:59:51 --> Severity: Notice  --> Undefined property: Board::$board_mobile_receive C:\AutoSet6\public_html\board_tank\application\controllers\board.php 125
ERROR - 2013-06-08 20:59:54 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 20:59:58 --> Severity: Warning  --> strpos(): Empty delimiter C:\AutoSet6\public_html\board_tank\application\models\board_model.php 109
ERROR - 2013-06-08 20:59:58 --> Severity: Notice  --> Undefined property: Board::$admin_mail_receive C:\AutoSet6\public_html\board_tank\application\controllers\board.php 118
ERROR - 2013-06-08 20:59:58 --> Severity: Notice  --> Undefined property: Board::$board_mobile_receive C:\AutoSet6\public_html\board_tank\application\controllers\board.php 125
ERROR - 2013-06-08 21:00:00 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:00:04 --> Severity: Warning  --> strpos(): Empty delimiter C:\AutoSet6\public_html\board_tank\application\models\board_model.php 109
ERROR - 2013-06-08 21:00:04 --> Severity: Notice  --> Undefined property: Board::$admin_mail_receive C:\AutoSet6\public_html\board_tank\application\controllers\board.php 118
ERROR - 2013-06-08 21:00:04 --> Severity: Notice  --> Undefined property: Board::$board_mobile_receive C:\AutoSet6\public_html\board_tank\application\controllers\board.php 125
ERROR - 2013-06-08 21:00:06 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:00:09 --> Severity: Warning  --> strpos(): Empty delimiter C:\AutoSet6\public_html\board_tank\application\models\board_model.php 109
ERROR - 2013-06-08 21:00:09 --> Severity: Notice  --> Undefined property: Board::$admin_mail_receive C:\AutoSet6\public_html\board_tank\application\controllers\board.php 118
ERROR - 2013-06-08 21:00:09 --> Severity: Notice  --> Undefined property: Board::$board_mobile_receive C:\AutoSet6\public_html\board_tank\application\controllers\board.php 125
ERROR - 2013-06-08 21:00:11 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:00:15 --> Severity: Warning  --> strpos(): Empty delimiter C:\AutoSet6\public_html\board_tank\application\models\board_model.php 109
ERROR - 2013-06-08 21:00:15 --> Severity: Notice  --> Undefined property: Board::$admin_mail_receive C:\AutoSet6\public_html\board_tank\application\controllers\board.php 118
ERROR - 2013-06-08 21:00:15 --> Severity: Notice  --> Undefined property: Board::$board_mobile_receive C:\AutoSet6\public_html\board_tank\application\controllers\board.php 125
ERROR - 2013-06-08 21:00:17 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:00:20 --> Severity: Warning  --> strpos(): Empty delimiter C:\AutoSet6\public_html\board_tank\application\models\board_model.php 109
ERROR - 2013-06-08 21:00:20 --> Severity: Notice  --> Undefined property: Board::$admin_mail_receive C:\AutoSet6\public_html\board_tank\application\controllers\board.php 118
ERROR - 2013-06-08 21:00:20 --> Severity: Notice  --> Undefined property: Board::$board_mobile_receive C:\AutoSet6\public_html\board_tank\application\controllers\board.php 125
ERROR - 2013-06-08 21:00:22 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:00:26 --> Severity: Warning  --> strpos(): Empty delimiter C:\AutoSet6\public_html\board_tank\application\models\board_model.php 109
ERROR - 2013-06-08 21:00:26 --> Severity: Notice  --> Undefined property: Board::$admin_mail_receive C:\AutoSet6\public_html\board_tank\application\controllers\board.php 118
ERROR - 2013-06-08 21:00:26 --> Severity: Notice  --> Undefined property: Board::$board_mobile_receive C:\AutoSet6\public_html\board_tank\application\controllers\board.php 125
ERROR - 2013-06-08 21:03:07 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:03:10 --> Severity: Notice  --> Undefined index: view_article C:\AutoSet6\public_html\tankv\application\controllers\board.php 77
ERROR - 2013-06-08 21:03:10 --> Query error: Table 'kkboard.manual' doesn't exist
ERROR - 2013-06-08 21:03:51 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:03:58 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\memo\receive_list_view.php 47
ERROR - 2013-06-08 21:04:26 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:04:33 --> Severity: Warning  --> strpos(): Empty delimiter C:\AutoSet6\public_html\tankv\application\models\board_model.php 109
ERROR - 2013-06-08 21:04:33 --> Severity: Notice  --> Undefined property: Board::$admin_mail_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 118
ERROR - 2013-06-08 21:04:33 --> Severity: Notice  --> Undefined property: Board::$board_mobile_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 125
ERROR - 2013-06-08 21:04:35 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:04:43 --> Severity: Warning  --> unlink(./file/board/notice/): Permission denied C:\AutoSet6\public_html\tankv\include\upload\upload.php 17
ERROR - 2013-06-08 21:04:43 --> Severity: Warning  --> strpos(): Empty delimiter C:\AutoSet6\public_html\tankv\application\models\board_model.php 109
ERROR - 2013-06-08 21:04:43 --> Severity: Notice  --> Undefined property: Board::$admin_mail_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 118
ERROR - 2013-06-08 21:04:43 --> Severity: Notice  --> Undefined property: Board::$board_mobile_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 125
ERROR - 2013-06-08 21:05:14 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:05:30 --> Severity: Warning  --> unlink(./file/board/notice/): Permission denied C:\AutoSet6\public_html\tankv\include\upload\upload.php 17
ERROR - 2013-06-08 21:05:30 --> Severity: Warning  --> strpos(): Empty delimiter C:\AutoSet6\public_html\tankv\application\models\board_model.php 109
ERROR - 2013-06-08 21:05:30 --> Severity: Notice  --> Undefined property: Board::$admin_mail_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 118
ERROR - 2013-06-08 21:05:30 --> Severity: Notice  --> Undefined property: Board::$board_mobile_receive C:\AutoSet6\public_html\tankv\application\controllers\board.php 125
ERROR - 2013-06-08 21:05:44 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:09:30 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:10:07 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:11:35 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:16:40 --> Severity: Notice  --> Use of undefined constant PHPASS_HASH_STRENGTH - assumed 'PHPASS_HASH_STRENGTH' C:\AutoSet6\public_html\tankv\application\controllers\auth.php 418
ERROR - 2013-06-08 21:16:40 --> Severity: Notice  --> Use of undefined constant PHPASS_HASH_PORTABLE - assumed 'PHPASS_HASH_PORTABLE' C:\AutoSet6\public_html\tankv\application\controllers\auth.php 418
ERROR - 2013-06-08 21:16:40 --> Severity: Warning  --> fopen(/dev/urandom): failed to open stream: No such file or directory C:\AutoSet6\public_html\tankv\phpass-0.1\PasswordHash.php 49
ERROR - 2013-06-08 21:17:31 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:17:41 --> Severity: Notice  --> Undefined variable: board_skin C:\AutoSet6\public_html\tankv\application\views\admin\board_write_form_view.php 35
ERROR - 2013-06-08 21:17:42 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:18:31 --> Severity: Notice  --> Undefined variable: board_skin C:\AutoSet6\public_html\tankv\application\views\admin\board_write_form_view.php 35
ERROR - 2013-06-08 21:18:32 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:18:33 --> Severity: Notice  --> Undefined index: view_article C:\AutoSet6\public_html\tankv\application\controllers\board.php 77
ERROR - 2013-06-08 21:18:33 --> Query error: Table 'kkboard.manual' doesn't exist
ERROR - 2013-06-08 21:19:04 --> Severity: Notice  --> Undefined variable: board_skin C:\AutoSet6\public_html\tankv\application\views\admin\board_write_form_view.php 35
ERROR - 2013-06-08 21:19:04 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:19:22 --> Severity: Notice  --> Undefined variable: board_skin C:\AutoSet6\public_html\tankv\application\views\admin\board_write_form_view.php 35
ERROR - 2013-06-08 21:19:22 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:19:51 --> Severity: Notice  --> Undefined variable: board_skin C:\AutoSet6\public_html\tankv\application\views\admin\board_write_form_view.php 35
ERROR - 2013-06-08 21:19:51 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:20:53 --> Severity: Notice  --> Undefined variable: category C:\AutoSet6\public_html\tankv\skin\board\bootstrap\list_skin.php 46
ERROR - 2013-06-08 21:23:48 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:24:26 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:24:52 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:25:54 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:26:22 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:27:00 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:27:01 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:27:01 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:27:51 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:30:18 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:30:59 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:31:01 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:31:23 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:31:44 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:31:51 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:32:21 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:32:52 --> Severity: Warning  --> unlink(./file/banner/): Permission denied C:\AutoSet6\public_html\tankv\include\upload\upload.php 17
ERROR - 2013-06-08 21:33:30 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:34:12 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:34:21 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:35:09 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:35:17 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:35:23 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:35:38 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:35:42 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:36:01 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:36:05 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:36:10 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:36:21 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:36:51 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:37:06 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:37:23 --> Severity: Warning  --> unlink(./file/memo/memo/): Permission denied C:\AutoSet6\public_html\tankv\include\upload\upload.php 17
ERROR - 2013-06-08 21:37:23 --> Severity: Notice  --> Undefined property: Admin_memo::$admin_mail_receive C:\AutoSet6\public_html\tankv\application\controllers\admin\admin_memo.php 141
ERROR - 2013-06-08 21:37:23 --> Severity: Notice  --> Undefined property: Admin_memo::$board_mobile_receive C:\AutoSet6\public_html\tankv\application\controllers\admin\admin_memo.php 148
ERROR - 2013-06-08 21:37:23 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_send_list_view.php 36
ERROR - 2013-06-08 21:37:26 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_send_list_view.php 36
ERROR - 2013-06-08 21:37:28 --> Severity: Notice  --> Trying to get property of non-object C:\AutoSet6\public_html\tankv\application\views\admin\memo_receive_list_view.php 36
ERROR - 2013-06-08 21:37:30 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:37:36 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:39:09 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:39:42 --> Severity: Notice  --> Undefined variable: users_sms C:\AutoSet6\public_html\tankv\application\views\admin\sms_read_view.php 30
ERROR - 2013-06-08 21:40:29 --> Severity: Warning  --> mkdir(): File exists C:\AutoSet6\public_html\tankv\application\controllers\admin\site_config.php 87
ERROR - 2013-06-08 21:40:29 --> Severity: Warning  --> mkdir(): File exists C:\AutoSet6\public_html\tankv\application\controllers\admin\site_config.php 88
ERROR - 2013-06-08 21:40:29 --> Severity: Warning  --> mkdir(): File exists C:\AutoSet6\public_html\tankv\application\controllers\admin\site_config.php 89
ERROR - 2013-06-08 21:40:29 --> Severity: Warning  --> mkdir(): File exists C:\AutoSet6\public_html\tankv\application\controllers\admin\site_config.php 90
ERROR - 2013-06-08 21:40:29 --> Severity: Notice  --> Use of undefined constant site - assumed 'site' C:\AutoSet6\public_html\tankv\application\controllers\admin\site_config.php 97
ERROR - 2013-06-08 21:40:29 --> Severity: Notice  --> Use of undefined constant site - assumed 'site' C:\AutoSet6\public_html\tankv\application\controllers\admin\site_config.php 99
ERROR - 2013-06-08 21:46:23 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-08 21:46:23 --> Severity: Notice  --> Undefined index: ip_address C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-08 21:46:23 --> Severity: Notice  --> Undefined index: user_agent C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-08 21:46:23 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-08 21:46:23 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 288
ERROR - 2013-06-08 21:46:23 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 289
ERROR - 2013-06-08 21:47:53 --> Severity: Warning  --> fopen(/dev/urandom): failed to open stream: No such file or directory C:\AutoSet6\public_html\tankv\phpass-0.1\PasswordHash.php 49
ERROR - 2013-06-08 21:47:53 --> Query error: Incorrect integer value: '' for column 're_email' at row 1
ERROR - 2013-06-08 21:49:50 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 21:49:54 --> Severity: Notice  --> Undefined variable: site_logo C:\AutoSet6\public_html\tankv\application\views\admin\top_view.php 61
ERROR - 2013-06-08 22:08:14 --> Severity: Notice  --> Undefined variable: site_logo C:\AutoSet6\public_html\tankv\application\views\admin\top_view.php 61
ERROR - 2013-06-08 22:08:53 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 22:08:55 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 22:09:21 --> Severity: Notice  --> Undefined index: $users_email_activation C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 22
ERROR - 2013-06-08 22:09:21 --> Severity: Notice  --> Undefined variable: users_register1 C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 93
ERROR - 2013-06-08 22:09:21 --> Severity: Notice  --> Undefined variable: users_register2 C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 97
ERROR - 2013-06-08 22:09:30 --> Severity: Notice  --> Undefined variable: site_logo C:\AutoSet6\public_html\tankv\application\views\admin\top_view.php 61
ERROR - 2013-06-08 22:14:59 --> Severity: Notice  --> Undefined index: $users_email_activation C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 22
ERROR - 2013-06-08 22:14:59 --> Severity: Notice  --> Undefined variable: users_register1 C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 93
ERROR - 2013-06-08 22:14:59 --> Severity: Notice  --> Undefined variable: users_register2 C:\AutoSet6\public_html\tankv\application\views\admin\member_config_view.php 97
ERROR - 2013-06-08 22:16:14 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 22:19:41 --> Severity: Notice  --> Undefined variable: site_logo C:\AutoSet6\public_html\tankv\application\views\admin\top_view.php 61
ERROR - 2013-06-08 22:19:46 --> Severity: Notice  --> Undefined variable: site_logo C:\AutoSet6\public_html\tankv\application\views\admin\top_view.php 61
ERROR - 2013-06-08 22:20:02 --> Severity: Notice  --> Undefined variable: site_logo C:\AutoSet6\public_html\tankv\application\views\admin\top_view.php 61
ERROR - 2013-06-08 22:20:48 --> Severity: Notice  --> Undefined variable: site_logo C:\AutoSet6\public_html\tankv\application\views\admin\top_view.php 53
ERROR - 2013-06-08 22:20:48 --> Severity: Notice  --> Undefined variable: site_logo C:\AutoSet6\public_html\tankv\application\views\admin\top_view.php 61
ERROR - 2013-06-08 22:22:36 --> Severity: Notice  --> Undefined variable: site_logo C:\AutoSet6\public_html\tankv\application\views\admin\top_view.php 53
ERROR - 2013-06-08 22:22:36 --> Severity: Notice  --> Undefined variable: site_logo C:\AutoSet6\public_html\tankv\application\views\admin\top_view.php 61
ERROR - 2013-06-08 22:22:36 --> Severity: Notice  --> Undefined variable: retouch_date C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 1
ERROR - 2013-06-08 22:22:36 --> Severity: Notice  --> Undefined variable: kname C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 33
ERROR - 2013-06-08 22:22:36 --> Severity: Notice  --> Undefined variable: mobile C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 41
ERROR - 2013-06-08 22:22:36 --> Severity: Notice  --> Undefined variable: telephone C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 49
ERROR - 2013-06-08 22:22:36 --> Severity: Notice  --> Undefined variable: zip_address C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 57
ERROR - 2013-06-08 22:22:36 --> Severity: Notice  --> Undefined variable: homepage C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 65
ERROR - 2013-06-08 22:22:36 --> Severity: Notice  --> Undefined variable: birthday C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 73
ERROR - 2013-06-08 22:22:36 --> Severity: Notice  --> Undefined variable: sex C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 81
ERROR - 2013-06-08 22:22:36 --> Severity: Notice  --> Undefined variable: job C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 89
ERROR - 2013-06-08 22:22:55 --> Severity: Notice  --> Undefined variable: site_logo C:\AutoSet6\public_html\tankv\application\views\admin\top_view.php 60
ERROR - 2013-06-08 22:22:55 --> Severity: Notice  --> Undefined variable: retouch_date C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 1
ERROR - 2013-06-08 22:22:55 --> Severity: Notice  --> Undefined variable: kname C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 33
ERROR - 2013-06-08 22:22:55 --> Severity: Notice  --> Undefined variable: mobile C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 41
ERROR - 2013-06-08 22:22:55 --> Severity: Notice  --> Undefined variable: telephone C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 49
ERROR - 2013-06-08 22:22:55 --> Severity: Notice  --> Undefined variable: zip_address C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 57
ERROR - 2013-06-08 22:22:55 --> Severity: Notice  --> Undefined variable: homepage C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 65
ERROR - 2013-06-08 22:22:55 --> Severity: Notice  --> Undefined variable: birthday C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 73
ERROR - 2013-06-08 22:22:55 --> Severity: Notice  --> Undefined variable: sex C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 81
ERROR - 2013-06-08 22:22:55 --> Severity: Notice  --> Undefined variable: job C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 89
ERROR - 2013-06-08 22:27:41 --> Severity: Notice  --> Undefined index: kname C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 33
ERROR - 2013-06-08 22:28:44 --> Severity: Notice  --> Undefined index: kname C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 33
ERROR - 2013-06-08 22:28:44 --> Severity: Notice  --> Undefined index: mobile C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 41
ERROR - 2013-06-08 22:28:44 --> Severity: Notice  --> Undefined index: telephone C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 49
ERROR - 2013-06-08 22:29:47 --> Severity: Notice  --> Undefined index: kname C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 33
ERROR - 2013-06-08 22:29:47 --> Severity: Notice  --> Undefined index: mobile C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 41
ERROR - 2013-06-08 22:29:47 --> Severity: Notice  --> Undefined index: telephone C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 49
ERROR - 2013-06-08 22:29:47 --> Severity: Notice  --> Undefined index: zip_address C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 57
ERROR - 2013-06-08 22:29:47 --> Severity: Notice  --> Undefined index: homepage C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 65
ERROR - 2013-06-08 22:29:47 --> Severity: Notice  --> Undefined index: birthday C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 73
ERROR - 2013-06-08 22:29:47 --> Severity: Notice  --> Undefined index: sex C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 81
ERROR - 2013-06-08 22:29:47 --> Severity: Notice  --> Undefined index: job C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 89
ERROR - 2013-06-08 22:30:34 --> Severity: Notice  --> Undefined index: kname C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 33
ERROR - 2013-06-08 22:30:34 --> Severity: Notice  --> Undefined index: mobile C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 41
ERROR - 2013-06-08 22:30:34 --> Severity: Notice  --> Undefined index: telephone C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 49
ERROR - 2013-06-08 22:30:34 --> Severity: Notice  --> Undefined index: zip_address C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 57
ERROR - 2013-06-08 22:30:34 --> Severity: Notice  --> Undefined index: homepage C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 65
ERROR - 2013-06-08 22:30:34 --> Severity: Notice  --> Undefined index: birthday C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 73
ERROR - 2013-06-08 22:30:34 --> Severity: Notice  --> Undefined index: sex C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 81
ERROR - 2013-06-08 22:30:34 --> Severity: Notice  --> Undefined index: job C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 89
ERROR - 2013-06-08 22:31:00 --> Severity: Notice  --> Undefined index: kname C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 5
ERROR - 2013-06-08 22:31:00 --> Severity: Notice  --> Undefined index: kname C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 33
ERROR - 2013-06-08 22:31:00 --> Severity: Notice  --> Undefined index: mobile C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 41
ERROR - 2013-06-08 22:31:00 --> Severity: Notice  --> Undefined index: telephone C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 49
ERROR - 2013-06-08 22:31:00 --> Severity: Notice  --> Undefined index: zip_address C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 57
ERROR - 2013-06-08 22:31:00 --> Severity: Notice  --> Undefined index: homepage C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 65
ERROR - 2013-06-08 22:31:00 --> Severity: Notice  --> Undefined index: birthday C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 73
ERROR - 2013-06-08 22:31:00 --> Severity: Notice  --> Undefined index: sex C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 81
ERROR - 2013-06-08 22:31:00 --> Severity: Notice  --> Undefined index: job C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 89
ERROR - 2013-06-08 22:33:44 --> Severity: Notice  --> Undefined index: kname C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 5
ERROR - 2013-06-08 22:33:44 --> Severity: Notice  --> Undefined index: kname C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 33
ERROR - 2013-06-08 22:33:44 --> Severity: Notice  --> Undefined index: mobile C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 41
ERROR - 2013-06-08 22:33:44 --> Severity: Notice  --> Undefined index: telephone C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 49
ERROR - 2013-06-08 22:33:44 --> Severity: Notice  --> Undefined index: zip_address C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 57
ERROR - 2013-06-08 22:33:44 --> Severity: Notice  --> Undefined index: homepage C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 65
ERROR - 2013-06-08 22:33:44 --> Severity: Notice  --> Undefined index: birthday C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 73
ERROR - 2013-06-08 22:33:44 --> Severity: Notice  --> Undefined index: sex C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 81
ERROR - 2013-06-08 22:33:44 --> Severity: Notice  --> Undefined index: job C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 89
ERROR - 2013-06-08 22:33:45 --> Severity: Notice  --> Undefined index: kname C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 5
ERROR - 2013-06-08 22:33:45 --> Severity: Notice  --> Undefined index: kname C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 33
ERROR - 2013-06-08 22:33:45 --> Severity: Notice  --> Undefined index: mobile C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 41
ERROR - 2013-06-08 22:33:45 --> Severity: Notice  --> Undefined index: telephone C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 49
ERROR - 2013-06-08 22:33:45 --> Severity: Notice  --> Undefined index: zip_address C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 57
ERROR - 2013-06-08 22:33:45 --> Severity: Notice  --> Undefined index: homepage C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 65
ERROR - 2013-06-08 22:33:45 --> Severity: Notice  --> Undefined index: birthday C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 73
ERROR - 2013-06-08 22:33:45 --> Severity: Notice  --> Undefined index: sex C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 81
ERROR - 2013-06-08 22:33:45 --> Severity: Notice  --> Undefined index: job C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 89
ERROR - 2013-06-08 22:33:47 --> Severity: Notice  --> Undefined index: kname C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 5
ERROR - 2013-06-08 22:33:47 --> Severity: Notice  --> Undefined index: kname C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 33
ERROR - 2013-06-08 22:33:47 --> Severity: Notice  --> Undefined index: mobile C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 41
ERROR - 2013-06-08 22:33:47 --> Severity: Notice  --> Undefined index: telephone C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 49
ERROR - 2013-06-08 22:33:47 --> Severity: Notice  --> Undefined index: zip_address C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 57
ERROR - 2013-06-08 22:33:47 --> Severity: Notice  --> Undefined index: homepage C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 65
ERROR - 2013-06-08 22:33:47 --> Severity: Notice  --> Undefined index: birthday C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 73
ERROR - 2013-06-08 22:33:47 --> Severity: Notice  --> Undefined index: sex C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 81
ERROR - 2013-06-08 22:33:47 --> Severity: Notice  --> Undefined index: job C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 89
ERROR - 2013-06-08 22:33:47 --> Severity: Notice  --> Undefined index: kname C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 5
ERROR - 2013-06-08 22:33:47 --> Severity: Notice  --> Undefined index: kname C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 33
ERROR - 2013-06-08 22:33:47 --> Severity: Notice  --> Undefined index: mobile C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 41
ERROR - 2013-06-08 22:33:47 --> Severity: Notice  --> Undefined index: telephone C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 49
ERROR - 2013-06-08 22:33:47 --> Severity: Notice  --> Undefined index: zip_address C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 57
ERROR - 2013-06-08 22:33:47 --> Severity: Notice  --> Undefined index: homepage C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 65
ERROR - 2013-06-08 22:33:47 --> Severity: Notice  --> Undefined index: birthday C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 73
ERROR - 2013-06-08 22:33:47 --> Severity: Notice  --> Undefined index: sex C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 81
ERROR - 2013-06-08 22:33:47 --> Severity: Notice  --> Undefined index: job C:\AutoSet6\public_html\tankv\application\views\admin\member_join_form_view.php 89
ERROR - 2013-06-08 22:37:21 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-08 22:37:21 --> Severity: Notice  --> Undefined index: ip_address C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-08 22:37:21 --> Severity: Notice  --> Undefined index: user_agent C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-08 22:37:21 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-08 22:37:21 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 288
ERROR - 2013-06-08 22:37:21 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 289
ERROR - 2013-06-08 22:37:50 --> Severity: Warning  --> fopen(/dev/urandom): failed to open stream: No such file or directory C:\AutoSet6\public_html\tankv\phpass-0.1\PasswordHash.php 49
ERROR - 2013-06-08 22:37:51 --> Query error: Incorrect integer value: '' for column 're_email' at row 1
ERROR - 2013-06-08 22:54:07 --> Severity: Warning  --> fopen(/dev/urandom): failed to open stream: No such file or directory C:\AutoSet6\public_html\tankv\phpass-0.1\PasswordHash.php 49
ERROR - 2013-06-08 22:54:07 --> Query error: Incorrect integer value: '' for column 're_mobile' at row 1
ERROR - 2013-06-08 22:57:18 --> Severity: Warning  --> fopen(/dev/urandom): failed to open stream: No such file or directory C:\AutoSet6\public_html\tankv\phpass-0.1\PasswordHash.php 49
ERROR - 2013-06-08 22:57:18 --> Query error: Incorrect integer value: '' for column 're_mobile' at row 1
ERROR - 2013-06-08 23:30:06 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 23:39:02 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-08 23:39:02 --> Severity: Notice  --> Undefined index: ip_address C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-08 23:39:02 --> Severity: Notice  --> Undefined index: user_agent C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-08 23:39:02 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-08 23:39:02 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 288
ERROR - 2013-06-08 23:39:02 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 289
ERROR - 2013-06-08 23:39:23 --> Severity: Warning  --> fopen(/dev/urandom): failed to open stream: No such file or directory C:\AutoSet6\public_html\tankv\phpass-0.1\PasswordHash.php 49
ERROR - 2013-06-08 23:39:23 --> Query error: Incorrect integer value: '' for column 're_mobile' at row 1
ERROR - 2013-06-08 23:40:36 --> Severity: Warning  --> fopen(/dev/urandom): failed to open stream: No such file or directory C:\AutoSet6\public_html\tankv\phpass-0.1\PasswordHash.php 49
ERROR - 2013-06-08 23:40:36 --> Query error: Incorrect integer value: '' for column 're_mobile' at row 1
ERROR - 2013-06-08 23:42:13 --> Severity: Warning  --> fopen(/dev/urandom): failed to open stream: No such file or directory C:\AutoSet6\public_html\tankv\phpass-0.1\PasswordHash.php 49
ERROR - 2013-06-08 23:42:13 --> Query error: Incorrect integer value: '' for column 're_mobile' at row 1
ERROR - 2013-06-08 23:46:40 --> Severity: Notice  --> Use of undefined constant PHPASS_HASH_STRENGTH - assumed 'PHPASS_HASH_STRENGTH' C:\AutoSet6\public_html\tankv\application\controllers\auth.php 422
ERROR - 2013-06-08 23:46:40 --> Severity: Notice  --> Use of undefined constant PHPASS_HASH_PORTABLE - assumed 'PHPASS_HASH_PORTABLE' C:\AutoSet6\public_html\tankv\application\controllers\auth.php 422
ERROR - 2013-06-08 23:46:40 --> Severity: Warning  --> fopen(/dev/urandom): failed to open stream: No such file or directory C:\AutoSet6\public_html\tankv\phpass-0.1\PasswordHash.php 49
ERROR - 2013-06-08 23:48:33 --> 404 Page Not Found --> editor
ERROR - 2013-06-08 23:48:50 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-08 23:48:50 --> Severity: Notice  --> Undefined index: ip_address C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-08 23:48:50 --> Severity: Notice  --> Undefined index: user_agent C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-08 23:48:50 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 272
ERROR - 2013-06-08 23:48:50 --> Severity: Notice  --> Undefined index: session_id C:\AutoSet6\public_html\tankv\system\libraries\Session.php 288
ERROR - 2013-06-08 23:48:50 --> Severity: Notice  --> Undefined index: last_activity C:\AutoSet6\public_html\tankv\system\libraries\Session.php 289
ERROR - 2013-06-08 23:49:17 --> Severity: Warning  --> fopen(/dev/urandom): failed to open stream: No such file or directory C:\AutoSet6\public_html\tankv\phpass-0.1\PasswordHash.php 49
ERROR - 2013-06-08 23:49:17 --> Query error: Incorrect integer value: '' for column 're_mobile' at row 1
ERROR - 2013-06-08 23:57:43 --> Severity: Warning  --> fopen(/dev/urandom): failed to open stream: No such file or directory C:\AutoSet6\public_html\tankv\phpass-0.1\PasswordHash.php 49
