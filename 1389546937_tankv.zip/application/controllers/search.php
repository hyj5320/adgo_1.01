<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * @통합검색
 * @CodeIgniter 기반으로 제작
 * @CI포럼소스 참조함
 * @package	탱크V (www.tankv.com)
 * @author		김영균/꾸숑 (webse@nate.com)
 * @version		beta test
 * @license		MIT License
 * @2013.05.06 작성
 */
class Search extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('search_model');
		$this->load->model('admin/site_config_model');
		$this->load->model('admin/board_model');
		$this->load->helper(array('directory','common'));
		$this->seg_exp = segment_explode($this->uri->uri_string());
		//$this->output->enable_profiler(TRUE);//FALSE로 하면 미작동됨
	}

	//헤더, 푸터 자동삽입
	public function _remap($method)
	{
		$site=$this->site_config_model->site();
		$this->load->view('sub_top_view',$site);
		if( method_exists($this, $method) )
		{
			$this->{"{$method}"}();
		}
		$this->load->view('sub_foot_view');
	}


	//세그먼트 정리 및 리맵 추가 포럼 소스 참조 제작됨
	function index()
	{
		if( in_array('q', $this->seg_exp) )
		{
			$data['search_word'] = $search_word = urldecode($this->security->xss_clean(url_explode($this->seg_exp, 'q')));
			//주소에서 q 제거. 뷰에서 사용
			$this->seg_exp =  url_delete($this->seg_exp, 'q');
			$data['search_url'] = "q/".$search_word;
		}
		else
		{
			$data['search_word'] = $search_word = '';
			$data['search_url'] = '';
		}
		if( $search_word != '' )
		{
			$post = array('s_word'=>str_replace("'", "", $search_word));
		}
		else
		{
			$post = '';
		}
		$data['search_total'] = $total = $this->search_model->search_total($post);
		if($this->uri->segment(4) == 'page')
		{
			$data['page_account']=$page = 1;
		}
		else
		{
			//페이징
			if( in_array('page', $this->seg_exp) )
			{
				$data['page_account'] = $page = urldecode($this->security->xss_clean(url_explode($this->seg_exp, 'page')));
			}
			else
			{
				$data['page_account'] = $page = 1;
			}
		}
		$rp = 20; //리스트 갯수
		$limit = 9; //보여줄 페이지수
		$start = (($page-1) * $rp);

		//검색후 페이징처리위한..
		$this->url_seg = $this->seg_exp;
		$urls = implode('/', url_delete($this->url_seg, 'page'));
		$data['pagination_links'] = pagination($urls."/search/index/q/$search_word/page", paging($page,$rp,$total,$limit));
		$data['search_list'] = $this->search_model->search_list($start, $rp, $post);
		$this->load->view('board/search_view', $data);
	}
}