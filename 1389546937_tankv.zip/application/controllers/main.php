<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * @메인페이지
 * @CodeIgniter 기반으로 제작
 * @package	탱크V (www.tankv.com)
 * @author		김영균/꾸숑 (webse@nate.com)
 * @version		beta test
 * @license		MIT License
 * @2013.05.06 작성
 */
class Main extends CI_Controller
{
	function main(){
		parent::__construct();
		$this->load->model('admin/site_config_model');
		$this->load->model('main_model');
		$this->load->helper(array('form', 'url', 'directory','alert'));
		$this->load->library(array('tank_auth','form_validation'));
		//$this->output->enable_profiler(TRUE);//FALSE로 하면 미작동됨
	}

	//헤더, 푸터 자동삽입(2013.03.31)
	public function _remap($method)
	{
		$site=$this->site_config_model->site();
		$this->load->view('main_top_view',$site);
		if( method_exists($this, $method) )
		{
			$this->{"{$method}"}();
		}
		$this->load->view('main_foot_view');
	}

	function index(){
		$data['result'] = $this->main_model->index();
		$this->load->view('main_view',$data);
	}
}
