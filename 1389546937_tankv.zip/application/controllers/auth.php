<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Auth extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin/site_config_model');//사이트설정
		$this->load->model('admin/member_config_model');//회원관리 설정
		$this->load->model('admin/member_join_form_model');//회원가입 폼 설정
		$this->load->model('tank_auth/users');
		$this->load->model('admin/smss_model');//sms발송
		$this->load->config('tank_auth', TRUE);
		$this->load->helper(array('form', 'url', 'directory', 'alert'));
		$this->load->library(array('security', 'tank_auth', 'form_validation'));
		$this->lang->load('tank_auth');//$this->load->language('file_name')과 같음
		$this->output->enable_profiler(TRUE);//FALSE로 하면 미작동됨
	}

	//메세지가 있을시에 메세지를 출력하고 그렇지 않으면 기본 페이지로 이동
	function index()
	{
		if ($message = $this->session->flashdata('message'))
		{
			//alert($this->session->set_flashdata('message', $message));//컨트롤러에서는 한글이 깨짐
			$this->load->view('auth/general_message', array('message' => $message));
		}
		else
		{
			redirect('/auth/login/');
		}
	}

	//헤더, 푸터 자동삽입(2013.03.31)-포럼에서 _remap 검색
	public function _remap($method)
	{
		//소스없는 users_view.php를 만들어서 모델 불러옮
		if($this->uri->segment(2) != 'search_zip')
		{
			$users=$this->member_config_model->users();
			$this->load->view('users_view',$users);
			$site=$this->site_config_model->site();
			$this->load->view('sub_top_view',$site);
		}

		if( method_exists($this, $method) )
		{
			$this->{"{$method}"}();
		}

		if($this->uri->segment(2) != 'search_zip')
		{
			$this->load->view('sub_foot_view');
		}
	}

	//로그인
	function login()
	{
		// 로그인
		if ($this->tank_auth->is_logged_in()) {	
		// 관리자	
		if($this->session->userdata('level') ==10)
			redirect('');
		// 일반유저
		if($this->session->userdata('level') < 10)
		redirect('');
		// 로그인 성공시
		} elseif ($this->tank_auth->is_logged_in(FALSE)) {						// logged in, not activated
			redirect('/auth/send_again/');

		} else {
		//로그인 아이디 사용시
			$data['login_by_username'] = ($this->config->item('login_by_username', 'tank_auth') AND
					$this->config->item('use_username', 'tank_auth'));
			//로그인시 메일을 아이디로 사용시
			$data['login_by_email'] = $this->config->item('login_by_email', 'tank_auth');
			//로그인 폼검증
			$this->form_validation->set_rules('login', '아이디', 'trim|required|xss_clean');
			$this->form_validation->set_rules('password', '비밀번호', 'trim|required|xss_clean');
			$this->form_validation->set_rules('remember', '자동로그인', 'integer');
			//로그인 시도시?(Get login for counting attempts to login)
			if ($this->config->item('login_count_attempts', 'tank_auth') AND
					($login = $this->input->post('login'))) {
				$login = $this->security->xss_clean($login);
			} else {
				$login = '';
			}
			//로그인시 스팸방지 코드 사용시 폼검증
			$data['use_recaptcha'] = $this->config->item('use_recaptcha', 'tank_auth');
			if ($this->tank_auth->is_max_login_attempts_exceeded($login)) {
				if ($data['use_recaptcha'])
					$this->form_validation->set_rules('recaptcha_response_field', 'Confirmation Code', 'trim|xss_clean|required|callback__check_recaptcha');
				else
					$this->form_validation->set_rules('captcha', 'Confirmation Code', 'trim|xss_clean|required|callback__check_captcha');
			}
			$data['errors'] = array();
			//폼검증 완료시 로그인
			if ($this->form_validation->run()) {
				if ($this->tank_auth->login(
						$this->form_validation->set_value('login'),
						$this->form_validation->set_value('password'),
						$this->form_validation->set_value('remember'),
						$data['login_by_username'],
						$data['login_by_email'])) {				
					// 로그인 성공
					redirect('auth');// 로그인 후 페이지
				//로그인 실패시
				} else {
			$errors = $this->tank_auth->get_error_message();


					//불량회원 일때
					if (isset($errors['banned'])) {
						//alert($this->lang->line('auth_message_banned'), '../main');
						$this->_show_message($this->lang->line('auth_message_banned').' '.$errors['banned']);
					//인증 안된 회원 인증메일 발송폼으로...
					} elseif (isset($errors['not_activated'])) {
					//현재 인증안된 회원이 세션이 생성 되어서 게시판 작성 가능상태임 추후 수정요함
						$this->_show_message($this->lang->line('auth_message_not_activated').' '.$errors['not_activated']);
					} else {//실패시
						foreach ($errors as $k => $v)	$data['errors'][$k] = $this->lang->line($v);
					}
				}
			}
			$data['show_captcha'] = FALSE;
			if ($this->tank_auth->is_max_login_attempts_exceeded($login)) {
				$data['show_captcha'] = TRUE;
				if ($data['use_recaptcha']) {
					$data['recaptcha_html'] = $this->_create_recaptcha();
				} else {
					$data['captcha_html'] = $this->_create_captcha();
				}
			}
			//로그인 폼 출력
			$data2['user_id']	= $this->tank_auth->get_user_id();
			$data2['username']	= $this->tank_auth->get_username();
			$this->load->view('auth/login_form', $data);
		}
	}

	//로그아웃(user_autologin테이블의 자동로그인도 해제됨)
	function logout()
	{
		$this->tank_auth->logout();
		$this->_show_message($this->lang->line('auth_message_logged_out'));
	}

	//회원가입 약관등
	function register1()
	{	    
	 $this->load->view('auth/register');
	}

	//우편번호 검색
	function search_zip()
	{
		if($this->input->post('search'))
		{
			$search = $this->input->post('search');
			$this->load->model('tank_auth/users');
				$data['result'] = $this->users->search_zip($search);
				$data['search'] = $search;
			$this->load->view('auth/search_zip', $data);
		}
		else
		{
			$this->load->view('auth/search_zip');
		}
	}

	//회원가입 (필드 추가시 참조 nickname)
	function register()
	{
		//회원괸리 설정
		$users = $this->member_config_model->users();

		//회원가입폼 출력설정
		$data['use'] = $this->member_join_form_model->index();

		//로그인 되어 있을시
		if ($this->tank_auth->is_logged_in()) 
		{
			redirect('');
			//회원가입 후 이메일 인증 안되어 있을시
		} 
		elseif ($this->tank_auth->is_logged_in(FALSE)) 
		{
			redirect('/auth/send_again/');
			//회원가입 비활성시(language/korea/auth_message_registration_disabled)
			//} elseif (!$this->config->item('allow_registration', 'tank_auth')) {
			//db화 해서 수정했음-관리자/회원관리 설정에서 설정함
			//회원가입 기능 정지시 메세지 출력
		} 
		elseif ($users['users_enable']==false) 
		{
			$this->_show_message($this->lang->line('auth_message_registration_disabled'));
			//회원가입 활성
		} 
		else 
		{
			//아이디 입력 받을시
			$use_username = $this->config->item('use_username', 'tank_auth');
			if ($use_username) 
			{
				$this->form_validation->set_rules('username', '아이디', 'trim|required|xss_clean|min_length['.$this->config->item('username_min_length', 'tank_auth').']|max_length['.$this->config->item('username_max_length', 'tank_auth').']|alpha_dash');
			}

				$this->form_validation->set_rules('nickname', '별명', 'trim|required|xss_clean');
				$this->form_validation->set_rules('email', '이메일', 'trim|required|xss_clean|valid_email');

				//아래 두줄 추가 해줘야 정상 작동됨-db오류? 인뜻함
				$this->form_validation->set_rules('re_email', '이메일활용동의', 'trim|xss_clean');
				$this->form_validation->set_rules('re_mobile', '모바일 활용동의', 'trim|xss_clean');

			///////////////선택입력사항//공부삼아 2차원 배열로 해봄! /////////////////
			if($data['use']['kname']==1){//1=사용
				$this->form_validation->set_rules('kname', '이름', 'trim|xss_clean');
			}elseif($data['use']['kname']==2){//2=필수입력
				$this->form_validation->set_rules('kname', '이름', 'trim|required|xss_clean');
				}

			if($data['use']['mobile']==1){
				$this->form_validation->set_rules('mobile', '핸드폰', 'trim|xss_clean');
			}elseif($data['use']['mobile']==2){
				$this->form_validation->set_rules('mobile', '핸드폰', 'trim|required|xss_clean|numeric');
				}

			if($data['use']['telephone']==1){
				$this->form_validation->set_rules('telephone', '전화번호', 'trim|xss_clean');
			}elseif($data['use']['telephone']==2){
				$this->form_validation->set_rules('telephone', '전화번호', 'trim|required|xss_clean|numeric');
				}

			if($data['use']['zip_address']==1){
				$this->form_validation->set_rules('zipcode1', '우편번호1', 'trim|xss_clean');
				$this->form_validation->set_rules('zipcode2', '우편번호2', 'trim|xss_clean');
				$this->form_validation->set_rules('address1', '주소1', 'trim|xss_clean');
				$this->form_validation->set_rules('address2', '주소2', 'trim|xss_clean');
			}elseif($data['use']['zip_address']==2){
				$this->form_validation->set_rules('zipcode1', '우편번호1', 'trim|xss_clean');
				$this->form_validation->set_rules('zipcode2', '우편번호2', 'trim|xss_clean');
				$this->form_validation->set_rules('address1', '주소1', 'trim|required|xss_clean');
				$this->form_validation->set_rules('address2', '주소2', 'trim|required|xss_clean');
				}

			if($data['use']['homepage']==1){
				$this->form_validation->set_rules('homepage', '홈페이지', 'trim|xss_clean|prep_url');
			}elseif($data['use']['homepage']==2){
				$this->form_validation->set_rules('homepage', '홈페이지', 'trim|required|xss_clean|prep_url');
				}

			if($data['use']['birthday']==1){
				$this->form_validation->set_rules('birthday', '생일', 'trim|xss_clean');
			}elseif($data['use']['birthday']==2){
				$this->form_validation->set_rules('birthday', '생일', 'trim|required|xss_clean');
				}

			if($data['use']['sex']==1){
				$this->form_validation->set_rules('sex', '성별', 'trim|xss_clean');
			}elseif($data['use']['sex']==2){
				$this->form_validation->set_rules('sex', '성별', 'trim|required|xss_clean');
				}

			if($data['use']['job']==1){
				$this->form_validation->set_rules('sex', '직업', 'trim|xss_clean');
			}elseif($data['use']['job']==2){
				$this->form_validation->set_rules('job', '직업', 'trim|required|xss_clean');
				}

			$this->form_validation->set_rules('password', '비밀번호', 'trim|required|xss_clean|min_length['.$this->config->item('password_min_length', 'tank_auth').']|max_length['.$this->config->item('password_max_length', 'tank_auth').']|alpha_dash');
			$this->form_validation->set_rules('confirm_password', '패스워드확인', 'trim|required|xss_clean|matches[password]');
			
			//스팸방지 코드 사용시 폼검증
			$captcha_registration	= $this->config->item('captcha_registration', 'tank_auth');
			$use_recaptcha			= $this->config->item('use_recaptcha', 'tank_auth');

			if ($captcha_registration) {
				if ($use_recaptcha) {
					$this->form_validation->set_rules('recaptcha_response_field', '인증코드', 'trim|xss_clean|required|callback__check_recaptcha');
				} else {
					$this->form_validation->set_rules('captcha', '인증코드', 'trim|xss_clean|required|callback__check_captcha');
				}
			}
			$data['errors'] = array();
			
			//$email_activation = $this->config->item('email_activation', 'tank_auth');
			$email_activation = $users['users_email_activation'];
			
			//회원데이터 기록
			if ($this->form_validation->run())
			{
				if (!is_null($data = $this->tank_auth->create_user(
						$use_username ? $this->form_validation->set_value('username') : '',
						$this->form_validation->set_value('kname'),
						$this->form_validation->set_value('nickname'),
						$this->form_validation->set_value('email'),
						$this->form_validation->set_value('re_email'), 
						$this->form_validation->set_value('mobile'),
						$this->form_validation->set_value('re_mobile'),
						$this->form_validation->set_value('password'),
						$this->form_validation->set_value('telephone'),
						$this->form_validation->set_value('zipcode1'),
						$this->form_validation->set_value('zipcode2'),
						$this->form_validation->set_value('address1'),
						$this->form_validation->set_value('address2'),
						$this->form_validation->set_value('homepage'),
						$this->form_validation->set_value('birthday'),
						$this->form_validation->set_value('sex'),
						$this->form_validation->set_value('job'),
						$email_activation))) {
					$data['site_name'] = $this->config->item('website_name', 'tank_auth');
					unset($data['password']); // 패스워드 삭제(암호화 되기전 패스워드)
					
					//email 인증 사용시 인증메일 발송
					if ($email_activation) 
					{
						
						//email 인증 만료기간 설정
						$data['activation_period'] = $this->config->item('email_activation_expire', 'tank_auth') / 3600;
						//email 인증 메일 발송
						$this->_send_email('activate', $data['email'], $data);
						//패스워드 삭제
						unset($data['password']); // Clear password (just for any case)
						//관리자/회원관리/이메일인증 => 인증유도 메세지 출력
						alert($this->lang->line('auth_message_registration_completed_1'), './auth/login');
						//$this->_show_message($this->lang->line('auth_message_registration_completed_1'));
					} 
					else 
					{
						//회원가입 축하 메일 발송
						if ($this->config->item('email_account_details', 'tank_auth')) 
						{
							$this->_send_email('welcome', $data['email'], $data);
						}
						//회원가입 축하 SMS 전송
						$users = $this->member_config_model->users();//관리자/회원설정
						if ($users['users_sms_entry']==1)
						{
						  $data=$this->smss_model->smss_member_register();
						  $this->load->view('admin/sms_process_view',$data);
						}
						//회원가입 완료 메세지
						unset($data['password']);
						alert($this->lang->line('auth_message_registration_completed_2'), './auth/login');
						//$this->_show_message($this->lang->line('auth_message_registration_completed_2').' '.anchor('/auth/login/', 'Login'));
					}
				//폼검증 실패시
				} 
				else 
				{
					$errors = $this->tank_auth->get_error_message();
					foreach ($errors as $k => $v)	$data['errors'][$k] = $this->lang->line($v);
				}
			}
			//스팸방지 인증코드 사용시
			if ($captcha_registration) 
			{
				if ($use_recaptcha) 
				{
					$data['recaptcha_html'] = $this->_create_recaptcha();
				} 
				else 
				{
					$data['captcha_html'] = $this->_create_captcha();
				}
			}
			//스팸방지 인증코드 오류시&회원가입 성공시
			$data['use_username'] = $use_username;
			$data['captcha_registration'] = $captcha_registration;
			$data['use_recaptcha'] = $use_recaptcha;
			$data['use'] = $this->member_join_form_model->index();//폼사용 설정
			$this->load->view('auth/register_form', $data);
		}
	}

	//회원 정보 수정(패스워드 메일 수정)
	function modify()
	{
		//회원가입폼 출력설정
		$data['use'] = $this->member_join_form_model->index();
		if (!$this->tank_auth->is_logged_in()) {
			//로그인 페이지
			redirect('/auth/login/');
		} else {
			$this->form_validation->set_rules('email', '이메일', 'trim|required|xss_clean|valid_email');
			$this->form_validation->set_rules('password', '비밀번호', 'trim|required|xss_clean|min_length['.$this->config->item('password_min_length', 'tank_auth').']|max_length['.$this->config->item('password_max_length', 'tank_auth').']|alpha_dash');
			$this->form_validation->set_rules('confirm_password', '비밀번호 재입력', 'trim|required|xss_clean|matches[password]');
//////선택입력사항//추가적인 비교값이 있을수 있으므로 2차원 배열로 작업! //////////
			if($data['use']['kname']==1){//1=사용
				$this->form_validation->set_rules('kname', '이름', 'trim|xss_clean');
			}elseif($data['use']['kname']==2){//2=필수입력
				$this->form_validation->set_rules('kname', '이름', 'trim|required|xss_clean');
				}			
			if($data['use']['mobile']==1){
				$this->form_validation->set_rules('mobile', '핸드폰', 'trim|xss_clean');
			}elseif($data['use']['mobile']==2){
				$this->form_validation->set_rules('mobile', '핸드폰', 'trim|required|xss_clean|numeric');
				}
			if($data['use']['telephone']==1){
				$this->form_validation->set_rules('telephone', '전화번호', 'trim|xss_clean');
			}elseif($data['use']['telephone']==2){
				$this->form_validation->set_rules('telephone', '전화번호', 'trim|required|xss_clean|numeric');
				}
			if($data['use']['zip_address']==1){
				$this->form_validation->set_rules('zipcode1', '우편번호1', 'trim|xss_clean');
				$this->form_validation->set_rules('zipcode2', '우편번호2', 'trim|xss_clean');
				$this->form_validation->set_rules('address1', '주소1', 'trim|xss_clean');
				$this->form_validation->set_rules('address2', '주소2', 'trim|xss_clean');
			}elseif($data['use']['zip_address']==2){
				$this->form_validation->set_rules('zipcode1', '우편번호1', 'trim|xss_clean');
				$this->form_validation->set_rules('zipcode2', '우편번호2', 'trim|xss_clean');
				$this->form_validation->set_rules('address1', '주소1', 'trim|required|xss_clean');
				$this->form_validation->set_rules('address2', '주소2', 'trim|required|xss_clean');
				}
			if($data['use']['homepage']==1){
				$this->form_validation->set_rules('homepage', '홈페이지', 'trim|xss_clean|prep_url');
			}elseif($data['use']['homepage']==2){
				$this->form_validation->set_rules('homepage', '홈페이지', 'trim|required|xss_clean|prep_url');
				}
			if($data['use']['birthday']==1){
				$this->form_validation->set_rules('birthday', '생일', 'trim|xss_clean');
			}elseif($data['use']['birthday']==2){
				$this->form_validation->set_rules('birthday', '생일', 'trim|required|xss_clean');
				}
			if($data['use']['sex']==1){
				$this->form_validation->set_rules('sex', '성별', 'trim|xss_clean');
			}elseif($data['use']['sex']==2){
				$this->form_validation->set_rules('sex', '성별', 'trim|required|xss_clean');
				}
			if($data['use']['job']==1){
				$this->form_validation->set_rules('sex', '직업', 'trim|xss_clean');
			}elseif($data['use']['job']==2){
				$this->form_validation->set_rules('job', '직업', 'trim|required|xss_clean');
				}

			if ($this->form_validation->run()) {
				//password 암호화
				@$hasher = new PasswordHash(PHPASS_HASH_STRENGTH, PHPASS_HASH_PORTABLE);
				$hashed_password = $hasher->HashPassword($this->input->post('password'));
				//기존 파일명을 가져온다.
				$data = $this->users->users_record();
				$uploadfile = $data['file1'];
				//파일 저장 디렉토리
				$dir="./file/users/";
				//파일 업로드
				include('include/upload/upload.php');

				$data = $this->input->post(NULL, TRUE);
				$data['password'] = $hashed_password;
				$data['file1'] = $uploadfile;
				$data['last_ip'] = $this->input->ip_address();
				unset($data['confirm_password']);
				unset($data['MAX_FILE_SIZE']);

				$this->db->where('id', $this->tank_auth->get_user_id());//아이디 세션값get_user_id()
				$this->db->update('users', $data);
				//수정완료후 이동할 페이지
				redirect('');
			}
			//입력오류시 수정페이지 출력
			$data['views'] = $this->users->users_record();
			$data['use'] = $this->member_join_form_model->index();//폼사용 설정
			$this->load->view('auth/member_modify', $data);
		}
	}

	/**
	 * Send activation email again, to the same or new email address
	 * 새이메일 주소 설정위해서 인증메일 보내기
	 * @return void
	 */

	//회원 미활성화시(activated = 0) 인증 이메일 발송폼 출력
	function send_again()
	{
		if (!$this->tank_auth->is_logged_in(FALSE)) {							// not logged in or activated
			redirect('/auth/login/');
		} else {
			//입력된 이메일 폼 검증
			$this->form_validation->set_rules('email', 'Email', 'trim|required|xss_clean|valid_email');

			$data['errors'] = array();
			//폼검증 통과시 이메일 발송
			if ($this->form_validation->run()) {								// validation ok
				if (!is_null($data = $this->tank_auth->change_email(
						$this->form_validation->set_value('email')))) {			// success
					$data['site_name']	= $this->config->item('website_name', 'tank_auth');
					$data['activation_period'] = $this->config->item('email_activation_expire', 'tank_auth') / 3600;
					$this->_send_email('activate', $data['email'], $data);

					$this->_show_message(sprintf($this->lang->line('auth_message_activation_email_sent'), $data['email']));
				//폼검증 미통과시 에러메세지 출력
				} else {
					$errors = $this->tank_auth->get_error_message();
					foreach ($errors as $k => $v)	$data['errors'][$k] = $this->lang->line($v);
				}
			}
			$this->load->view('auth/send_again_form', $data);
		}
	}

	/**
	 * Activate user account.
	 * User is verified by user_id and authentication code in the URL.
	 * Can be called by clicking on link in mail.
	 * 사용자 계정을 활성화합니다.
	 * 사용자 URL의 USER_ID 및 인증 코드를 확인합니다.
	 * 이메일을 확인한후 이메일 링크를 클릭하여 호출 할 수 있습니다.
	 * @return void
	 */

	//이메일 인증 폼
	function activate()
	{
		$user_id		= $this->uri->segment(3);
		$new_email_key	= $this->uri->segment(4);

		// Activate user
		if ($this->tank_auth->activate_user($user_id, $new_email_key)) {		// success
			$this->tank_auth->logout();
			$this->_show_message($this->lang->line('auth_message_activation_completed').' '.anchor('/auth/login/', 'Login'));

		} else {																// fail
			$this->_show_message($this->lang->line('auth_message_activation_failed'));
		}
	}

	//비밀번호 찾기(메일로 새 비번 전송됨)
	function forgot_password()
	{
		if ($this->tank_auth->is_logged_in()) {									// logged in
			redirect('');

		} elseif ($this->tank_auth->is_logged_in(FALSE)) {						// logged in, not activated
			redirect('/auth/send_again/');

		} else {
			$this->form_validation->set_rules('login', 'Email or login', 'trim|required|xss_clean');

			$data['errors'] = array();

			if ($this->form_validation->run()) {								// validation ok
				if (!is_null($data = $this->tank_auth->forgot_password(
						$this->form_validation->set_value('login')))) {

					$data['site_name'] = $this->config->item('website_name', 'tank_auth');

					// Send email with password activation link
					$this->_send_email('forgot_password', $data['email'], $data);

					$this->_show_message($this->lang->line('auth_message_new_password_sent'));

				} else {
					$errors = $this->tank_auth->get_error_message();
					foreach ($errors as $k => $v)	$data['errors'][$k] = $this->lang->line($v);
				}
			}
			$this->load->view('auth/forgot_password_form', $data);
		}
	}

	/**
	 * Replace user password (forgotten) with a new one (set by user).
	 * User is verified by user_id and authentication code in the URL.
	 * Can be called by clicking on link in mail.
  	 * 새로운 유저암호 (암호 찾기) 교체.
     * URL의 USER_ID 및 인증 코드 확인.
	 * 이 메일 링크를 클릭하여 호출 할 수 있습니다.
	 * @return void
	 */

	function reset_password()
	{
		$user_id		= $this->uri->segment(3);
		$new_pass_key	= $this->uri->segment(4);

		$this->form_validation->set_rules('new_password', 'New Password', 'trim|required|xss_clean|min_length['.$this->config->item('password_min_length', 'tank_auth').']|max_length['.$this->config->item('password_max_length', 'tank_auth').']|alpha_dash');
		$this->form_validation->set_rules('confirm_new_password', 'Confirm new Password', 'trim|required|xss_clean|matches[new_password]');

		$data['errors'] = array();

		if ($this->form_validation->run()) {								// validation ok
			if (!is_null($data = $this->tank_auth->reset_password(
					$user_id, $new_pass_key,
					$this->form_validation->set_value('new_password')))) {	// success

				$data['site_name'] = $this->config->item('website_name', 'tank_auth');

				// Send email with new password
				$this->_send_email('reset_password', $data['email'], $data);

				$this->_show_message($this->lang->line('auth_message_new_password_activated').' '.anchor('/auth/login/', 'Login'));

			} else {														// fail
				$this->_show_message($this->lang->line('auth_message_new_password_failed'));
			}
		} else {
			// Try to activate user by password key (if not activated yet)
		    $users = $this->member_config_model->users();//관리자/회원설정
//			if ($this->config->item('email_activation', 'tank_auth')) {
			if ($users['users_email_activation']) {
				$this->tank_auth->activate_user($user_id, $new_pass_key, FALSE);
			}

			if (!$this->tank_auth->can_reset_password($user_id, $new_pass_key)) {
				$this->_show_message($this->lang->line('auth_message_new_password_failed'));
			}
		}
		$this->load->view('auth/reset_password_form', $data);
	}

	//비밀번호 변경폼 출력됨
	function change_password()
	{
		if (!$this->tank_auth->is_logged_in()) {								// not logged in or not activated
			redirect('/auth/login/');

		} else {
			$this->form_validation->set_rules('old_password', '현재비밀번호', 'trim|required|xss_clean');
			$this->form_validation->set_rules('new_password', '새 비밀번호', 'trim|required|xss_clean|min_length['.$this->config->item('password_min_length', 'tank_auth').']|max_length['.$this->config->item('password_max_length', 'tank_auth').']|alpha_dash');
			$this->form_validation->set_rules('confirm_new_password', '새 비밀번호 확인', 'trim|required|xss_clean|matches[new_password]');

			$data['errors'] = array();

			if ($this->form_validation->run()) {								// validation ok
				if ($this->tank_auth->change_password(
						$this->form_validation->set_value('old_password'),
						$this->form_validation->set_value('new_password'))) {	// success
					$this->_show_message($this->lang->line('auth_message_password_changed'));

				} else {														// fail
					$errors = $this->tank_auth->get_error_message();
					foreach ($errors as $k => $v)	$data['errors'][$k] = $this->lang->line($v);
				}
			}
			$this->load->view('auth/change_password_form', $data);
		}
	}

	//이메일 변경(이메일발송 인증됨)
	function change_email()
	{
		if (!$this->tank_auth->is_logged_in()) {								// not logged in or not activated
			redirect('/auth/login/');

		} else {
			$this->form_validation->set_rules('password', '비밀번호', 'trim|required|xss_clean');
			$this->form_validation->set_rules('email', '이메일', 'trim|required|xss_clean|valid_email');

			$data['errors'] = array();

			if ($this->form_validation->run()) {								// validation ok
				if (!is_null($data = $this->tank_auth->set_new_email(
						$this->form_validation->set_value('email'),
						$this->form_validation->set_value('password')))) {			// success

					$data['site_name'] = $this->config->item('website_name', 'tank_auth');

					// Send email with new email address and its activation link
					$this->_send_email('change_email', $data['new_email'], $data);

					$this->_show_message(sprintf($this->lang->line('auth_message_new_email_sent'), $data['new_email']));

				} else {
					$errors = $this->tank_auth->get_error_message();
					foreach ($errors as $k => $v)	$data['errors'][$k] = $this->lang->line($v);
				}
			}
			$this->load->view('auth/change_email_form', $data);
		}
	}

	/**
	 * Replace user email with a new one.
	 * User is verified by user_id and authentication code in the URL.
	 * Can be called by clicking on link in mail.
	 * 새 이메일을 등록 합니다.
	 * URL의 USER_ID 및 인증 코드 확인.
	 * 이 메일 링크를 클릭하여 호출 할 수 있습니다.
	 * @return void
	 */

	function reset_email()
	{
		$user_id		= $this->uri->segment(3);
		$new_email_key	= $this->uri->segment(4);

		// Reset email
		if ($this->tank_auth->activate_new_email($user_id, $new_email_key)) {	// success
			$this->tank_auth->logout();
			$this->_show_message($this->lang->line('auth_message_new_email_activated').' '.anchor('/auth/login/', 'Login'));

		} else {																// fail
			$this->_show_message($this->lang->line('auth_message_new_email_failed'));
		}
	}

	//회원탈퇴-회원탈퇴됨 다음페이지 에러메세지
	function unregister()
	{
		//회원정보 삭제후 로그아웃 되므로 로그인폼으로 이동됨
		if (!$this->tank_auth->is_logged_in()) {								// not logged in or not activated
			redirect('/auth/login/');

		} else {
			//폼검증
			$this->form_validation->set_rules('password', '패스워드', 'trim|required|xss_clean');

			$data['errors'] = array();

			//관리자 설정(관리자/회원관리/회원탈퇴처리)
			$users = $this->member_config_model->users();
			if($users['users_out']==1){
				$method_out = "users_out";
			}elseif($users['users_out']==2){
				$method_out = "delete_user";
				}

			if ($this->form_validation->run()) {
				if ($this->tank_auth->$method_out(
						$this->form_validation->set_value('password'))) {
					$this->_show_message($this->lang->line('auth_message_unregistered'));

				} else {														// fail
					$errors = $this->tank_auth->get_error_message();
					foreach ($errors as $k => $v)	$data['errors'][$k] = $this->lang->line($v);
				}
			}
			//폼 검증에 실패시 에러메세지 출력하면서 탈퇴폼으로 돌아감
			$this->load->view('auth/unregister_form', $data);
		}
	}

	/**
	 * Show info message
	 * 정보 메시지를 표시
	 * @param	string
	 * @return	void
	 */
	function _show_message($message)
	{
		$this->session->set_flashdata('message', $message);
		//alert($this->session->set_flashdata('message', $message));
		redirect('/auth/');
	}

	/**
	 * Send email message of given type (activate, forgot_password, etc.)
	 * 메일 (활성화, forgot_password 등)전송
	 * @param	string
	 * @param	string
	 * @param	array
	 * @return	void
	 */
	//이메일 발송
	function _send_email($type, $email, &$data)
	{
		$this->load->library('email');
		$this->email->from($this->config->item('webmaster_email', 'tank_auth'), $this->config->item('website_name', 'tank_auth'));
		$this->email->reply_to($this->config->item('webmaster_email', 'tank_auth'), $this->config->item('website_name', 'tank_auth'));
		$this->email->to($email);
		$this->email->subject(sprintf($this->lang->line('auth_subject_'.$type), $this->config->item('website_name', 'tank_auth')));
		$this->email->message($this->load->view('email/'.$type.'-html', $data, TRUE));
		$this->email->set_alt_message($this->load->view('email/'.$type.'-txt', $data, TRUE));
		$this->email->send();
	}

	/**
	 * 스팸방지 이미지 생성
	 *
	 * @return	string
	 */
	//스팸방지 코드 설정
	function _create_captcha()
	{
		$this->load->helper('captcha');

		$cap = create_captcha(array(
			'img_path'		=> './'.$this->config->item('captcha_path', 'tank_auth'),
			'img_url'		=> base_url().$this->config->item('captcha_path', 'tank_auth'),
			'font_path'		=> './'.$this->config->item('captcha_fonts_path', 'tank_auth'),
			'font_size'		=> $this->config->item('captcha_font_size', 'tank_auth'),
			'img_width'		=> $this->config->item('captcha_width', 'tank_auth'),
			'img_height'	=> $this->config->item('captcha_height', 'tank_auth'),
			'show_grid'		=> $this->config->item('captcha_grid', 'tank_auth'),
			'expiration'	=> $this->config->item('captcha_expire', 'tank_auth'),
		));

		// 세션의 보안문자 파라미터 저장
		$this->session->set_flashdata(array(
				'captcha_word' => $cap['word'],
				'captcha_time' => $cap['time'],
		));

		return $cap['image'];
	}

	/**
	 * Callback function. Check if CAPTCHA test is passed.
	 * 보안문자 통과 확인
	 * @param	string
	 * @return	bool
	 */
	function _check_captcha($code)
	{
		$time = $this->session->flashdata('captcha_time');
		$word = $this->session->flashdata('captcha_word');

		list($usec, $sec) = explode(" ", microtime());
		$now = ((float)$usec + (float)$sec);

		if ($now - $time > $this->config->item('captcha_expire', 'tank_auth')) {
			$this->form_validation->set_message('_check_captcha', $this->lang->line('auth_captcha_expired'));
			return FALSE;

		} elseif (($this->config->item('captcha_case_sensitive', 'tank_auth') AND
				$code != $word) OR
				strtolower($code) != strtolower($word)) {
			$this->form_validation->set_message('_check_captcha', $this->lang->line('auth_incorrect_captcha'));
			return FALSE;
		}
		return TRUE;
	}

	/**
	 * Create reCAPTCHA JS and non-JS HTML to verify user as a human
	 * 작성 reCAPTCHA를 JS가 아닌 JS HTML은 인간으로 사용자를 확인합니다
	 * @return	string
	 */
	function _create_recaptcha()
	{
		$this->load->helper('recaptcha');

		// Add custom theme so we can get only image
		$options = "<script>var RecaptchaOptions = {theme: 'custom', custom_theme_widget: 'recaptcha_widget'};</script>\n";

		// Get reCAPTCHA JS and non-JS HTML
		$html = recaptcha_get_html($this->config->item('recaptcha_public_key', 'tank_auth'));

		return $options.$html;
	}

	/**
	 * Callback function. Check if reCAPTCHA test is passed.
	 * 콜백함수 테스트 통과 확인
	 * @return	bool
	 */
	function _check_recaptcha()
	{
		$this->load->helper('recaptcha');

		$resp = recaptcha_check_answer($this->config->item('recaptcha_private_key', 'tank_auth'),
				$_SERVER['REMOTE_ADDR'],
				$_POST['recaptcha_challenge_field'],
				$_POST['recaptcha_response_field']);

		if (!$resp->is_valid) {
			$this->form_validation->set_message('_check_recaptcha', $this->lang->line('auth_incorrect_captcha'));
			return FALSE;
		}
		return TRUE;
	}

}

/* End of file auth.php */
/* Location: ./application/controllers/auth.php */