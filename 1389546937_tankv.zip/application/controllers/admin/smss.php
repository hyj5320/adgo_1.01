<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
date_default_timezone_set('Asia/Seoul');
/**
 * @SMS 관리자 설정
 * @CodeIgniter 기반으로 제작
 * @package	탱크V (www.tankv.com)
 * @author		김영균/꾸숑 (webse@nate.com)
 * @version		beta test
 * @license		MIT License
 * @2013.05.06 작성
 */
class Smss extends CI_Controller
{
	function Smss()
	{
		parent::__construct();
		$this->load->model('admin/site_config_model');
		$this->load->model('admin/board_model');
		$this->load->model('admin/smss_model');
		$this->load->helper(array('form', 'url', 'directory','alert'));
		$this->load->library(array('tank_auth','form_validation'));
		//$this->output->enable_profiler(TRUE);//FALSE로 하면 미작동됨

		//게시판 세그먼트 값 상수 선언
		define('BOARD_NO', $this->seg_value('no'));
		define('BOARD_ID', $this->seg_value('id'));
		define('BOARD_PAGE', $this->seg_value('page'));
		$this->id = BOARD_ID;//get id값
		$this->page = BOARD_PAGE;//get page값
		$this->no = BOARD_NO;//get num값
		if(!$this->page)$this->page=1;

		//base64encode_url
		if ( ! function_exists('base64_encode_url'))
		{
			function base64_encode_url($plainText)
			{
				$base64 = base64_encode($plainText);
				$base64url = strtr($base64, '+/=', '-_~');
				return $base64url; 
			}
		}

		//base64decode_url
		if ( ! function_exists('base64_decode_url'))
		{
			function base64_decode_url($encoded)
			{
				$base64 = strtr($encoded,'-_~','+/=');
				$plainText = base64_decode($base64);
				return $plainText;
			} 
		}
	}

	//리멥설정
	public function _remap($method)
	{
		$site=$this->site_config_model->site();
		$this->load->view('admin/top_view',$site);

		if( method_exists($this, $method) )
		{
			$this->{"{$method}"}();
		}
		$this->load->view('admin/foot_view');
	}

	//페이지 리스트
	function sms_list()
	{
		if(!$this->session->userdata('level'))$this->session->set_userdata('level', 1);
		if($this->session->userdata('level') != 10)
		alert2('접근 권한이 없습니다.'); 
		// 세팅 - 설정
		$base_segment = 7; // CI페이징 세그먼트 주소위치값
		$page_view = 20; // 한 페이지에 레코드 수 
		$directory =  implode('/',array_slice(explode('/',$_SERVER["REQUEST_URI"]),1,1));
		$base_url = "/$directory/admin/smss/sms_list/id/$this->id/page"; // 페이징 이동주소
		$page_per_block = 10; // 페이징 이동 개수 ( 1 .. 5) 
 		//페이지네이션
		include('include/pagination/pagination.php');
		// 모델 - 쿼리
		$data['result']=$this->smss_model->sms_list($start_idx, $page_view, $data); //리스트 가져오기 
		// 뷰 - 출력
		$this->load->view('admin/sms_list_view', $data);
	}

	//관리자 sms발송폼
	function sms_main()
	{
		if($this->session->userdata('level') != 10){alert('접근 권한이 없습니다.');}
		$this->load->view('admin/sms_main_view');
	}

	//sms 발송
	function sms_process()
	{
		$data = $this->smss_model->process();
		if($this->session->userdata('level') != 10){alert('접근 권한이 없습니다.');}
		$this->load->view('admin/sms_process_view',$data);
		redirect(base_url("admin/smss/sms_list/id/$this->id/"));
	}

	//sms 발송 내용 읽기
	function sms_read()
	{
		$data['title']='SMS 읽기';
		$data = $this->smss_model->sms_read();
		$this->load->view('admin/sms_read_view',$data);
	}

	//sms 발송 내력 삭제
	function sms_delete()
	{
		if(!$this->session->userdata('level'))$this->session->set_userdata('level', 10);
		if($this->session->userdata('level') != 10)
		{
			alert('삭제 권한이 없습니다.'); 
		}
		else
		{
			$this->smss_model->sms_delete();
			redirect(base_url("admin/smss/sms_list/id/$this->id"));
		}
	}

	//세그먼트값 찾기 (id/test 일때 id=test)
	function seg_value($key,$segment=NULL)
	{
		if($segment == NULL) 
		{
			$segment = $this->uri->segment_array();
		}
		$this->seg_exp = array_values($segment);
		$arr_key = array_keys($this->seg_exp, $key);		
		if($arr_key)
		{
			$arr_val = $arr_key[0] + 1;
		}
		else
		{
			$arr_val = 200;
		}
		if(count($this->seg_exp) > $arr_val)
		{
			return $this->seg_exp[$arr_val];
		} 
	}

	//세그먼트 위치값 (id/test 일때 test의 세그먼트 위치값)
	function seg_index($key,$segment=NULL)
	{
		if($segment == NULL) {
		$segment = $this->uri->segment_array();
	}
		$this->seg_exp = array_values($segment);
		$arr_key = array_keys($this->seg_exp, $key);
		$tot =count($arr_key);
		if($tot > 0)
		{
			$arr_val = $arr_key[0] + 2;
			return $arr_val;
		}
		else
		{
			return "";
		}
	}
}
