<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * @콘텐츠관리(html 페이지)
 * @CodeIgniter 기반으로 제작
 * @Tank auth, 다음에디터. 스마트에디터 사용됨
 * @package	탱크V (www.tankv.com)
 * @author		김영균/꾸숑 (webse@nate.com)
 * @version		beta test
 * @license		MIT License
 * @2013.05.06 작성
 */
class Contents extends CI_Controller
{
	function contents()
	{
		parent::__construct();
		$this->load->model('admin/site_config_model');
		$this->load->model('admin/contents_model');
		$this->load->helper(array('form', 'url','directory', 'alert'));
		$this->load->library(array('tank_auth','form_validation'));
		//$this->output->enable_profiler(TRUE);//FALSE로 하면 미작동됨

		//게시판 세그먼트 값 상수 선언(전역적 사용)
		define('BOARD_NO', $this->seg_value('no'));
		define('BOARD_ID', $this->seg_value('id'));
		define('BOARD_PAGE', $this->seg_value('page'));
		$this->id = BOARD_ID;//get id값
		$this->page = BOARD_PAGE;//get page값
		$this->no = BOARD_NO;//get num값
		if(!$this->page)$this->page=1;

		//base64encode_url
		if ( ! function_exists('base64_encode_url'))
		{
			function base64_encode_url($plainText)
			{
				$base64 = base64_encode($plainText);
				$base64url = strtr($base64, '+/=', '-_~');
				return $base64url; 
			}
		}

		//base64decode_url
		if ( ! function_exists('base64_decode_url'))
		{
			function base64_decode_url($encoded)
			{
				$base64 = strtr($encoded,'-_~','+/=');
				$plainText = base64_decode($base64);
				return $plainText;
			} 
		}
	}

	//헤더, 푸터 자동삽입
	public function _remap($method)
	{

		//읽기는 유저페이지에서 동작함
		$site=$this->site_config_model->site();
		if($this->uri->segment(3) == 'read')
		{
			$this->load->view('sub_top_view', $site);
		}
		else
		{
			$this->load->view('admin/top_view',$site);
		}
		if( method_exists($this, $method) )
		{
			$this->{"{$method}"}();
		}

		//읽기는 유저페이지에서 동작함
		if($this->uri->segment(3) == 'read')
		{
			$this->load->view('sub_foot_view');
		}
		else
		{
			$this->load->view('admin/foot_view');
		}
	}

	//페이지 리스트
	function index()
	{
		if(!$this->session->userdata('level'))$this->session->set_userdata('level', 1);
		if($this->session->userdata('level') != 10)
		alert2('접근 권한이 없습니다.');

		// 세팅 - 설정
		$base_segment = 7; // CI페이징 세그먼트 주소위치값
		$page_view = 10; // 한 페이지에 레코드 수 
		$directory =  implode('/',array_slice(explode('/',$_SERVER["REQUEST_URI"]),1,1));
		$base_url = "/$directory/admin/contents/index/id/$this->id/page"; // 페이징 이동주소
		$page_per_block = 10; // 페이징 이동 개수 ( 1 .. 5) 

 		//페이지네이션
		include('include/pagination/pagination.php');

		// 모델 - 쿼리
		$data['result']=$this->contents_model->select($start_idx, $page_view, $data); //리스트 가져오기
		
		// 뷰 - 출력
		$this->load->view('admin/contents_list_view', $data);
	}

	//페이지 생성
	function write_form(){
		if(!$this->session->userdata('level'))$this->session->set_userdata('level', 10);
		if($this->session->userdata('level') != 10)
		{
			alert('접근 권한이 없습니다.'); 
		}
		else
		{
			$this->form_validation->set_rules('con_id', '페이지아이디', 'xss_clean|required|alpha|min_length[4]|max_length[40]');
			$this->form_validation->set_rules('con_name', '페이지명', 'xss_clean|required|min_length[4]|max_length[40]');
			$this->form_validation->set_rules('con_use', '메뉴출력여부', 'xss_clean|required');
			$this->form_validation->set_rules('con_place', '메뉴출력위치', 'xss_clean|required');
			$this->form_validation->set_rules('con_sequence', '메뉴출력순서', 'xss_clean|required');
			$this->form_validation->set_rules('content', '내용', 'xss_clean');
		if ($this->form_validation->run() == false)
		{
			$data['title']='페이지 생성';
			$this->load->view('admin/contents_write_view',$data);
		 }
		 else
		{
			$this->contents_model->write();
			redirect(base_url("admin/contents/index/id/$this->id/page/1"));
		}
		}
	}

	//페이지 읽기
	function read(){
		$data['title']='글읽기';
		$data = $this->contents_model->read();
		$this->load->view('admin/contents_read_view',$data);
	}

	//페이지수정
	function edit_form(){
		if(!$this->session->userdata('level'))$this->session->set_userdata('level', 10);
		if($this->session->userdata('level') != 10)
		{
			alert('접근 권한이 없습니다.'); 
		}
		else
		{
			$this->form_validation->set_rules('con_id', '페이지아이디', 'xss_clean|required|alpha|min_length[4]|max_length[40]');
			$this->form_validation->set_rules('con_name', '페이지명', 'xss_clean|required|min_length[4]|max_length[40]');
			//content필드에 xss_clean 사용시 html수정시 수정되지 않아 뺌
			$this->form_validation->set_rules('content', '내용');
		if ($this->form_validation->run() == false)
		{
			$data['title']='페이지 수정';
			$data = $this->contents_model->edit_form();
			$this->load->view('admin/contents_edit_form_view',$data);
		}
		else
		{
			$this->contents_model->edit();
			redirect(base_url("admin/contents/edit_form/id/$this->id/page/$this->page/no/$this->no"));
		}
		}
	}

	//페이지 삭제
	function delete()
	{
		if(!$this->session->userdata('level'))$this->session->set_userdata('level', 10);
		if($this->session->userdata('level') != 10)
		{
			alert('접근 권한이 없습니다.'); 
		}
		else
		{
			$this->contents_model->delete();
			redirect(base_url("admin/contents/index/id/$this->id"));
		}
	}

	//세그먼트값 찾기 (id/test 일때 id=test)
	function seg_value($key,$segment=NULL)
	{
		if($segment == NULL) 
		{
			$segment = $this->uri->segment_array();
		}
		$this->seg_exp = array_values($segment);
		$arr_key = array_keys($this->seg_exp, $key);		
		if($arr_key)
		{
			$arr_val = $arr_key[0] + 1;
		}
		else
		{
			$arr_val = 200;
		}
		if(count($this->seg_exp) > $arr_val)
		{
			return $this->seg_exp[$arr_val];
		} 
	}

	//세그먼트 위치값 (id/test 일때 test의 세그먼트 위치값)
	function seg_index($key,$segment=NULL)
	{
		if($segment == NULL) {
		$segment = $this->uri->segment_array();
	}
	$this->seg_exp = array_values($segment);
	$arr_key = array_keys($this->seg_exp, $key);
	$tot =count($arr_key);
	if($tot > 0)
	{
	$arr_val = $arr_key[0] + 2;
	return $arr_val;
	}
	else
	{
		return "";
	}
	}
}