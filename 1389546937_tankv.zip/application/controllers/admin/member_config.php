<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * @회원관리 설정
 * @CodeIgniter 기반으로 제작
 * @package	탱크V (www.tankv.com)
 * @author		김영균/꾸숑 (webse@nate.com)
 * @version		beta test
 * @license		MIT License
 * @2013.05.06 작성
 */
class Member_config extends CI_Controller
{
	function member_config()
	{
		parent::__construct();
		$this->load->model('admin/site_config_model');//사이트 기본설정 데이터
		$this->load->model('admin/member_config_model');//회원가입 기본설정 데이터
		$this->load->helper(array('form', 'url','directory', 'alert'));
		$this->load->library(array('tank_auth','form_validation'));
		//$this->output->enable_profiler(TRUE);//FALSE로 하면 미작동됨
	}

	//헤더, 푸터 자동삽입(2013.03.31)-포럼에서 _remap 검색
	public function _remap($method)
	{
		$users=$this->site_config_model->site();
		$users['users']=$this->member_config_model->users();
		$this->load->view('admin/top_view',$users);
		if( method_exists($this, $method) )
		{
			$this->{"{$method}"}();
		}
		$site=$this->site_config_model->site();
		$this->load->view('admin/foot_view',$site);
	}

	//사이트 기본 설정
	function index(){
		if(!$this->session->userdata('level'))$this->session->set_userdata('level', 1);
		if($this->session->userdata('level') != 10)
		{
			alert('접근 권한이 없습니다.'); 
		}
		else
		{
			$this->form_validation->set_rules('users_enable', '회원가입작동상태', 'xss_clean|required|is_natural');
			$this->form_validation->set_rules('users_enable', '승인처리', 'xss_clean|required|is_natural');
			$this->form_validation->set_rules('users_out', '탈퇴처리', 'xss_clean|required|is_natural');
			$this->form_validation->set_rules('users_cut_id', '가입제한 아이디', 'xss_clean');
			$this->form_validation->set_rules('users_cut_nickname', '가입제한 닉네임', 'xss_clean|required');
			$this->form_validation->set_rules('users_skin', '회원가입 스킨', 'xss_clean|required');
			$this->form_validation->set_rules('users_sms_entry', '회원가입 축하SMS', 'xss_clean|required');
			$this->form_validation->set_rules('users_sms_admin', '발신번호는', 'xss_clean');
			$this->form_validation->set_rules('users_sms_message', 'sms메세지는', 'xss_clean');
			$this->form_validation->set_rules('users_register1', '약관1', 'xss_clean');
			$this->form_validation->set_rules('users_register2', '약관2', 'xss_clean');
			$this->form_validation->set_rules('users_register3', '약관3', 'xss_clean');
			$this->form_validation->set_rules('users_register4', '약관4', 'xss_clean');
		if ($this->form_validation->run() == false)
		{
			$this->load->view('admin/member_config_view');
		}
		else
		{
			$this->member_config_model->member_config();
			redirect(base_url("admin/member_config/index/users_id/$this->users_id/users_page/$this->users_page/users_no/$this->users_no"));
		}
		}
	}
}
?>
