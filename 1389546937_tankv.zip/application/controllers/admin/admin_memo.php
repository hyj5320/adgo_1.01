<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
date_default_timezone_set('Asia/Seoul');
/**
 * @쪽지 관리
 * @CodeIgniter 기반으로 제작
 * @package	탱크V (www.tankv.com)
 * @author		김영균/꾸숑 (webse@nate.com)
 * @version		beta test
 * @license		MIT License
 * @2013.05.06 작성
 */
class Admin_memo extends CI_Controller
{
	function admin_memo()
	{
		parent::__construct();
		$this->load->model('admin/site_config_model');
		$this->load->model('admin/admin_memo_model');
		$this->load->model('admin/smss_model');
		$this->load->model('admin/mails_model');
		$this->load->helper(array('form', 'url', 'directory', 'alert', 'html'));
		$this->load->library(array('tank_auth','form_validation', 'email'));
		$this->load->dbforge();
		//$this->output->enable_profiler(TRUE);//FALSE로 하면 미작동됨

		//관리자 여부 첵크
		$admin = $this->admin_memo_model->memo_admin();
		if(!$this->session->userdata('level'))$this->session->set_userdata('level', 1);
		if($this->session->userdata('level') != 10)
		alert2('접근 권한이 없습니다.'); 

		//쪽지 세그먼트 값 상수 선언
		define('BOARD_NUM', $this->seg_value('no'));
		define('BOARD_ID', $this->seg_value('id'));
		define('BOARD_PAGE', $this->seg_value('page'));
		$this->id = BOARD_ID;//get id값
		$this->page = BOARD_PAGE;//get page값
		$this->no = BOARD_NUM;//get num값
		if(!$this->page)$this->page=1;

		//base64encode_url
		if ( ! function_exists('base64_encode_url'))
		{
			function base64_encode_url($plainText)
			{
				$base64 = base64_encode($plainText);
				$base64url = strtr($base64, '+/=', '-_~');
				return $base64url; 
			 }
		}

		//base64decode_url
		if ( ! function_exists('base64_decode_url'))
		{
			function base64_decode_url($encoded)
			{
				$base64 = strtr($encoded,'-_~','+/=');
				$plainText = base64_decode($base64);
				return $plainText;
			} 
		}
	}

	//헤더, 푸터 자동삽입(2013.03.31)-포럼에서 _remap 검색
	public function _remap($method)
	{
		$site=$this->site_config_model->site();
		$this->load->view('admin/top_view',$site);

		if( method_exists($this, $method) )
		{
			$this->{"{$method}"}();
		}
		$this->load->view('admin/foot_view');
	}

	//받은 쪽지 리스트
	function receive_list()
	{
		$admin = $this->admin_memo_model->memo_admin();

		// 세팅 - 설정
		$base_segment = 7; // CI페이징 세그먼트 주소위치값
		$page_view = 15; // 한 페이지에 레코드 수 
		//$page_url = dirname($_SERVER["REQUEST_URI"]);//부모주소반환
		$directory =  implode('/',array_slice(explode('/',$_SERVER["REQUEST_URI"]),1,1));
		$base_url = "/$directory/admin/admin_memo/receive_list/id/$this->id/page"; // 페이징 이동주소

		$page_per_block = 10; // 페이징 이동 개수 ( 1 .. 5) 
		//페이지네이션
		include('include/pagination/pagination.php');

		// 모델 - 쿼리
		$data['result']=$this->admin_memo_model->select($start_idx, $page_view, $data); //리스트 가져오기 
		$data['admin'] = $this->admin_memo_model->memo_admin();//2차원배열이 앞에 1차원배열은 뒤에 위치해야 오류안남
		//$this->load->view('admin/aaa/bbb/ccc/aaa/ddd');
		$this->load->view('admin/memo_receive_list_view', $data);
	}

	//보낸 쪽지 리스트
	function send_list()
	{
		$admin = $this->admin_memo_model->memo_admin();

		// 세팅 - 설정
		$base_segment = 7; // CI페이징 세그먼트 주소위치값
		$page_view = 15; // 한 페이지에 레코드 수 
		//$page_url = dirname($_SERVER["REQUEST_URI"]);//부모주소반환
		$directory =  implode('/',array_slice(explode('/',$_SERVER["REQUEST_URI"]),1,1));
		$base_url = "/$directory/admin/admin_memo/send_list/id/$this->id/page"; // 페이징 이동주소
		$page_per_block = 10; // 페이징 이동 개수 ( 1 .. 5) 

		//페이지네이션
		include('include/pagination/pagination.php');

		// 모델 - 쿼리
		$data['result']=$this->admin_memo_model->select($start_idx, $page_view, $data); //리스트 가져오기 

		$data['admin'] = $this->admin_memo_model->memo_admin();//2차원배열이 앞에 1차원배열은 뒤에 위치해야 오류안남

		$this->load->view('admin/memo_send_list_view', $data);
	}

	//쪽지 쓰기
	function send_form()
	{
		$data['admin'] = $this->admin_memo_model->memo_admin();

		$this->form_validation->set_rules('memo_subject', '제목', 'xss_clean|required|min_length[4]|max_length[40]');
		$this->form_validation->set_rules('memo_receive_id', '받는아이디', 'xss_clean|required|min_length[4]|max_length[40]');
		$this->form_validation->set_rules('memo_contents', '내용', 'xss_clean');
		if ($this->form_validation->run() == false)
		{
			$this->load->view('admin/memo_send_form_view',$data);
		}
			else
		{	
			$this->admin_memo_model->send_form();

			//관리자에게 메일 발송 시작(보내는메일과 받는메일이 같은경우 미발송됨)
			//($data 가 충돌이 나서 $data2로 변경함 삽질했음 ㅜㅠ)
			if($this->admin_mail_receive==1)
			{
				$data2=$this->mails_model->mails_board_write();
				$this->load->view('email/mails_board_write_view',$data2);
			}

			//관리자에게 SMS 전송
			if($this->board_mobile_receive ==1)
			{
				$data=$this->smss_model->smss_board_write();
				$this->load->view('admin/sms_process_view',$data);
			}
			redirect(base_url("admin/admin_memo/send_list/id/$this->id"));
		}
	}

	//쪽지 읽기
	function read()
	{
		$data = $this->admin_memo_model->read();
		$data['admin'] = $this->admin_memo_model->memo_admin();

		if($data['memo_bad_count'] > $data['admin']['bad_count']) 
		{
			alert("해당 쪽지는 신고 {$data['admin']['bad_count']}회 이상으로 블럭처리 되었습니다. 의견이 있으시면 관리자에게 문의 하세요."); 
		}
		else
		{
			$data['title']='쪽지 읽기';
			$data['admin'] = $this->admin_memo_model->memo_admin();
			$this->load->view('admin/memo_read_view',$data);
		}
	}

	//파일 다운로드
	function file_down()
	{
		$this->load->helper('download');

		$filename = $this->seg_value('file');
		$data = file_get_contents("./file/memo/$this->id/$filename");
		$name = $filename;
		force_download($name, $data);
	}

	//쪽지 신고
	function bad_count()
	{
		$admin = $this->admin_memo_model->memo_admin();
		$data = $this->admin_memo_model->bad_count();

		$bad_count = $data['memo_bad_count']+1;
		alert("신고 {$memo_bad_count}회 접수 되었습니다. 신고가 {$admin['bad_count']}회 이상이면 자동 블럭처리 됩니다.");
	}

	//쪽지 삭제
	function delete()
	{
		$data = $this->admin_memo_model->read();

		if(!$this->session->userdata('level')) $this->session->set_userdata('level', 1);

		//관리자(10레벨)와 쪽지 쓴회원과 쪽지받은 회원만 삭제 가능
		if($this->session->userdata('level') != 10)
		{
			if($data['memo_send_id'] != $this->session->userdata('username') && $data['memo_receive_id'] != $this->session->userdata('username'))
			alert('삭제권한이 없습니다.');
		}
		$this->admin_memo_model->delete();

		// 받은쪽지 보낸쪽지를 구분해서 목록으로 링크 위해서...
		if($data['memo_send_id'] == $this->session->userdata('username'))
		{
			$aaa = 'send_list';
		}
		elseif($data['memo_receive_id'] == $this->session->userdata('username'))
		{
			$aaa = 'receive_list';
		}
		redirect(base_url("admin/admin_memo/$aaa/id/$this->id"));
	}

	//세그먼트값 찾기 (id/test 일때 id=test)
	function seg_value($key,$segment=NULL)
	{
		if($segment == NULL) 
		{
			$segment = $this->uri->segment_array();
		}
			$this->seg_exp = array_values($segment);
			$arr_key = array_keys($this->seg_exp, $key);		
			if($arr_key)
			{
				$arr_val = $arr_key[0] + 1;
			}
			else
			{
				$arr_val = 200;
			}
			if(count($this->seg_exp) > $arr_val)
			{
				return $this->seg_exp[$arr_val];
			} 
	}

	//세그먼트 위치값 (id/test 일때 test의 세그먼트 위치값)
	function seg_index($key,$segment=NULL)
	{
		if($segment == NULL) 
		{
			$segment = $this->uri->segment_array();
		}
			$this->seg_exp = array_values($segment);
			$arr_key = array_keys($this->seg_exp, $key);
			$tot =count($arr_key);
			if($tot > 0)
			{
				$arr_val = $arr_key[0] + 2;
				return $arr_val;
			}
			else
			{
				return "";
			}
	}
}

