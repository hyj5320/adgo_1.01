<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * @베너 관리
 * @CodeIgniter 기반으로 제작
 * @package	탱크V (www.tankv.com)
 * @author		김영균/꾸숑 (webse@nate.com)
 * @version		beta test
 * @license		MIT License
 * @2013.05.06 작성
 */
class Banner extends CI_Controller
{
	function banner()
	{
		parent::__construct();
		$this->load->model('admin/site_config_model');
		$this->load->model('admin/banner_model');
		$this->load->helper(array('form', 'url','directory', 'alert'));
		$this->load->library(array('tank_auth','form_validation'));
		//$this->output->enable_profiler(TRUE);//FALSE로 하면 미작동됨

		 //세그먼트 값 상수 선언
		define('BOARD_NO', $this->seg_value('no'));
		define('BOARD_ID', $this->seg_value('id'));
		define('BOARD_PAGE', $this->seg_value('page'));
		$this->id = BOARD_ID;//get id값
		$this->page = BOARD_PAGE;//get page값
		$this->no = BOARD_NO;//get num값
		if(!$this->page)$this->page=1;

		//base64encode_url
		if ( ! function_exists('base64_encode_url'))
		{
			function base64_encode_url($plainText)
			{
			$base64 = base64_encode($plainText);
			$base64url = strtr($base64, '+/=', '-_~');
			return $base64url; 
			}
		}

		//base64decode_url
		if ( ! function_exists('base64_decode_url'))
		{
			function base64_decode_url($encoded){
			$base64 = strtr($encoded,'-_~','+/=');
			$plainText = base64_decode($base64);
			return $plainText;
			} 
		}  
	}

	//헤더, 푸터 자동삽입(2013.03.31)-포럼에서 _remap 검색
	public function _remap($method)
	{
		$site=$this->site_config_model->site();
		$this->load->view('admin/top_view',$site);

		if( method_exists($this, $method) )
		{
			$this->{"{$method}"}();
		}
		$this->load->view('admin/foot_view');
	}

	//베너 리스트
	function index()
	{
		if(!$this->session->userdata('level'))$this->session->set_userdata('level', 1);
		if($this->session->userdata('level') != 10)
			alert2('접근 권한이 없습니다.'); 
		// 세팅 - 설정
		$base_segment = 7; // CI페이징 세그먼트 주소위치값
		$page_view = 10; // 한 페이지에 레코드 수 
		$directory =  implode('/',array_slice(explode('/',$_SERVER["REQUEST_URI"]),1,1));
		$base_url = "/$directory/admin/banner/index/id/$this->id/page"; // 페이징 이동주소
		$page_per_block = 10; // 페이징 이동 개수 ( 1 .. 5) 
		//페이지네이션
		include('include/pagination/pagination.php');
		// 모델 - 쿼리
		$data['result']=$this->banner_model->select($start_idx, $page_view, $data); //리스트 가져오기 
		// 뷰 - 출력
		$this->load->view('admin/banner_list_view', $data);
	}

	//베너 생성
	function write_form()
	{
		if(!$this->session->userdata('level'))$this->session->set_userdata('level', 10);
		if($this->session->userdata('level') != 10)
		{
			alert('접근 권한이 없습니다.'); 
		}else{
				$this->form_validation->set_rules('banner_title', '베너타이틀', 'xss_clean|required|min_length[4]|max_length[40]');
				$this->form_validation->set_rules('banner_link', '베너 링크', 'xss_clean|required|prep_url|min_length[4]|max_length[40]');
				$this->form_validation->set_rules('banner_place', '베너위치', 'xss_clean|required');
				$this->form_validation->set_rules('banner_use', '사용여부', 'xss_clean|required');
				$this->form_validation->set_rules('banner_sequence', '출력순서');
				$this->form_validation->set_rules('banner_target', '타겟', 'xss_clean|required');	   
				$this->form_validation->set_rules('banner_width', '베너높이', 'xss_clean');
				$this->form_validation->set_rules('banner_height', '베너폭', 'xss_clean');
		if ($this->form_validation->run() == false)
		{
			$data['title']='베너 생성';
			$this->load->view('admin/banner_write_form_view',$data);
		}else{
				$this->banner_model->write();
				redirect(base_url("admin/banner/index/id/$this->id/page/1"));
				}
		}
	}

	//베너  수정
	function edit_form(){
		if(!$this->session->userdata('level'))$this->session->set_userdata('level', 10);
		if($this->session->userdata('level') != 10)
		{
			alert('접근 권한이 없습니다.'); 
		}else{
				$this->form_validation->set_rules('banner_title', '베너타이틀', 'xss_clean|required|min_length[4]|max_length[40]');
				$this->form_validation->set_rules('banner_link', '베너 링크', 'xss_clean|required|prep_url|min_length[4]|max_length[40]');
				$this->form_validation->set_rules('banner_place', '베너위치', 'xss_clean|required');
				$this->form_validation->set_rules('banner_use', '사용여부', 'xss_clean|required');
				$this->form_validation->set_rules('banner_sequence', '출력순서');
				$this->form_validation->set_rules('banner_target', '타겟', 'xss_clean|required');	   
				$this->form_validation->set_rules('banner_width', '베너높이', 'xss_clean');
				$this->form_validation->set_rules('banner_height', '베너폭', 'xss_clean');
					if ($this->form_validation->run() == false)
					{
						$data['title']='베너 수정';
						$data = $this->banner_model->edit_form();
						$this->load->view('admin/banner_edit_form_view',$data);
					}else{
							$this->banner_model->edit();
							redirect(base_url("admin/banner/edit_form/id/$this->id/page/$this->page/no/$this->no"));
							}
				}
	}

	//베너 읽기(쿠키생성, 카운터증가)
	function read()
	{
			//해당 베너 정보 가져오기
			$data = $this->banner_model->edit_form();
			//죄회수 제어위한 쿠키 생성
			$cookie_banner_data = $this->id."_".$this->no;
			setcookie($cookie_banner_data,time(),time()+($data['banner_count_time']*60*60));
			// 카운터 증가
			if(!isset($_COOKIE[$cookie_banner_data]))
			{
				$data = array('banner_count' => $data['banner_count']+1);
				$this->db->where('banner_num', $this->no);
				$this->db->update($this->id, $data);
			}
			$data = $this->banner_model->edit_form();
			redirect($data['banner_link']);
	}

	//베너 삭제
	function delete()
	{
		if(!$this->session->userdata('level'))$this->session->set_userdata('level', 10);
		if($this->session->userdata('level') != 10)
		{
			alert('접근 권한이 없습니다.'); 
		}
		else
		{
			$this->banner_model->delete();
			redirect(base_url("admin/banner/index/id/$this->id"));
		}
	}

	// 세그먼트값 찾기 (id/test 일때 id=test)
	function seg_value($key,$segment=NULL)
	{
		if($segment == NULL) 
		{
		$segment = $this->uri->segment_array();
		}
		$this->seg_exp = array_values($segment);
		$arr_key = array_keys($this->seg_exp, $key);		
		 if($arr_key)
		{
		$arr_val = $arr_key[0] + 1;
		} 
		else 
		{
		$arr_val = 200;
		}
		if(count($this->seg_exp) > $arr_val)
		{
		return $this->seg_exp[$arr_val];
		} 
	}

	//세그먼트 위치값 (id/test 일때 test의 세그먼트 위치값)
	function seg_index($key,$segment=NULL)
		{
		if($segment == NULL) {
		$segment = $this->uri->segment_array();
		}
		$this->seg_exp = array_values($segment);
		$arr_key = array_keys($this->seg_exp, $key);
		$tot =count($arr_key);
		if($tot > 0) 
		{
		$arr_val = $arr_key[0] + 2;
		return $arr_val;
		} 
		else 
		{
		return "";
		}
	}
}
