<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * @회원가입폼 관리자 설정
 * @CodeIgniter 기반으로 제작
 * @package	탱크V (www.tankv.com)
 * @author		김영균/꾸숑 (webse@nate.com)
 * @version		beta test
 * @license		MIT License
 * @2013.05.06 작성
 */
class Member_join_form extends CI_Controller
{
	function Member_join_form()
	{
		parent::__construct();
		$this->load->model('admin/member_join_form_model');
		$this->load->model('admin/site_config_model');//사이트 기본설정 데이터
		$this->load->model('admin/member_config_model');//회원가입 기본설정 데이터
		$this->load->helper(array('form', 'url','directory', 'alert'));
		$this->load->library(array('tank_auth','form_validation'));
		//$this->output->enable_profiler(TRUE);//FALSE로 하면 미작동됨
	}

	//헤더, 푸터 자동삽입
	public function _remap($method)
	{
		$users=$this->site_config_model->site();
		$users['form']=$this->member_join_form_model->index();
		$this->load->view('admin/top_view',$users);
		if( method_exists($this, $method) )
		{
			$this->{"{$method}"}();
		}
		$this->load->view('admin/foot_view');
	}

	function index()
	{	
		$this->form_validation->set_rules('kname', '이름', 'xss_clean');
		$this->form_validation->set_rules('mobile', '핸드폰', 'xss_clean');
		$this->form_validation->set_rules('telephone', '집전화', 'xss_clean');
		$this->form_validation->set_rules('zip_address', '주소', 'xss_clean');
		$this->form_validation->set_rules('homepage', '홈페이지', 'xss_clean');	
		$this->form_validation->set_rules('birthday', '생일', 'xss_clean');	
		$this->form_validation->set_rules('sex', '성별', 'xss_clean');	
		$this->form_validation->set_rules('job', '직업', 'xss_clean');
	
		if ($this->form_validation->run() == FALSE)
		{
			 $data = $this->member_join_form_model->index();
			$this->load->view('admin/member_join_form_view', $data);
		}
		else
		{
			$this->member_join_form_model->join_form_config();
			 redirect(base_url("admin/member_join_form/index/"));
		}
	}
}
?>