<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * @쪽지 관리 설정
 * @CodeIgniter 기반으로 제작
 * @Tank auth, 다음에디터. 스마트에디터 사용됨
 * @package	탱크V (www.tankv.com)
 * @author		김영균/꾸숑 (webse@nate.com)
 * @version		beta test
 * @license		MIT License
 * @2013.05.06 작성
 */
class Admin_memo_config extends CI_Controller
{
	function admin_memo_config()
	{
		parent::__construct();
		$this->load->model('admin/site_config_model');
		$this->load->model('admin/admin_memo_config_model');
		$this->load->helper(array('form', 'url','directory', 'alert'));
		$this->load->library(array('tank_auth','form_validation'));
		//$this->output->enable_profiler(TRUE);//FALSE로 하면 미작동됨
	}

	//헤더, 푸터 자동삽입(2013.03.31)-포럼에서 _remap 검색
	public function _remap($method)
	{
		$site=$this->site_config_model->site();
		$site['memo']=$this->admin_memo_config_model->index();
		$this->load->view('admin/top_view',$site);

		if( method_exists($this, $method) )
		{
			$this->{"{$method}"}();
		}
		$site=$this->site_config_model->site();
		$this->load->view('admin/foot_view', $site);
	}

	//사이트 기본 설정
	function index(){
		if(!$this->session->userdata('level'))$this->session->set_userdata('level', 1);
		if($this->session->userdata('level') != 10)
		{
			alert('접근 권한이 없습니다.'); 
		}
		else
		{
			$this->form_validation->set_rules('use', '쪽지기능 사용여부', 'xss_clean');
			$this->form_validation->set_rules('level', '쪽지 사용가능레벨', 'xss_clean');
			$this->form_validation->set_rules('category_use', '카테고리 사용여부', 'xss_clean');
			$this->form_validation->set_rules('view_article', '출력쪽지수', 'xss_clean');
			$this->form_validation->set_rules('width', '폭', 'xss_clean|required');
			$this->form_validation->set_rules('bad_count', '차단신고수', 'xss_clean|');

		if ($this->form_validation->run() == false)
		{
			$this->load->view('admin/memo_config_form_view');
		}
		else
		{
			$this->admin_memo_config_model->edit();
			redirect(base_url("admin/admin_memo_config/index/"));
		}
		}
	}
}
?>