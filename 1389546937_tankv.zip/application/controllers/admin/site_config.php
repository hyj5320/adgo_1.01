<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * @사이트 전체 관리자 기본 설정
 * @CodeIgniter 기반으로 제작
 * @package	탱크V (www.tankv.com)
 * @author		김영균/꾸숑 (webse@nate.com)
 * @version		beta test
 * @license		MIT License
 * @2013.05.06 작성
 */
class Site_config extends CI_Controller
{
	function site_config()
	{
		parent::__construct();
		$this->load->model('admin/site_config_model');
		$this->load->helper(array('form', 'url','directory', 'alert'));
		$this->load->library(array('tank_auth','form_validation'));
		//$this->output->enable_profiler(TRUE);//FALSE로 하면 미작동됨
	}

	//헤더, 푸터 자동삽입(2013.03.31)-포럼에서 _remap 검색
	public function _remap($method)
	{
		$site=$this->site_config_model->index();
		$this->load->view('admin/top_view',$site);

		if( method_exists($this, $method) )
		{
			$this->{"{$method}"}();
		}
		$this->load->view('admin/foot_view');
	}

	//사이트 기본 설정
	function index(){
		if(!$this->session->userdata('level'))$this->session->set_userdata('level', 1);
		if($this->session->userdata('level') != 10)
		{
			alert('접근 권한이 없습니다.'); 
		}
		else
		{
			$this->form_validation->set_rules('site_title', '타이틀', 'xss_clean|required|min_length[2]|max_length[40]');
			$this->form_validation->set_rules('site_main_layout', '메인레이아웃', 'xss_clean|required|min_length[2]|max_length[40]');
			$this->form_validation->set_rules('site_sub_layout', '서브레이아웃', 'xss_clean|required|min_length[2]|max_length[40]');
			$this->form_validation->set_rules('site_main_skin', '메인스킨', 'xss_clean|required|min_length[2]|max_length[40]');
			$this->form_validation->set_rules('site_mail', 'Email', 'required|valid_email');
			$this->form_validation->set_rules('site_mobile', '핸드폰', 'xss_clean|required|is_natural|min_length[10]|max_length[11]');
			$this->form_validation->set_rules('site_align', '사이트 정렬', 'xss_clean|required|min_length[2]|max_length[40]');
			$this->form_validation->set_rules('site_width', '사이트 넓이', 'xss_clean|required|min_length[2]|max_length[10]');
			$this->form_validation->set_rules('site_keywords', '메타키워드', 'xss_clean|required|min_length[2]');
			$this->form_validation->set_rules('site_description', '메타테그', 'xss_clean|required|min_length[2]');

			//<script>테그가 update될수 있도록 보안 해제
			$this->form_validation->set_rules('analytics', '구글 코드', '');
			
		if ($this->form_validation->run() == false)
		{
			$this->load->view('admin/site_config_form_view');
		}
		else
		{
			$this->site_config_model->site_config();
			redirect(base_url("admin/site_config/index/"));
		}
		}
	}

	//사이트 DB 백업
	function site_db_backup() 
	{
		$this->load->dbutil();

		// 테이블 백업 및 변수에 할당
		$prefs = array(
							'tables'      => array(),     // 예 : array('table1', 'table2'), 공백이면 모든테이블 백업
							'ignore'     => array(),             // List of tables to omit from the backup
							'format'     => 'txt',                // gzip, zip, txt
							'filename'   => 'mybackup.sql',  // File name - NEEDED ONLY WITH ZIP FILES
							'add_drop'  => TRUE,             // Whether to add DROP TABLE statements to backup file
							'add_insert' => TRUE,             // Whether to add INSERT data to backup file
							'newline'    => "\r\n"            // Newline character used in backup file
						);

		$backup =& $this->dbutil->backup($prefs);
	
		//백업 폴더의 생성
		if (!is_dir('/file/backup/db/site')) 
		{
			@ mkdir('./file/', 0777);
			@ mkdir('./file/backup/', 0777);
			@ mkdir('./file/backup/db/', 0777);
			@ mkdir('./file/backup/db/site/', 0777);
		}

		$backup_time = date("Y.m.d.H.i.s");

		//서버에 파일 백업
		$this->load->helper('file');
		 write_file('./file/backup/db/site/'.$backup_time.'_'.site.'.sql', $backup);

		$f_name = ''.$backup_time.'_'.site.'.sql';
		//내 컴퓨터로 파일 다운로드
		$this->load->helper('download');
		force_download($f_name, $backup);
	}

	//db최적화
	function optimize_database() 
	{
		$this->load->dbutil();
		$result = $this->dbutil->optimize_database();
		if ($result !== FALSE)
		{
			alert('데이터베이스 최적화가 성공했습니다.!');
			//echo '<pre style="border: 1px solid red;">'.print_r($result, 1).'</pre>';
		}
		elseif ($result == FALSE)
		{
			alert('데이터베이스 최적화에 실패 했습니다.');
		}
	}
}
?>
