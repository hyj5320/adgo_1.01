<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * @회원관리
 * @CodeIgniter 기반으로 제작
 * @package	탱크V (www.tankv.com)
 * @author		김영균/꾸숑 (webse@nate.com)
 * @version		beta test
 * @license		MIT License
 * @2013.05.06 작성
 */
class Member extends CI_Controller
{
	function member()
	{
		parent::__construct();
		 $this->load->model('admin/site_config_model');
		$this->load->model('admin/member_model');
		$this->load->model('tank_auth/users');
		$this->load->model('admin/member_join_form_model');//회원가입 폼 설정
		$this->load->helper(array('form', 'url', 'alert'));
		$this->load->library(array('tank_auth','form_validation'));
		$this->load->config('tank_auth', TRUE);
		$this->lang->load('tank_auth');//$this->load->language('file_name')과 같음
		//$this->output->enable_profiler(TRUE);//FALSE로 하면 미작동됨

		 //게시판 세그먼트 값 상수 선언(전역적 사용)
		 //users 테이블에 id필드가 존재해서 변경작업함
		define('BOARD_ID', $this->seg_value('id'));
		define('BOARD_TABLE', $this->seg_value('table'));
		define('BOARD_PAGE', $this->seg_value('page'));
		$this->table = BOARD_TABLE;//get table값
		$this->page = BOARD_PAGE;//get page값
		$this->id = BOARD_ID;//get id값
		if(!$this->page)$this->page=1;

		//base64encode_url
		if ( ! function_exists('base64_encode_url'))
		{
			function base64_encode_url($plainText)
			{
				$base64 = base64_encode($plainText);
				$base64url = strtr($base64, '+/=', '-_~');
				return $base64url; 
			 }
		}

		//base64decode_url
		if ( ! function_exists('base64_decode_url'))
		{
			function base64_decode_url($encoded)
			{
				$base64 = strtr($encoded,'-_~','+/=');
				$plainText = base64_decode($base64);
				return $plainText;
			} 
		}
	}

	//헤더, 푸터 자동삽입(2013.03.31)-포럼에서 _remap 검색
	public function _remap($method)
	{
		$site=$this->site_config_model->site();
		$this->load->view('admin/top_view',$site);
		if( method_exists($this, $method) )
		{
			$this->{"{$method}"}();
		}
		$this->load->view('admin/foot_view');
	}

	//정상 회원 리스트
	function index()
	{
		if(!$this->session->userdata('level'))$this->session->set_userdata('level', 1);
		if($this->session->userdata('level') != 10)
		alert2('접근 권한이 없습니다.'); 
		// 세팅 - 설정
		$base_segment = 7; // CI페이징 세그먼트 주소위치값
		$page_view = 20; // 한 페이지에 레코드 수 
		$directory =  implode('/',array_slice(explode('/',$_SERVER["REQUEST_URI"]),1,1));
		$base_url = "/$directory/admin/member/index/table/$this->table/page"; // 페이징 이동주소
		$page_per_block = 10; // 페이징 이동 개수 ( 1 .. 5) 
		//페이지네이션
		include('include/pagination/pagination.php');
		// 모델 - 쿼리
		$data['result']=$this->member_model->select($start_idx, $page_view, $data);
		// 뷰 - 출력
		$this->load->view('admin/member_list_view', $data);
	}

	//회원 생성
	function write_form()
	{
		if(!$this->session->userdata('level'))$this->session->set_userdata('level', 1);
		if($this->session->userdata('level') != 10){
		alert('접근 권한이 없습니다.'); 
		}
		else
		{
			//회원가입폼 출력설정
			$data['use'] = $this->member_join_form_model->index();
			//회원가입시 아이디 사용여부 확인
			$use_username = $this->config->item('use_username', 'tank_auth');
			if ($use_username) 
			{
				$this->form_validation->set_rules('username', '아이디', 'xss_clean|required|min_length[4]|max_length[20]');
			}

			$this->form_validation->set_rules('nickname', '닉네임', 'xss_clean|required|min_length[2]|max_length[20]');

			$this->form_validation->set_rules('email', '이메일', 'xss_clean|required|valid_email');

			$this->form_validation->set_rules('password', '비밀번호', 'trim|required|xss_clean|min_length['.$this->config->item('password_min_length', 'tank_auth').']|max_length['.$this->config->item('password_max_length', 'tank_auth').']|alpha_dash');

			$this->form_validation->set_rules('confirm_password', '비밀번호확인', 'trim|required|xss_clean|matches[password]');

			//선택입력사항//추가적인 비교값이 있을수 있으므로 2차원 배열로 작업!
			if($data['use']['kname']==1){//1=사용
				$this->form_validation->set_rules('kname', '이름', 'trim|xss_clean');
			}elseif($data['use']['kname']==2){//2=필수입력
				$this->form_validation->set_rules('kname', '이름', 'trim|required|xss_clean');
				}
				
			if($data['use']['mobile']==1){
				$this->form_validation->set_rules('mobile', '핸드폰', 'trim|xss_clean');
			}elseif($data['use']['mobile']==2){
				$this->form_validation->set_rules('mobile', '핸드폰', 'trim|required|xss_clean|numeric');
				}

			if($data['use']['telephone']==1){
				$this->form_validation->set_rules('telephone', '전화번호', 'trim|xss_clean');
			}elseif($data['use']['telephone']==2){
				$this->form_validation->set_rules('telephone', '전화번호', 'trim|required|xss_clean|numeric');
				}

			if($data['use']['zip_address']==1){
				$this->form_validation->set_rules('zipcode1', '우편번호1', 'trim|xss_clean');
				$this->form_validation->set_rules('zipcode2', '우편번호2', 'trim|xss_clean');
				$this->form_validation->set_rules('address1', '주소1', 'trim|xss_clean');
				$this->form_validation->set_rules('address2', '주소2', 'trim|xss_clean');
			}elseif($data['use']['zip_address']==2){
				$this->form_validation->set_rules('zipcode1', '우편번호1', 'trim|xss_clean');
				$this->form_validation->set_rules('zipcode2', '우편번호2', 'trim|xss_clean');
				$this->form_validation->set_rules('address1', '주소1', 'trim|required|xss_clean');
				$this->form_validation->set_rules('address2', '주소2', 'trim|required|xss_clean');
				}

			if($data['use']['homepage']==1){
				$this->form_validation->set_rules('homepage', '홈페이지', 'trim|xss_clean|prep_url');
			}elseif($data['use']['homepage']==2){
				$this->form_validation->set_rules('homepage', '홈페이지', 'trim|required|xss_clean|prep_url');
				}

			if($data['use']['birthday']==1){
				$this->form_validation->set_rules('birthday', '생일', 'trim|xss_clean');
			}elseif($data['use']['birthday']==2){
				$this->form_validation->set_rules('birthday', '생일', 'trim|required|xss_clean');
				}

			if($data['use']['sex']==1){
				$this->form_validation->set_rules('sex', '성별', 'trim|xss_clean');
			}elseif($data['use']['sex']==2){
				$this->form_validation->set_rules('sex', '성별', 'trim|required|xss_clean');
				}

			if($data['use']['job']==1){
				$this->form_validation->set_rules('sex', '직업', 'trim|xss_clean');
			}elseif($data['use']['job']==2){
				$this->form_validation->set_rules('job', '직업', 'trim|required|xss_clean');
				}

			$this->form_validation->set_rules('level', '레벨', 'xss_clean|required|min_length[1]|max_length[2]');

			$this->form_validation->set_rules('activated', '인증', 'xss_clean|required|is_natural');
			$this->form_validation->set_rules('banned', '회원상태', 'xss_clean|required|min_length[1]|max_length[2]');

			$this->form_validation->set_rules('ban_reason', '불량회원사유', 'xss_clean');

			$this->form_validation->set_rules('users_out', '회원탈퇴상태', 'xss_clean|required|min_length[1]|max_length[2]');

			$this->form_validation->set_rules('out_reason', '탈퇴사유', 'xss_clean');

			if ($this->form_validation->run() == false)
			{
				$data['title']='글쓰기';
				$data['use_username'] = $use_username;//아이디 사용여부확인
				$data['use'] = $this->member_join_form_model->index();//폼사용 설정
				$this->load->view('admin/member_write_view',$data);
			}
			else
			{
				$this->member_model->write();
				redirect(base_url("admin/member/index/table/$this->table/page/1"));
			}
		}
	}

	//회원 수정
	function edit_form()
	{
		if(!$this->session->userdata('level'))$this->session->set_userdata('level', 1);
		if($this->session->userdata('level') != 10)
		{
			alert('접근 권한이 없습니다.'); 
		}
		else
		{
			//회원가입폼 출력설정
			$data['use'] = $this->member_join_form_model->index();

			$this->form_validation->set_rules('nickname', '닉네임', 'xss_clean|required|min_length[2]|max_length[20]');
			$this->form_validation->set_rules('email', '이메일', 'xss_clean|required|valid_email');

			// $data['use']['kname']==1 ->폼출력 , $data['use']['kname']==2 -> 폼출력+필수입력
			if($data['use']['kname']==1){//1=사용
				$this->form_validation->set_rules('kname', '이름', 'trim|xss_clean');
			}elseif($data['use']['kname']==2){//2=필수입력
				$this->form_validation->set_rules('kname', '이름', 'trim|required|xss_clean');
				}

			if($data['use']['mobile']==1){
				$this->form_validation->set_rules('mobile', '핸드폰', 'trim|xss_clean');
			}elseif($data['use']['mobile']==2){
				$this->form_validation->set_rules('mobile', '핸드폰', 'trim|required|xss_clean|numeric');
				}

			if($data['use']['telephone']==1){
				$this->form_validation->set_rules('telephone', '전화번호', 'trim|xss_clean');
			}elseif($data['use']['telephone']==2){
				$this->form_validation->set_rules('telephone', '전화번호', 'trim|required|xss_clean|numeric');
				}

			if($data['use']['zip_address']==1){
				$this->form_validation->set_rules('zipcode1', '우편번호1', 'trim|xss_clean');
				$this->form_validation->set_rules('zipcode2', '우편번호2', 'trim|xss_clean');
				$this->form_validation->set_rules('address1', '주소1', 'trim|xss_clean');
				$this->form_validation->set_rules('address2', '주소2', 'trim|xss_clean');
			}elseif($data['use']['zip_address']==2){
				$this->form_validation->set_rules('zipcode1', '우편번호1', 'trim|xss_clean');
				$this->form_validation->set_rules('zipcode2', '우편번호2', 'trim|xss_clean');
				$this->form_validation->set_rules('address1', '주소1', 'trim|required|xss_clean');
				$this->form_validation->set_rules('address2', '주소2', 'trim|required|xss_clean');
				}

			if($data['use']['homepage']==1){
				$this->form_validation->set_rules('homepage', '홈페이지', 'trim|xss_clean|prep_url');
			}elseif($data['use']['homepage']==2){
				$this->form_validation->set_rules('homepage', '홈페이지', 'trim|required|xss_clean|prep_url');
				}

			if($data['use']['birthday']==1){
				$this->form_validation->set_rules('birthday', '생일', 'trim|xss_clean');
			}elseif($data['use']['birthday']==2){
				$this->form_validation->set_rules('birthday', '생일', 'trim|required|xss_clean');
				}

			if($data['use']['sex']==1){
				$this->form_validation->set_rules('sex', '성별', 'trim|xss_clean');
			}elseif($data['use']['sex']==2){
				$this->form_validation->set_rules('sex', '성별', 'trim|required|xss_clean');
				}

			if($data['use']['job']==1){
				$this->form_validation->set_rules('sex', '직업', 'trim|xss_clean');
			}elseif($data['use']['job']==2){
				$this->form_validation->set_rules('job', '직업', 'trim|required|xss_clean');
				}

			$this->form_validation->set_rules('level', '레벨', 'xss_clean|required|min_length[1]|max_length[2]');

			$this->form_validation->set_rules('activated', '인증', 'xss_clean|required|is_natural');

			$this->form_validation->set_rules('banned', '회원상태', 'xss_clean|required|min_length[1]|max_length[2]');

			$this->form_validation->set_rules('ban_reason', '불량회원사유', 'xss_clean');

			$this->form_validation->set_rules('users_out', '회원탈퇴상태', 'xss_clean|required|min_length[1]|max_length[2]');

			$this->form_validation->set_rules('out_reason', '탈퇴사유', 'xss_clean');

			if ($this->form_validation->run() == false)
			{
				//충돌하여 위치 바꿈(필드명들이 같아서 오류임)
				//$data['views'] = $this->users->users_record();
				$data['views'] = $this->member_model->edit_form();
				$data['use'] = $this->member_join_form_model->index();//폼사용 설정
				$this->load->view('admin/member_edit_view', $data);
			}
			else
			{
				$this->member_model->edit();
				redirect(base_url("admin/member/edit_form/table/$this->table/page/$this->page/id/$this->id"));
			}
		}
	}

	//회원 삭제
	function delete()
	{
		if(!$this->session->userdata('level'))$this->session->set_userdata('level', 1);
		if($this->session->userdata('level') != 10){
		alert('접근 권한이 없습니다.'); 
		}
		else
		{
			$this->member_model->delete();
			redirect(base_url("admin/member/index/table/$this->table"));
		}
	}

	// 세그먼트값 찾기 (id/test 일때 id=test)
	function seg_value($key,$segment=NULL)
	{
		if($segment == NULL) 
		{
			$segment = $this->uri->segment_array();
		}
		$this->seg_exp = array_values($segment);
		$arr_key = array_keys($this->seg_exp, $key);		
		if($arr_key)
		{
			$arr_val = $arr_key[0] + 1;
		}
		else
		{
			$arr_val = 200;
		}
		if(count($this->seg_exp) > $arr_val)
		{
			return $this->seg_exp[$arr_val];
		} 
	}

	//세그먼트 위치값 (id/test 일때 test의 세그먼트 위치값)
	function seg_index($key,$segment=NULL)
	{
		if($segment == NULL) 
		{
			$segment = $this->uri->segment_array();
		}
		$this->seg_exp = array_values($segment);
		$arr_key = array_keys($this->seg_exp, $key);
		$tot =count($arr_key);
		if($tot > 0)
		{
			$arr_val = $arr_key[0] + 2;
			return $arr_val;
		}
		else
		{
			return "";
		}
	}
}

