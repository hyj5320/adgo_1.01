<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * @게시판 관리
 * @CodeIgniter 기반으로 제작
 * @Tank auth, 다음에디터. 스마트에디터 사용됨
 * @package	탱크V
 * @author		김영균/꾸숑 (webse@nate.com)
 * @version		beta test
 * @license		MIT License
 * @2013.05.06 작성
 */
class Board extends CI_Controller{
	function Board(){
		parent::__construct();
		$this->load->model('admin/site_config_model');
		$this->load->model('admin/board_model');
		$this->load->helper(array('form', 'url','directory', 'alert'));
		$this->load->library(array('tank_auth','form_validation'));
		//$this->output->enable_profiler(TRUE);//FALSE로 하면 미작동됨

		//게시판 세그먼트 값 상수 선언
		define('BOARD_NO', $this->seg_value('no'));
		define('BOARD_ID', $this->seg_value('id'));
		define('BOARD_PAGE', $this->seg_value('page'));
		$this->id = BOARD_ID;//get id값
		$this->page = BOARD_PAGE;//get page값
		$this->no = BOARD_NO;//get num값
		if(!$this->page)$this->page=1;

		//base64encode_url
		if ( ! function_exists('base64_encode_url'))
		{
			function base64_encode_url($plainText){
				$base64 = base64_encode($plainText);
				$base64url = strtr($base64, '+/=', '-_~');
			return $base64url; 
		}
	}

	//base64decode_url
	if ( ! function_exists('base64_decode_url'))
	{
		function base64_decode_url($encoded)
		{
			$base64 = strtr($encoded,'-_~','+/=');
			$plainText = base64_decode($base64);
			return $plainText;
		}
	}
}

	//헤더, 푸터 자동삽입(2013.03.31)-포럼에서 _remap 검색
	public function _remap($method)
	{
		$site=$this->site_config_model->site();
		$this->load->view('admin/top_view',$site);
		if( method_exists($this, $method) )
		{
			$this->{"{$method}"}();
		}
		$this->load->view('admin/foot_view');
	}

	//리스트
	function index(){
		if(!$this->session->userdata('level'))$this->session->set_userdata('level', 1);
		if($this->session->userdata('level') != 10)
		alert2('접근 권한이 없습니다.'); 

		// 세팅 - 설정
		$base_segment = 7; // CI페이징 세그먼트 주소위치값
		$page_view = 20; // 한 페이지에 레코드 수 
		$directory =  implode('/',array_slice(explode('/',$_SERVER["REQUEST_URI"]),1,1));
		$base_url = "/$directory/admin/board/index/id/$this->id/page"; // 페이징 이동주소
		$page_per_block = 10; // 페이징 이동 개수 ( 1 .. 5) 
		//페이지네이션
		include('include/pagination/pagination.php');
		// 모델 - 쿼리
		$data['result']=$this->board_model->select($start_idx, $page_view, $data); //리스트 가져오기 
		// 뷰 - 출력
		$this->load->view('admin/board_list_view', $data);
	}

	//게시판 생성
	function write_form(){
		if(!$this->session->userdata('level'))$this->session->set_userdata('level', 10);
		if($this->session->userdata('level') != 10)
		{
			alert('접근 권한이 없습니다.'); 
		}
		else
		{
			$this->form_validation->set_rules('id', 'id', 'xss_clean|required|alpha_dash|min_length[3]|max_length[40]');
			$this->form_validation->set_rules('board_title', '타이틀', 'xss_clean|required|min_length[3]|max_length[40]');
			$this->form_validation->set_rules('board_admin_mail', '게시판 관리자메일', 'xss_clean|required|valid_email');
			$this->form_validation->set_rules('board_admin_mobile', '핸드폰', 'xss_clean|required|is_natural|min_length[10]|max_length[11]');
			$this->form_validation->set_rules('width', '넓이', 'xss_clean|required|min_length[2]|max_length[5]');
			$this->form_validation->set_rules('board_category', '분류', 'xss_clean');
			$this->form_validation->set_rules('board_limit_word', '제한단어', 'xss_clean');
			$this->form_validation->set_rules('head', '상단html', 'xss_clean');
			$this->form_validation->set_rules('foot', '하단html', 'xss_clean');
		if ($this->form_validation->run() == false)
		{
			$data['title']='글쓰기';
			$this->load->view('admin/board_write_form_view',$data);
		}
		else
		{
			$this->board_model->write();
			redirect(base_url("admin/board/index/id/$this->id/page/1"));
		}
		}
	}

	//게시판 설정 수정
	function edit_form(){
		if(!$this->session->userdata('level'))$this->session->set_userdata('level', 10);
		if($this->session->userdata('level') != 10)
		{
		alert('접근 권한이 없습니다.'); 
		}
		else
		{
			$this->form_validation->set_rules('board_title', '타이틀', 'xss_clean|required|min_length[3]|max_length[40]');	
			$this->form_validation->set_rules('width', '넓이', 'xss_clean|required|min_length[2]|max_length[5]');
			$this->form_validation->set_rules('board_admin_mail', '게시판 관리자메일', 'xss_clean|required|valid_email');
			$this->form_validation->set_rules('board_admin_mobile', '핸드폰', 'xss_clean|required|is_natural|min_length[10]|max_length[11]');
			$this->form_validation->set_rules('use_board_category', '분류사용여부', 'xss_clean');
			$this->form_validation->set_rules('board_category', '분류', 'xss_clean');
			$this->form_validation->set_rules('board_limit_word', '제한단어', 'xss_clean');
			$this->form_validation->set_rules('head', '상단html', 'xss_clean');
			$this->form_validation->set_rules('foot', '하단html', 'xss_clean');
		if ($this->form_validation->run() == false)
		{
			$data['title']='게시판 수정';
			$data = $this->board_model->edit_form();
			$this->load->view('admin/board_edit_form_view',$data);
		}
		else
		{
			$this->board_model->edit();
			redirect(base_url("admin/board/edit_form/id/$this->id/page/$this->page/no/$this->no"));
		}
		}
	}

	//게시판 삭제
	function delete()
	{
		if(!$this->session->userdata('level'))$this->session->set_userdata('level', 10);
		if($this->session->userdata('level') != 10)
		{
		alert('접근 권한이 없습니다.'); 
		}
		else
		{
			$this->board_model->delete();
			redirect(base_url("admin/board/index/id/board_admin"));
		}
	}

	//게시판 백업
	function board_backup() 
	{
		$this->load->dbutil();

		$data = $this->board_model->edit_form();
		$table = $data['id'];

		// 게시판 테이블 백업 및 변수에 할당
		$prefs = array(
							'tables'      => array($table),     // 예 : array('table1', 'table2'), 공백이면 모든테이블 백업
							'ignore'     => array(),             // List of tables to omit from the backup
							'format'     => 'txt',                // gzip, zip, txt
							'filename'   => 'mybackup.sql',  // File name - NEEDED ONLY WITH ZIP FILES
							'add_drop'  => TRUE,             // Whether to add DROP TABLE statements to backup file
							'add_insert' => TRUE,             // Whether to add INSERT data to backup file
							'newline'    => "\r\n"            // Newline character used in backup file
						);

		$backup =& $this->dbutil->backup($prefs);
	
		//백업 폴더의 생성
		if (!is_dir('/file/backup/db/board')) 
		{
			@ mkdir('./file/', 0777);
			@ mkdir('./file/backup/', 0777);
			@ mkdir('./file/backup/db/', 0777);
			@ mkdir('./file/backup/db/board/', 0777);
		}

		$backup_time = date("Y.m.d.H.i.s");

		//서버에 파일 백업
		$this->load->helper('file');
		 write_file('./file/backup/db/board/'.$backup_time.'_'.$table.'.sql', $backup);

		$f_name = ''.$backup_time.'_'.$table.'.sql';
		//내 컴퓨터로 파일 다운로드
		$this->load->helper('download');
		force_download($f_name, $backup);
	}

	//게시판 복구//정상작동 안됨
	function board_restore() 
	{
		$config['upload_path'] = './file/';
		$config['allowed_types'] = 'sql';
		$config['max_size']	= '100';
		$config['encrypt_name'] = 'TRUE';
		$config['remove_spaces'] = 'TRUE';

		$this->load->library('upload', $config);

		if ( ! $this->upload->do_upload())
		{
			$error = array('error' => $this->upload->display_errors());

			$this->load->view('admin/board_restore_view', $error);
		}
		else
		{
			$data = array('upload_data' => $this->upload->data());
			$filename = $config['upload_path'].$data['upload_data']['file_name'];
			$contents = file_get_contents($filename);
			$contents = str_replace("\r\n", "|", $contents); //기본 줄바꿈을 |로 변환
			$contents = str_replace("||", "|", $contents); //두줄 바꿈도 | 로 변환
			$contents = str_replace("|||", "|", $contents); //세줄 바꿈도 | 로 변환
			$requetes = explode("|", $contents); //모두 일차원배열로 변경
			$requetes2 = array_pop($requetes);

				foreach($requetes as $key => $val) {
					if($val !='')
					$this->db->query(trim($val));

					if(mysql_error()) 
					{
						alert('게시판 복구중 에러!','');
					}
				}
				//복구후 업로드한 파일 삭제
				@unlink($filename);

			alert_close('복구 되었습니다.');
		}
	}

	//세그먼트값 찾기 (id/test 일때 id=test)
	function seg_value($key,$segment=NULL)
	{
		if($segment == NULL) 
		{
			$segment = $this->uri->segment_array();
		}
		$this->seg_exp = array_values($segment);
		$arr_key = array_keys($this->seg_exp, $key);		
		if($arr_key)
		{
			$arr_val = $arr_key[0] + 1;
		}
		else
		{
			$arr_val = 200;
		}
		if(count($this->seg_exp) > $arr_val)
		{
			return $this->seg_exp[$arr_val];
		} 
	}

	//세그먼트 위치값 (id/test 일때 test의 세그먼트 위치값)
	function seg_index($key,$segment=NULL)
	{
		if($segment == NULL) 
		{
			$segment = $this->uri->segment_array();
		}
		$this->seg_exp = array_values($segment);
		$arr_key = array_keys($this->seg_exp, $key);
		$tot =count($arr_key);
		if($tot > 0)
		{
			$arr_val = $arr_key[0] + 2;
			return $arr_val;
		}
		else
		{
			return "";
		}
	}
}