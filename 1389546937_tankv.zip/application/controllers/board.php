<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
date_default_timezone_set('Asia/Seoul');
//항상 새페이지 출력-레이아웃에 삽입시 적용이 않됨
header("Cache-Control:no-cache");
header("Pragma:no-cache");

/**
 * @게시판
 * @CodeIgniter 기반으로 제작
 * @Tank auth, 다음에디터. 스마트에디터 사용됨
 * @package	탱크V (www.tankv.com)
 * @author		김영균/꾸숑 (webse@nate.com)
 * @version		beta test
 * @license		MIT License
 * @2013.05.06 작성
 */
class Board extends CI_Controller
{
	function Board()
	{
		parent::__construct();
		$this->load->model('admin/site_config_model');
		$this->load->model('board_model');
		$this->load->model('admin/smss_model');
		$this->load->model('admin/mails_model');
		$this->load->helper(array('form', 'url', 'directory', 'alert', 'html'));
		$this->load->library(array('tank_auth','form_validation', 'email'));
		$this->load->dbforge();
		//$this->output->enable_profiler(TRUE);//FALSE로 하면 미작동됨

		//게시판 세그먼트 값 상수 선언(전역적 사용)
		define('BOARD_NUM', $this->seg_value('num'));
		define('BOARD_ID', $this->seg_value('id'));
		define('BOARD_PAGE', $this->seg_value('page'));
		$this->id = BOARD_ID;//get id값
		$this->page = BOARD_PAGE;//get page값
		$this->num = BOARD_NUM;//get num값
		if(!$this->page)$this->page=1;

		//base64encode_url
		if ( ! function_exists('base64_encode_url'))
		{
			function base64_encode_url($plainText)
			{
				$base64 = base64_encode($plainText);
				$base64url = strtr($base64, '+/=', '-_~');
				return $base64url; 
			 }
		}

		//base64decode_url
		if ( ! function_exists('base64_decode_url'))
		{
			function base64_decode_url($encoded)
			{
				$base64 = strtr($encoded,'-_~','+/=');
				$plainText = base64_decode($base64);
				return $plainText;
			} 
		}
	}

	//헤더, 푸터 자동삽입(2013.03.31)
	public function _remap($method)
	{
		$site=$this->site_config_model->site();
		$this->load->view('sub_top_view',$site);
		if( method_exists($this, $method) )
		{
			$this->{"{$method}"}();
		}
		$this->load->view('sub_foot_view');
	}

	//리스트
	function index()
	{
		$admin = $this->board_model->board_admin();

		// 세팅 - 설정
		$base_segment = 6; // CI페이징 세그먼트 주소위치값
		$page_view = $admin['view_article']; // 한 페이지에 레코드 수 
		//$page_url = dirname($_SERVER["REQUEST_URI"]);//부모주소반환
		$directory =  implode('/',array_slice(explode('/',$_SERVER["REQUEST_URI"]),1,1));
		$base_url = "/$directory/board/index/id/$this->id/page"; // 페이징 이동주소
		$page_per_block = 10; // 페이징 이동 개수 ( 1 .. 5) 

		//부트스트렙 페이징 사용할려면 게시판 스킨명에 boot문자 포함 시킬것
		if(stristr($admin['board_skin'], 'boot') === FALSE)
		{
			include('include/pagination/pagination.php');
		}
		else
		{
			include('include/pagination/boot_pagination.php');
		}

		// 모델 - 쿼리-리스트 가져오기 
		$data['result']=$this->board_model->select($start_idx, $page_view, $data);

		// 뷰 - 본문출력-2차원배열이 앞에 1차원배열은 뒤에 위치해야 오류안남
		$data['admin'] = $this->board_model->board_admin();//

		$this->load->view('board/list_view', $data);
	}

	//글쓰기
	function write_form()
	{
		$data['admin'] = $this->board_model->board_admin();
		if(!$this->session->userdata('level'))$this->session->set_userdata('level', 1);
		 if($this->session->userdata('level') < $data['admin']['write_level'])
		{
			alert('글쓰기 권한이 없습니다.'); 
		}
		else
		{
			$this->form_validation->set_rules('subject', '제목', 'xss_clean|required|min_length[4]|max_length[40]');
			$this->form_validation->set_rules('content', '내용', 'xss_clean');
			if ($this->form_validation->run() === FALSE)
			{
				$this->load->view('board/write_form_view',$data);
			}
			else
			{	
				$this->board_model->write();

				//관리자에게 메일 발송 시작(보내는메일과 받는메일이 같은경우 미발송됨)
				//($data 가 충돌이 나서 $data2로 변경함 삽질했음 ㅜㅠ)
				//===사용하면 오류

				if($data['admin']['board_mail_receive'] == 1)
				{
					$data2=$this->mails_model->mails_board_write();
					$this->load->view('email/mails_board_write_view',$data2);
				}

				//관리자에게 SMS 전송 ===사용하면 오류

				if($data['admin']['board_mobile_receive'] == 1)
				{
					$data=$this->smss_model->smss_board_write();
					$this->load->view('admin/sms_process_view',$data);
				}
				redirect(base_url("board/index/id/$this->id"));
			}
		}
	}

	//답글
	function reply_form()
	{
		$data['admin'] = $this->board_model->board_admin();
		if(!$this->session->userdata('level'))$this->session->set_userdata('level', 1);
		if($this->session->userdata('level') < $data['admin']['reply_level'])
		{
			alert('답글쓰기 권한이 없습니다.'); 
		}
		else
		{
			$this->form_validation->set_rules('subject', '제목', 'xss_clean|required|min_length[4]|max_length[40]');
			if ($this->form_validation->run() === FALSE)
			{
				$data['title']='답글쓰기';
				$data = $this->board_model->reply_form();
				$data['admin'] = $this->board_model->board_admin();
				$this->load->view('board/reply_form_view',$data);
			}
			else
			{
				$this->board_model->reply();
				//원글 작성자에게 답글 메일 발송 시작(보내는메일과 받는메일이 같은경우 미발송됨)
				//($data 가 충돌이 나서 $data2로 변경함 삽질했음 ㅜㅠ)
				//isset을 사용하지 않으면 오류, TRUE대신 1을 사용하면 오류

				if($data['admin']['board_mail_send'] == 1)
				{
					$data2=$this->mails_model->mails_board_reply();
					$this->load->view('email/mails_board_reply_view',$data2);
				}

				//원글 작성자에게 답글 SMS 전송
				if($data['admin']['board_mobile_send'] == 1)
				{
					$data=$this->smss_model->smss_board_reply();
					$this->load->view('admin/sms_process_view',$data);
				}
				redirect(base_url("board/index/id/$this->id/page/$this->page"));
			}
		}
	}

	//글읽기
	function read()
	{
		$data = $this->board_model->read();
		$data['admin'] = $this->board_model->board_admin();
		if(!$this->session->userdata('level'))$this->session->set_userdata('level', 1);
		if($this->session->userdata('level') < $data['admin']['read_level'])
		{
			alert('글읽기 권한이 없습니다.'); 
		}
		elseif($data['bad_count'] > $data['admin']['board_bad_count']) 
		{
			alert("해당 게시물은 신고 {$data['admin']['board_bad_count']}회 이상으로 블럭처리 되었습니다. 의견이 있으시면 관리자에게 문의 하세요."); 
		}
		else
		{
			$data['title']='글읽기';
			$data['admin'] = $this->board_model->board_admin();
			$this->load->view('board/read_view',$data);
		}
	}

	//글수정
	function edit_form()
	{
		$data = $this->board_model->edit_form();
		if(!$this->session->userdata('level'))$this->session->set_userdata('level', 1);
		
		//관리자(10레벨)와 글쓴사람만 수정 가능
		if($this->session->userdata('level') != 10)
		{
			if($data['wr_user_id'] != $this->session->userdata('username'))
				alert('수정권한이 없습니다.');
		}
		$this->form_validation->set_rules('subject', '제목', 'xss_clean|required|min_length[4]|max_length[40]');
		if ($this->form_validation->run() === FALSE)
		{
			$data['admin'] = $this->board_model->board_admin();
			$this->load->view('board/edit_form_view',$data);
		}
		else
		{
			$this->board_model->edit();
			redirect(base_url("board/index/id/$this->id"));
		}
	}

	//파일 다운로드
	function file_down()
	{
		$this->load->helper('download');

		$filename = $this->seg_value('file');
		$data = file_get_contents("./file/board/$this->id/$filename");
		$name = $filename;
		force_download($name, $data);
	}

	//게시글 신고
	function bad_count()
	{
		$admin = $this->board_model->board_admin();
		$data = $this->board_model->bad_count();
		$bad_count = $data['bad_count']+1;
		alert("신고 {$bad_count}회 접수 되었습니다. 신고가 {$admin['board_bad_count']}회 이상이면 자동 블럭처리 됩니다.");
	}

	//게시글 추천
	function good_count()
	{
		$admin = $this->board_model->board_admin();
		$data = $this->board_model->good_count();
		$good_count = $data['good_count']+1;
		alert("추천 {$good_count}회 접수 되었습니다. 추천 {$admin['board_good_count']}회 이상이면 자동 추천처리 됩니다..");
	}

	//댓글 신고
	function comment_bad_count()
	{
		$data = $this->board_model->comment_bad_count();
		$comment_bad_count = $data['comment_bad_count']+1;
		alert("신고 {$comment_bad_count}회 접수 되었습니다.");
	}

	//댓글 추천
	function comment_good_count()
	{
		$data = $this->board_model->comment_good_count();
		$comment_good_count = $data['comment_good_count']+1;
		alert("추천 {$comment_good_count}회 접수 되었습니다.");
	}

	//글삭제
	function delete()
	{
		$data = $this->board_model->edit_form();
		if(!$this->session->userdata('level')) $this->session->set_userdata('level', 1);
		
		//관리자(10레벨)와 글쓴회원만 삭제 가능
		if($this->session->userdata('level') != 10)
		{
			if($data['wr_user_id'] != $this->session->userdata('username'))
			alert('삭제권한이 없습니다.');
		}
		$this->board_model->delete();
		redirect(base_url("/board/index/id/$this->id/page/$this->page/"));	 
	}

	//댓글쓰기
	function comment_write()
	{
		if(!$this->session->userdata('level'))$this->session->set_userdata('level', 1);
		if($this->session->userdata('level') < $this->admin_write_level)
		{
			alert('댓글쓰기 권한이 없습니다.'); 
		}
		else
		{
			$this->form_validation->set_rules('memo', '내용', 'xss_clean|required|min_length[5]|max_length[1000]');
			if ($this->form_validation->run() === FALSE)
			{
				$data['title']='글쓰기';
				$data = $this->board_model->read();
				$this->load->view('board/read_view',$data);
			}
			else
			{					
				$this->board_model->comment_write();
				redirect(base_url("/board/read/id/$this->id/page/$this->page/num/$this->num"));
			}
		}
	}
	
	//댓글삭제
	function comment_delete()
	{
		if(!$this->session->userdata('level')) $this->session->set_userdata('level', 1);
		if($this->session->userdata('level') != 10)
		{
			if($this->session->userdata('level') < $this->admin_write_level) 
		 alert('댓글 삭제권한이 없습니다.');
		}
		$this->board_model->comment_delete();
		alert('댓글이 삭제 되었습니다.');	
	}

	//세그먼트값 찾기 (id/test 일때 id=test)
	function seg_value($key,$segment=NULL)
	{
		if($segment == NULL) 
		{
			$segment = $this->uri->segment_array();
		}
			$this->seg_exp = array_values($segment);
			$arr_key = array_keys($this->seg_exp, $key);		
			if($arr_key)
			{
				$arr_val = $arr_key[0] + 1;
			}
			else
			{
				$arr_val = 200;
			}
			if(count($this->seg_exp) > $arr_val)
			{
				return $this->seg_exp[$arr_val];
			} 
	}

	//세그먼트 위치값 (id/test 일때 test의 세그먼트 위치값)
	function seg_index($key,$segment=NULL)
	{
		if($segment == NULL) 
		{
			$segment = $this->uri->segment_array();
		}
			$this->seg_exp = array_values($segment);
			$arr_key = array_keys($this->seg_exp, $key);
			$tot =count($arr_key);
			if($tot > 0)
			{
				$arr_val = $arr_key[0] + 2;
				return $arr_val;
			}
			else
			{
				return "";
			}
	}
}