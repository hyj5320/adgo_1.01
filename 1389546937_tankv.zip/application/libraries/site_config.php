	function index(){
	  $this->db->select("*");
	  $this->db->where('site_no', 1);
	  $query = $this->db->get('site_config');
	  $row = $query->row_array();
	    
	  $data['site_no'] = $site_no;
	  $data['site_title'] = $row['site_title'];
	  $data['site_layout'] = $row['site_layout'];
	  $data['site_mail'] = $row['site_mail'];
	  $data['site_width'] = $row['site_width'];
	  $data['site_loge'] = $row['site_loge'];
	  $data['site_meta'] = $row['site_meta'];
	  $data['site_date'] = $row['site_date'];
	  $data['site_ip'] = $row['site_ip'];	 
	  return $data;
    }