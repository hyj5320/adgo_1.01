<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------
| DATABASE CONNECTIVITY SETTINGS
| -------------------------------------------------------------------
| This file will contain the settings needed to access your database.
|
| For complete instructions please consult the 'Database Connection'
| page of the User Guide.
|
| -------------------------------------------------------------------
| EXPLANATION OF VARIABLES
| -------------------------------------------------------------------
|
|	['hostname'] The hostname of your database server.
|	['username'] The username used to connect to the database
|	['password'] The password used to connect to the database
|	['database'] The name of the database you want to connect to
|	['dbdriver'] The database type. ie: mysql.  Currently supported:
				 mysql, mysqli, postgre, odbc, mssql, sqlite, oci8
|	['dbprefix'] You can add an optional prefix, which will be added
|				 to the table name when using the  Active Record class
|	['pconnect'] TRUE/FALSE - Whether to use a persistent connection
|	['db_debug'] TRUE/FALSE - Whether database errors should be displayed.
|	['cache_on'] TRUE/FALSE - Enables/disables query caching
|	['cachedir'] The path to the folder where cache files should be stored
|	['char_set'] The character set used in communicating with the database
|	['dbcollat'] The character collation used in communicating with the database
|				 NOTE: For MySQL and MySQLi databases, this setting is only used
| 				 as a backup if your server is running PHP < 5.2.3 or MySQL < 5.0.7
|				 (and in table creation queries made with DB Forge).
| 				 There is an incompatibility in PHP with mysql_real_escape_string() which
| 				 can make your site vulnerable to SQL injection if you are using a
| 				 multi-byte character set and are running versions lower than these.
| 				 Sites using Latin-1 or UTF-8 database character set and collation are unaffected.
|	['swap_pre'] A default table prefix that should be swapped with the dbprefix
|	['autoinit'] Whether or not to automatically initialize the database.
|	['stricton'] TRUE/FALSE - forces 'Strict Mode' connections
|							- good for ensuring strict SQL while developing
|
| The $active_group variable lets you choose which connection group to
| make active.  By default there is only one group (the 'default' group).
|
| The $active_record variables lets you determine whether or not to load
| the active record class
|
| [ '호스트'] 데이터베이스 서버의 호스트 이름입니다.
| [ '이름'] 데이터베이스에 연결하는 데 사용되는 사용자 이름
| [ '암호'] 데이터베이스에 연결하는 데 사용되는 암호
| [ '데이터베이스']는 연결하려는 데이터베이스의 이름
| [ 'dbdriver'] 데이터베이스 유형. 예 : MySQL은. 현재 지원 : MySQL은, mysqli, postgre, ODBC, |				MSSQL, SQLite는, OCI8
| [ 'dbprefix는'] 당신이 추가됩니다 선택적 접두사를 추가 할 수 있습니다
|					테이블 이름에 액티브 레코드 클래스를 사용하는 경우
| [ 'pconnect'] TRUE / ​​FALSE - 영구 연결을 사용할지 여부
| [ 'db_debug'] TRUE / ​​FALSE - 데이터베이스 오류를 표시할지 여부를 지정합니다.
| [ 'cache_on는'] FALSE / TRUE - 캐싱을 활성화 / 비활성화 쿼리
| [ 'cacheDir가'] 캐시 파일이 저장되어야하는 폴더의 경로
| [ 'char_set는'] 문자는 데이터베이스와의 통신에 사용되는 설정
| [ 'dbcollat​​'] 데이터베이스와의 통신에 사용되는 문자 데이터 정렬
|				참고 : MySQL과 MySQLi 데이터베이스의 경우,이 설정은 사용
|				서버가 PHP <5.2.3 또는 MySQL의 <5.0.7을 실행중인 경우 백업으로
|				(및 DB 포지로 만든 테이블 생성 쿼리).
|				 인 mysql_real_escape_string ()와 PHP의 호환성이있다
|				 당신은을 사용하는 경우 SQL 주입 귀하의 사이트가 취약 할 수 있습니다
|				멀티 바이트 문자 세트와 이러한보다 버전이 낮은 실행하고 있습니다.
|				라틴어 1 또는 UTF-8 데이터베이스 문자 집합 및 데이터 정렬을 사용하는 사이트는					영향을받지 않습니다.
| [ 'swap_pre'] dbprefix로 교체해야합니다 기본 테이블 접두사
| [ 'autoinit'] 데이터베이스를 자동으로 초기화할지 여부.
| [ 'stricton'] FALSE / TRUE - 힘의 엄격한 모드 '연결
|									- 개발하면서 엄격한 SQL을 보장하는 좋은
| $ active_group 변수는 선택할 수있는 연결 그룹
| 활성화합니다. 기본적으로 하나의 그룹 ( '기본'그룹)가 있습니다.
| $ active_record 변수는로드할지 여부를 결정할 수 있습니다
| 액티브 레코드 클래스

*/





$active_group = 'default';
$active_record = TRUE;

//include("./install/dbconfig.php");
$db['default']['hostname'] = 'localhost';
$db['default']['username'] = 'tankv';
$db['default']['password'] = '1234';
$db['default']['database'] = 'tankv';
$db['default']['dbdriver'] = 'mysql';
$db['default']['dbprefix'] = '';
$db['default']['pconnect'] = TRUE;
$db['default']['db_debug'] = TRUE;
$db['default']['cache_on'] = FALSE;
$db['default']['cachedir'] = '';
$db['default']['char_set'] = 'utf8';
$db['default']['dbcollat'] = 'utf8_general_ci';
$db['default']['swap_pre'] = '';
$db['default']['autoinit'] = TRUE;
$db['default']['stricton'] = FALSE;


/* End of file database.php */
/* Location: ./application/config/database.php */