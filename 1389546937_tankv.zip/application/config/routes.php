<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
| 이 파일은 사용자에게 특정 컨트롤러 기능을 다시 맵 URI 요청을 할 수 있습니다.
|
| 일반적으로 URL 문자열 사이의 일대일 관계가
| 와 해당 컨트롤러 클래스 / 메소드.의 세그먼트
| URL은 일반적으로이 패턴을 따릅니다 :
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
| 어떤 경우에는, 그러나, 당신은이 관계를 매핑 할 수 있습니다
| 다른 클래스 / 함수가 하나 이상 호출 될 수 있도록 
| URL에 해당.
|
| 자세한 정보를 보려면 사용 설명서를 참조하십시오 :
| Please see the user guide for complete details:
|
|	http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There area two reserved routes:
| 이 영역이 예약 경로 :
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
| 이 경로는 컨트롤러 클래스를로드해야하는 나타내는 경우
| URI에 데이터가 포함되어 있지 않습니다.위의 예에서 "환영"클래스
| 로드 될 것이다.
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router what URI segments to use if those provided
| in the URL cannot be matched to a valid route.
| 이 노선은 그 제공된 경우 URI 세그먼트를 사용할지 라우터를 말할 것이다
| URL에 유효한 경로와 일치 할 수 없습니다.
*/

$route['default_controller'] = "main";
$route['404_override'] = '';

/* End of file routes.php */
/* Location: ./application/config/routes.php */