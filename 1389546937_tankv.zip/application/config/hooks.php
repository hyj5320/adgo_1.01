<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| Hooks
| -------------------------------------------------------------------------
| This file lets you define "hooks" to extend CI without hacking the core
| files.  Please see the user guide for info:
| 이 파일은 코어를 해킹하지 않고 CI를 확장하는 "후크"를 정의 할 수 있습니다
| 파일. 정보의 사용자 설명서를 참조하십시오 :
|	http://codeigniter.com/user_guide/general/hooks.html
|
*/

//$hook['post_controller_constructor'] = array(
//	'class'    => '_Common',
//	'function' => 'index',
//	'filename' => 'Common.php',
//	'filepath' => 'hooks'
//);

/* End of file hooks.php */
/* Location: ./application/config/hooks.php */