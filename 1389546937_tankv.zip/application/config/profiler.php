<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| Profiler Sections (프로파일 섹션)
| -------------------------------------------------------------------------
| This file lets you determine whether or not various sections of Profiler
| data are displayed when the Profiler is enabled.
| Please see the user guide for info:
| 이 파일은 프로파일 여부에 다양한 섹션을 확인 할 수 있습니다
| 프로파일을 사용하는 경우 데이터가 표시됩니다.
| 정보의 사용자 설명서를 참조하십시오 :
|	http://codeigniter.com/user_guide/general/profiling.html
|
*/
//$config['benchmarks']= FALSE;//이곳에서 설정한 값이 Profiler에 적용됨

/* End of file profiler.php */
/* Location: ./application/config/profiler.php */