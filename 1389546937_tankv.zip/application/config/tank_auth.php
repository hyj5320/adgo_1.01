<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Website details 사이트 세부 정보
|
| These details are used in emails sent by authentication library.
| 이러한 세부 사항은 인증 라이브러리에서 보낸 이메일에 사용됩니다.
|--------------------------------------------------------------------------
*/
$config['website_name'] = '웹사이트';
$config['webmaster_email'] = '707kib@naver.com';

/*
|--------------------------------------------------------------------------
| Security settings 보안 설정
|
| The library uses PasswordHash library for operating with hashed passwords.
| 'phpass_hash_portable' = Can passwords be dumped and exported to another server. If set to FALSE then you won't be able to use this database on another server.
| 'phpass_hash_strength' = Password hash strength.
|--------------------------------------------------------------------------
*/
$config['phpass_hash_portable'] = false;//암호 다른서버 사용유무
$config['phpass_hash_strength'] = 8;//암호해시 강도

/*
|--------------------------------------------------------------------------
| Registration settings 등록 설정
|
| 'allow_registration' = Registration is enabled or not
| 'captcha_registration' = Registration uses CAPTCHA
| 'email_activation' = Requires user to activate their account using email after registration.
| 'email_activation_expire' = Time before users who don't activate their account getting deleted from database. Default is 48 hours (60*60*24*2).
| 'email_account_details' = Email with account details is sent after registration (only when 'email_activation' is FALSE).
| 'use_username' = Username is required or not.
|--------------------------------------------------------------------------
*/
//$config['allow_registration'] = TRUE;//회원 가입 받을지 유무(db화 했음)
$config['captcha_registration'] = false;//회원가입 보안문자 유무
//$config['email_activation'] = false;//이메일 인증 여부(db화 했음)
$config['email_activation_expire'] = 60*60*24*2;//이메일 인증 만료 기간(기본48시간)
$config['email_account_details'] = false;//회원가입 축하 메일발송 여부
$config['use_username'] = TRUE;//회원가입 아이디 사용 유무

$config['username_min_length'] = 4;
$config['username_max_length'] = 20;
$config['password_min_length'] = 4;
$config['password_max_length'] = 20;

/*
|--------------------------------------------------------------------------
| Login settings  로그인 설정
|
| 'login_by_username' = Username can be used to login.
| 'login_by_email' = Email can be used to login.
| You have to set at least one of 2 settings above to TRUE.
| 'login_by_username' makes sense only when 'use_username' is TRUE.
|
| 'login_record_ip' = Save in database user IP address on user login.
| 'login_record_time' = Save in database current time on user login.
|
| 'login_count_attempts' = Count failed login attempts.
| 'login_max_attempts' = Number of failed login attempts before CAPTCHA will be shown.
| 'login_attempt_expire' = Time to live for every attempt to login. Default is 24 hours (60*60*24).
|--------------------------------------------------------------------------
*/
$config['login_by_username'] = TRUE;//로그인시 아이디 사용
$config['login_by_email'] = TRUE;//로그인시 메일을 아이디로 사용
$config['login_record_ip'] = TRUE;//로그인시 ip주소 저장
$config['login_record_time'] = TRUE;//현재시간 저장
$config['login_count_attempts'] = TRUE;//로그인 실패 카운트
$config['login_max_attempts'] = 10;//10회이상 로그인 실패시 보안문자 자동출력
$config['login_attempt_expire'] = 60*60*24;//24시간동안 10회 로그인 싶패시 보안문자 출력

/*
|--------------------------------------------------------------------------
| Auto login settings 자동 로그인 설정
|
| 'autologin_cookie_name' = Auto login cookie name.
| 'autologin_cookie_life' = Auto login cookie life before expired. Default is 2 months (60*60*24*31*2).
|--------------------------------------------------------------------------
*/
$config['autologin_cookie_name'] = 'autologin';//자동 로그인 쿠키 이름
$config['autologin_cookie_life'] = 60*60*24*31*2;//자동 로그인 기간 설정(기본2개월)

/*
|--------------------------------------------------------------------------
| Forgot password settings 비밀번호 재발급 설정
|
| 'forgot_password_expire' = Time before forgot password key become invalid. Default is 15 minutes (60*15).
|--------------------------------------------------------------------------
*/
$config['forgot_password_expire'] = 60*15;//지정된 시간이 지나면 암호키 무효(기본15분)

/*
|--------------------------------------------------------------------------
| Captcha 보안문자
|
| You can set captcha that created by Auth library in here.
| 'captcha_path' = Directory where the catpcha will be created.
| 'captcha_fonts_path' = Font in this directory will be used when creating captcha.
| 'captcha_font_size' = Font size when writing text to captcha. Leave blank for random font size.
| 'captcha_grid' = Show grid in created captcha.
| 'captcha_expire' = Life time of created captcha before expired, default is 3 minutes (180 seconds).
| 'captcha_case_sensitive' = Captcha case sensitive or not.
|--------------------------------------------------------------------------
*/
$config['captcha_path'] = 'captcha/';//보안문자 생성되는 디렉토리
$config['captcha_fonts_path'] = 'captcha/fonts/2.ttf';//사용글꼴
$config['captcha_width'] = 200;//박스 폭
$config['captcha_height'] = 50;//박스 높이
$config['captcha_font_size'] = 30;//글꼴크기
$config['captcha_grid'] = FALSE;//보안문자 격자표시
$config['captcha_expire'] = 600;//보안문자 유효시간
$config['captcha_case_sensitive'] = FALSE;//보안문자 대소문자 구분여부

/*
|--------------------------------------------------------------------------
| reCAPTCHA
|
| 'use_recaptcha' = Use reCAPTCHA instead of common captcha
| You can get reCAPTCHA keys by registering at http://recaptcha.net
| 'use_recaptcha는'= 일반적인 보안 문자 대신 reCAPTCHA를 사용
| 당신은 http://recaptcha.net에 등록하여 ReCaptcha 키를 얻을 수 있습니다
|--------------------------------------------------------------------------
*/
$config['use_recaptcha'] = FALSE;//일반적인 보안 문자 대신 reCAPTCHA를 사용
$config['recaptcha_public_key'] = '';
$config['recaptcha_private_key'] = '';

/*
|--------------------------------------------------------------------------
| Database settings 데이터베이스 설정
|
| 'db_table_prefix' = Table prefix that will be prepended to every table name used by the library
| (except 'ci_sessions' table).
| 'db_table_prefix'= 테이블 접두사가이 라이브러리를 사용하는 모든 테이블 이름 앞에 추가됩니다
| ( 'ci_sessions'테이블 제외).
|--------------------------------------------------------------------------
*/
$config['db_table_prefix'] = '';


/* End of file tank_auth.php */
/* Location: ./application/config/tank_auth.php */