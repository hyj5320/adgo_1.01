<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| File and Directory Modes (파일 및 디렉토리 모드)
|--------------------------------------------------------------------------
|
| These prefs are used when checking and setting modes when working
| with the file system.  The defaults are fine on servers with proper
| security, but you may wish (or even need) to change the values in
| certain environments (Apache running a separate process for each
| user, PHP under CGI with Apache suEXEC, etc.).  Octal values should
| always be used to set the mode correctly.
| 작업 할 때 모드를 확인하고 설정할 때 이러한 환경 설정이 사용됩니다
| 파일 시스템. 기본값은 적절한 함께 서버에 벌금
| 보안,하지만 당신은의 값을 변경합니다 (또는 필요)하실 수 있습니다
| 특정 환경 (아파치 각각에 대해 별도의 프로세스를 실행
| 아파치 suEXEC를, 등) CGI에 따라 사용자, PHP. 진수 값은해야
| 항상 올바르게 모드를 설정하는 데 사용할 수.
*/
define('FILE_READ_MODE', 0644);
define('FILE_WRITE_MODE', 0666);
define('DIR_READ_MODE', 0755);
define('DIR_WRITE_MODE', 0777);

/*
|--------------------------------------------------------------------------
| File Stream Modes (파일 스트림 모드)
|--------------------------------------------------------------------------
|
| These modes are used when working with fopen()/popen()
| 하면 fopen()/popen이 (로 작업 할 때이 모드)을 사용하는
*/

define('FOPEN_READ',							'rb');
define('FOPEN_READ_WRITE',						'r+b');
define('FOPEN_WRITE_CREATE_DESTRUCTIVE',		'wb'); // truncates existing file data, use with care
define('FOPEN_READ_WRITE_CREATE_DESTRUCTIVE',	'w+b'); // truncates existing file data, use with care
define('FOPEN_WRITE_CREATE',					'ab');
define('FOPEN_READ_WRITE_CREATE',				'a+b');
define('FOPEN_WRITE_CREATE_STRICT',				'xb');
define('FOPEN_READ_WRITE_CREATE_STRICT',		'x+b');


/* End of file constants.php */
/* Location: ./application/config/constants.php */