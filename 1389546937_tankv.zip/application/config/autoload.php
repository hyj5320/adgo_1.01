<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------
| AUTO-LOADER
| -------------------------------------------------------------------
| This file specifies which systems should be loaded by default.
|
| In order to keep the framework as light-weight as possible only the
| absolute minimal resources are loaded by default. For example,
| the database is not connected to automatically since no assumption
| is made regarding whether you intend to use it.  This file lets
| you globally define which systems you would like loaded with every
| request.
| 이 파일 시스템은 기본적으로로드 할 것인지를 지정한다.
| 만 가능한 가벼운 무게로 틀을 유지하기 위해 |
| 절대 최소한의 자원은 기본적으로로드됩니다. 예를 들어,
| 데이터베이스가없는 가정 이후에 자동으로 연결되지
| 당신이 그것을 사용하려는 여부에 대해 이루어집니다. 이 파일은 수
| 당신은 세계적 당신이 좋아하는 모든과 함께로드 할있는 시스템을 정의
| 자료 요청.
| -------------------------------------------------------------------
| Instructions (|주의 사항)
| -------------------------------------------------------------------
|
| These are the things you can load automatically:
| 당신이 자동으로로드 할 수있는 것들 :
| 1. Packages
| 2. Libraries
| 3. Helper files
| 4. Custom config files
| 5. Language files
| 6. Models
| 1. 패키지
| 2. 라이브러리
| 3. 도우미 파일
| 4. 사용자 정의 구성 파일
| 5. 언어 파일
| 6. 모델
*/

/*
| -------------------------------------------------------------------
|  Auto-load Packges
| -------------------------------------------------------------------
| Prototype:
|
|  $autoload['packages'] = array(APPPATH.'third_party', '/usr/local/shared');
|
*/

$autoload['packages'] = array();


/*
| -------------------------------------------------------------------
|  Auto-load Libraries
| -------------------------------------------------------------------
| These are the classes located in the system/libraries folder
| or in your application/libraries folder.
| 이러한 시스템에있는 클래스입니다 / 라이브러리 폴더
| 또는 응용 프로그램 / 라이브러리 폴더에있다.
| Prototype:
|
|	$autoload['libraries'] = array('database', 'session', 'xmlrpc');
*/

$autoload['libraries'] = array('database', 'session','tank_auth');


/*
| -------------------------------------------------------------------
|  Auto-load Helper Files
| -------------------------------------------------------------------
| Prototype:
|
|	$autoload['helper'] = array('url', 'file');
*/

$autoload['helper'] = array('url', 'file', 'form', 'alert');


/*
| -------------------------------------------------------------------
|  Auto-load Config files
| -------------------------------------------------------------------
| Prototype:
|
|	$autoload['config'] = array('config1', 'config2');
|
| NOTE: This item is intended for use ONLY if you have created custom
| config files.  Otherwise, leave it blank.
| 주 : 사용자 정의 만든 경우에만이 항목을 사용하기위한 것입니다
| 설정 파일. 그렇지 않으면 비워 두십시오.
*/

$autoload['config'] = array();


/*
| -------------------------------------------------------------------
|  Auto-load Language files
| -------------------------------------------------------------------
| Prototype:
|
|	$autoload['language'] = array('lang1', 'lang2');
|
| NOTE: Do not include the "_lang" part of your file.  For example
| "codeigniter_lang.php" would be referenced as array('codeigniter');
|  주의 : 파일의 "_lang"부분을 포함하지 마십시오. 예를 들면
| "codeigniter_lang.php"는 배열 ( 'CodeIgniter는')로 참조 할 것;
*/

$autoload['language'] = array();


/*
| -------------------------------------------------------------------
|  Auto-load Models
| -------------------------------------------------------------------
| Prototype:
|
|	$autoload['model'] = array('model1', 'model2');
|
*/

$autoload['model'] = array();


/* End of file autoload.php */
/* Location: ./application/config/autoload.php */