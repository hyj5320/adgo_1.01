<?php defined('BASEPATH') OR exit('No direct script access allowed');
/*
|--------------------------------------------------------------------------
| Enable/Disable Migrations (사용 / 마이그레이션 안 함)
|--------------------------------------------------------------------------
|
| Migrations are disabled by default but should be enabled 
| whenever you intend to do a schema migration.
| 마이그레이션은 기본적으로 비활성화되어 있지만 사용하도록 설정해야합니다
| 당신이 스키마 마이그레이션을 수행하려고 할 때마다.
*/
$config['migration_enabled'] = FALSE;


/*
|--------------------------------------------------------------------------
| Migrations version
|--------------------------------------------------------------------------
|
| This is used to set migration version that the file system should be on.
| If you run $this->migration->latest() this is the version that schema will
| be upgraded / downgraded to.
| 이것은 파일 시스템에 있어야하는 이전 버전을 설정하는 데 사용됩니다.
| 당신은 $this->migration->latest() 를 실행하는 경우이 스키마 것이라는 버전입니다
| 업그레이드 / 다운 그레이드 할.
*/
$config['migration_version'] = 0;


/*
|--------------------------------------------------------------------------
| Migrations Path
|--------------------------------------------------------------------------
|
| Path to your migrations folder.
| Typically, it will be within your application path.
| Also, writing permission is required within the migrations path.
| 당신 마이그레이션 폴더 경로입니다.
| 일반적으로, 당신의 응용 프로그램 경로 내에 있어야합니다.
| 또한, 쓰기 권한은 마이그레이션 경로에서 필요합니다.
*/
$config['migration_path'] = APPPATH . 'migrations/';


/* End of file migration.php */
/* Location: ./application/config/migration.php */