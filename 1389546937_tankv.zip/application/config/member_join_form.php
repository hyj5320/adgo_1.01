<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| 회원가입폼 설정 정보
|--------------------------------------------------------------------------
*/
$config['website_name'] = '웹사이트';
$config['webmaster_email'] = '707kib@naver.com';
$config['name'] = '웹사이트';
$config['website'] = '707kib@naver.com';