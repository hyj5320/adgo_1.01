<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class	Member_join_form_model extends CI_Model {

	// 모델 생성자 호출
	function member_join_form_model()
	{
		parent::__construct();
	}

	//폼 사용여부
	function index()
	{
		$this->db->select("*");
		$this->db->where('section ', 'use');
		$query = $this->db->get('users_config_form');
		$data = $query->row_array();
		return $data;
	}

	//관리자 폼관련 설정 수정(회원가입폼 사용, 미사용, 필수입력 선택)
	function join_form_config()
	{
		$data = $this->input->post(NULL, TRUE);
		$data['retouch_date'] = date("Y-m-d H:i",time());
		$this->db->where('section', 'use');
		$this->db->update('users_config_form', $data);
	}
}
?>