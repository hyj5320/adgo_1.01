<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Mails_model extends CI_Model 
{

	//모델 생성자 호출
	function Mails_model()
	{
		parent::__construct();
	}

	//mail발송 리스트
	function mails_list($list_num,$offset,$data)
	{
		$this->db->select('*');
		if($data['key'] && $data['keyword'])
		{
			$this->db->like($data['key'], $data['keyword']); 
		}
		$this->db->order_by('mails_no desc');
		$this->db->limit($offset, $list_num);
		$query = $this->db->get($this->id);
		return $query->result();
	}

	//일반메일, 회원전체메일 발송 및 발송내역 db저장
	function mails_form()
	{
		$client_email = $this->input->post('client_email', TRUE);//보내는 메일(글작성자)
		$client_name = $this->input->post('client_name', TRUE);//보내는 사람(글작성자)
		$mails_to = $this->input->post('mails_to', TRUE);//받는메일(게시판설정/게시판관리자메일)
		$subject = $this->input->post('subject', TRUE);//제목
		$content = $this->input->post('content', TRUE);//내용
		$users_email = $this->input->post('users_email', TRUE);
		//회원전체 메일 발송
		if($users_email == 1)
		{
			$this->db->select("email");
			$this->db->where('activated =', "1");
			$this->db->where('banned =', "0");
			$this->db->where('users_out =', "1");
			$query = $this->db->get('users');
			//메일필드값 전체를 배열로 만듬
			foreach($query->result_array() as $row)
			{
				$mails_array[] = $row['email'];
			}
				//메일배열을 , 로 구분된 문장으로 만듬(반대함수:explode)
				$mails_to  = implode(",", $mails_array);
				$this->email->from($client_email, $client_name);
				$this->email->to($mails_to);
				$this->email->subject($subject); 
				$this->email->message($content);
				$this->email->send();
				//echo $this->email->print_debugger(); exit;	
		}
		//관리자 일반 메일 발송
		elseif($users_email == 0) 
		{
		$this->email->from($client_email, $client_name);
		$this->email->to($mails_to);
		$this->email->subject($subject); 
		$this->email->message($content);
		$this->email->send();
		//echo $this->email->print_debugger(); exit;
		}
		//메일 발송 내역 테이블에 저장
		$data=$this->input->post(NULL, TRUE);
		$data['mails_to'] = $mails_to;
		$data['mails_date'] = date("Y-m-d H:i",time());
		$data['mails_ip'] = $this->input->ip_address(NULL, TRUE);
		unset($data['users_email']);
		$this->db->insert($this->id,$data);
	}

	//관리자에게 게시글 메일 발송($data 가 충돌이 나서 $data2로 변경함 삽질했음 ㅜㅠ)
	function mails_board_write()
	{
		$id = $this->id;
		$this->db->select("*");
		$this->db->where('id', $id);//게시판테이블=게시판관리자레코드
		$query = $this->db->get('board_admin');//게시판 관리자 테이블
		$row = $query->row_array();
		$board_title = $row['board_title'];
		$data2['client_email'] = $this->session->userdata('email');//보내는 메일(글작성자)
		$data2['client_name'] = $this->session->userdata('nickname');//보내는 사람(글작성자)
		$data2['mail_to'] = $row['board_admin_mail'];//받는메일(게시판설정/게시판관리자메일)
		$data2['subject'] = $this->input->post('subject', TRUE);//제목
		$data2['content'] = $this->input->post('content', TRUE);//내용
		return $data2;
	}

	//게시판 답글 원글작성자에게 메일 발송
	function mails_board_reply()
	{
		$id = $this->id;
		$num = $this->num;

		//원글 작성자 게시판 테이블에서 아이디 가져오기
		$this->db->select("wr_user_id");
		$this->db->where('num', $num);
		$query = $this->db->get($this->id);
		$row1 = $query->row_array();

		//원글 작성자 users테이블에서 메일 가져오기
		$this->db->select("email");
		$this->db->where('username', $row1['wr_user_id']);
		$query = $this->db->get('users');
		$row2 = $query->row_array();

			$data2['client_email'] = $this->session->userdata('email');//보내는 메일(답글작성자)
			$data2['client_name'] = $this->session->userdata('nickname');//보내는 사람(답글작성자)
			$data2['mail_to'] = $row2['email'];//받는메일(게시판설정/게시판관리자메일)
			$data2['subject'] = $this->input->post('subject', TRUE);//제목
			$data2['content'] = $this->input->post('content', TRUE);//내용
			return $data2;
	}

	//발송된 메일 보기
	function mails_read()
	{
		$mails_no = $this->no;
		$this->db->where('mails_no', $mails_no);
		$query = $this->db->get($this->id);
		$data = $query->row_array();
		return $data;
	}

	//메일 삭제(이미지들삭제, 레코드삭제)
	function mails_delete()
	{
		$this->db->select("content");
		$this->db->where('mails_no', $this->no);
		$query = $this->db->get($this->id);
		$data = $query->row_array();
		preg_match_all('/<img.*?src="([^"]+)"[^>]*>/i',$data['content'],$matches);//이미지추출
			if($matches[0][0]){
				$unique = array_unique($matches[0]);//중복이미지 제거
				$data['content'] = str_replace($unique,'',$data['content']);//본문이미지테그삭제
				foreach ( $unique as $k=>$str )
				{ 
					$filename = './file/editor/'.basename($matches[1][$k]);
					if ( is_file($filename) ) unlink($filename);
				}
			}
		//레코드 삭제
		$this->db->where('mails_no', $this->no);
		$this->db->delete($this->id);
	}

} 
?>