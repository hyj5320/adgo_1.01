<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Admin_memo_model extends CI_Model 
{

	//모델 생성자 호출
	function admin_memo_model()
	{
		parent::__construct();
	}

	//쪽지 관리 설정
	function memo_admin()
	{
		//쪽지 설정
		$this->db->select("*");
		$this->db->where('no', 1);
		$query = $this->db->get('memo_admin');
		$data = $query->row_array();
		return $data;
	}

	//쪽지 총수 (검색용)
	function total_entry()
	{
		$query = $this->db->get($this->id);
		return $query->num_rows();
	}

	//목록
	function select($list_num,$offset,$data)
	{
		$this->db->select('*');
		if(isset($data['key']) && $data['keyword'])
		{
			$this->db->like($data['key'], $data['keyword']); 
		}

		$category=$this->input->post('memo_category', TRUE);
		if($category)
		{
			$this->db->where('memo_category', $category);
		}

		if($this->uri->segment(3) == 'receive_list')
		{
			$this->db->where('memo_receive_id', $this->session->userdata('username'));
			$this->db->where('memo_receive_delete', 'N');
		}
		elseif($this->uri->segment(3) == 'send_list')
		{
			$this->db->where('memo_send_id', $this->session->userdata('username'));
			$this->db->where('memo_send_delete', 'N');
		}

		$this->db->order_by('memo_no desc');
		$this->db->limit($offset, $list_num);
		$query = $this->db->get($this->id);
		//echo $this->db->last_query(); exit;
		return $query->result();
	}

	//쪽지 읽기
	function read()
	{
		$no = $this->no;
		$this->db->where('memo_no', $no);
		$query = $this->db->get($this->id);
		$data = $query->row_array();
			if($data['memo_receive_date'] == NULL && $data['memo_receive_id'] == $this->session->userdata('username'))
			{
				$data2 = array('memo_receive_count' => 'Y', 'memo_receive_date' => date("Y-m-d H:i",time()));
				$this->db->where('memo_no', $no);
				$this->db->update($this->id, $data2);
			}
		return $data;
	}

	//쪽지 폼
	function send_form()
	{
		//파일업로드
		$uploadfile ="";

		//파일 저장 디렉토리
		$dir="./file/memo/$this->id/";

		//디렉토리는 1개만 만들어짐 서브디렉토리는 별도 생성해야함(최초1회 사용)
		$dir2="./file/memo/";
		if(!is_dir($dir)){mkdir($dir2,0777);};

		//파일 업로드
		include('include/upload/upload.php');

		//금지어 설정-관리자 페이지는 금지어 일단 사용않함
		$data = $this->admin_memo_model->memo_admin();
		$contents = $this->input->post('memo_contents', TRUE);
		$limit_word  = $data['limit_word'];
		$word  = explode ("|", $limit_word);
		$memo_contents = str_replace($word,'***',$contents);

			$data=$this->input->post(NULL, TRUE);
			//$data['memo_contents']=$memo_contents;
			$data['memo_file1']=$uploadfile;
			$data['memo_send_date']=date("Y-m-d H:i",time());
			$data['memo_ip']=$this->input->ip_address(NULL, TRUE);
			unset($data['MAX_FILE_SIZE']);
		$this->db->insert($this->id,$data);
	}

	//쪽지 신고
	function bad_count()
	{
		$no = $this->no;
		$this->db->where('memo_no', $no);
		$query = $this->db->get($this->id);
		$data = $query->row_array();

		$cookie_bad_count = $this->id."_".$this->no;
		setcookie($cookie_bad_count,time(),time()+(24*60*60));//24시간

		// 신고 카운터(쿠키 생성)
		if(isset($_COOKIE[$cookie_bad_count]))
		{
			alert("{$data['nick_name']}님이 이미 신고 하셨습니다. 24시간 동안 1회 만 신고 가능합니다.");
		}
		elseif(!isset($_COOKIE[$cookie_bad_count]))
		{
			$data2 = array('memo_bad_count' => $data['memo_bad_count']+1);
			$this->db->where('memo_no', $this->no);
			$this->db->update($this->id, $data2);
		}
		return $data;
	}

	//쪽지 삭제
	function delete()
	{
		$no = $this->no;
		$this->db->where('memo_no', $no);
		$query = $this->db->get($this->id);
		$data = $query->row_array();

		//받은쪽지나 보낸쪽지중 하나만 삭제될시는 쪽지 삭제  않됨
		if($data['memo_send_delete'] == 'N' OR $data['memo_receive_delete'] == 'N')
		{
			if($this->uri->segment(10) == 'receive')
			{
				$receive_delete = array('memo_receive_delete' => 'Y');
				$this->db->where('memo_no', $this->no);
				$this->db->update($this->id, $receive_delete);
			}
			elseif($this->uri->segment(10) == 'send')
			{
				$send_delete = array('memo_send_delete' => 'Y');
				$this->db->where('memo_no', $this->no);
				$this->db->update($this->id, $send_delete);
			}
		}
		
		$no = $this->no;
		$this->db->where('memo_no', $no);
		$query = $this->db->get($this->id);
		$data = $query->row_array();

		//받은쪽지나 보낸쪽지 모두 삭제될시 쪽지 삭제됨
		if($data['memo_send_delete'] == 'Y' && $data['memo_receive_delete'] == 'Y')
		{

			//첨부(본문에 있는 이미지 테그 기준) 이미지 삭제
			//smard_editor/.../fileuploader.php의 경로도 같이 변경해줘야 함
			$this->db->select("*");
			$this->db->where('memo_no', $this->no);
			$query = $this->db->get($this->id);
			$data = $query->row_array();
				preg_match_all('/<img.*?src="([^"]+)"[^>]*>/i',$data['memo_contents'],$matches);//이미지추출
				//echo '<pre>'.print_r($matches).'</pre>';  exit;
				if(isset($matches[0][0])){
					$unique = array_unique($matches[0]);//중복이미지 제거
					$data['memo_contents'] = str_replace($unique,'',$data['memo_contents']);//본문이미지테그삭제
					foreach ( $unique as $k=>$str )
					{ 
						$filename = './file/editor/'.basename($matches[1][$k]);
						//echo $filename; exit;
						if ( is_file($filename) ) unlink($filename);
					}
				}

			//첨부파일 삭제
			$file1name = $data['memo_file1'];
			if(isset($file1name))
			{
				$file1 = "./file/memo/$this->id/$file1name";
				if ( is_file($file1) ) unlink($file1);
			}

			//쪽지 삭제
			$this->db->where('memo_no', $this->no);
			$this->db->delete($this->id); 
		}
	}
}
?>