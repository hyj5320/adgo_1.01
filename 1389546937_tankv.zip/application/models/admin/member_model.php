<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Member_model extends CI_Model 
{

	//모델 생성자 호출
	function member_model()
	{
		parent::__construct();
	}

	//회원 총수 (검색용)
	function total_entry()
	{
		$query = $this->db->get($this->table);
		return $query->num_rows();
	}

	//정상 회원목록
	function select($list_num,$offset,$data)
	{
		$this->db->select('*');

		if(isset($data['key']) && $data['keyword'])
		{
			$this->db->like($data['key'], $data['keyword']); 
		}

		$data=$this->input->post(NULL, TRUE);

		if(isset($data['activated']) && $data['activated'] !="")
		{
		$this->db->where('activated', $data['activated']);
		}

		if(isset($data['banned']) && $data['banned'] !="")
		{
		$this->db->where('banned', $data['banned']);
		}

		if(isset($data['users_out']) && $data['users_out'] !="")
		{
		$this->db->where('users_out', $data['users_out']);
		}

		if(isset($data['level']) && $data['level'] !="")
		{
		$this->db->where('level', $data['level']);
		}

		if(isset($data['address1']) && $data['address1'] !="")
		{
		$this->db->like('address1', $data['address1'], 'after');
		}

		if(isset($data['sex']) && $data['sex'] !="")
		{
		$this->db->where('sex', $data['sex']);
		}

		if(isset($data['created']) && $data['created'] !="")
		{
		$this->db->like('created', $data['created'], 'after');
		}

		if(isset($data['birthday']) && $data['birthday'] !="")
		{
		$this->db->where('birthday', $data['birthday'], 'after');
		}

		$this->db->order_by('id desc');
		$this->db->limit($offset, $list_num);
		$query = $this->db->get($this->table);
		//echo $this->db->last_query(); exit;
		return $query->result();
	}

	//회원 생성
	function write()
	{
		$username = $this->input->post('username', TRUE);
		$nickname = $this->input->post('nickname', TRUE);
		$email = $this->input->post('email', TRUE);
		//$mobile = $this->input->post('mobile', TRUE);
		//아이디 닉네임 이메일 모바일 중복 첵크
		if ((strlen($username) > 0) AND !$this->users->is_username_available($username)) 
		{
			alert('이미 존재하는 아이디 입니다. 다른 아이디로 가입하세요.');
			$this->error = array('username' => 'auth_username_in_use');
		}
		elseif (!$this->users->is_nickname_available($nickname)) 
		{
			alert('이미 존재하는 닉네임 입니다. 다른 닉네임으로 가입하세요.');
			$this->error = array('nickname' => 'auth_nickname_in_use');
		} 
		elseif (!$this->users->is_email_available($email)) 
		{
			alert('이미 존재하는 이메일 입니다. 다른 이메일로 가입하세요.');
			$this->error = array('email' => 'auth_email_in_use');
		} 
		//elseif (!$this->users->is_mobile_available($mobile))
		//{
		//	alert('이미 존재하는 핸드폰 번호 입니다. 다른 핸드폰 번호로 가입하세요.');
		//	$this->error = array('mobile' => 'auth_mobile_in_use');
		//} 
		else
		{
			//암호화-require_once경로를 변경하면 작동되지 않습니다.
			require_once('./phpass-0.1/PasswordHash.php');
			@$hasher = new PasswordHash(PHPASS_HASH_STRENGTH, PHPASS_HASH_PORTABLE);
			$hashed_password = $hasher->HashPassword($this->input->post('password'));
			//파일업로드
			$uploadfile ="";
			//저장 디렉토리
			$dir="./file/$this->table/";
			//파일 업로드
			include('include/upload/upload.php');
				$data=$this->input->post(NULL, TRUE);
				$data['password']=$hashed_password;
				$data['file1']=$uploadfile;
				$data['last_ip']=$this->input->ip_address(NULL, TRUE);
				unset($data['confirm_password'], $data['MAX_FILE_SIZE']);
			$this->db->insert($this->table,$data);
		}
	}

	//회원 수정 폼
	function edit_form()
	{
		$id = $this->id;
		$this->db->select("*");
		$this->db->where('id', $id);
		$query = $this->db->get($this->table);
		$data = $query->row_array();
		return $data;
	}

	//회원 수정
	function edit()
	{
		$username = $this->input->post('username', TRUE);
		$nickname = $this->input->post('nickname', TRUE);
		$email = $this->input->post('email', TRUE);
		$mobile = $this->input->post('mobile', TRUE);
		$data = $this->edit_form();//기존 값을 가져옮
		//정보수정시에만 중복첵크함
		if($username != $data['username'])
		{
			if ((strlen($username) > 0) AND !$this->users->is_username_available($username)) 
			{			
				alert('이미 존재하는 아이디 입니다. 다른 아이디로 수정 하세요.');
				$this->error = array('username' => 'auth_username_in_use');
			}
		}
		if($nickname != $data['nickname'])
		{
			if (!$this->users->is_nickname_available($nickname)) 
			{
			alert('이미 존재하는 닉네임 입니다. 다른 닉네임으로 수정 하세요.');
			$this->error = array('nickname' => 'auth_nickname_in_use');
			}
		} 
		if($email != $data['email'])
		{
			if (!$this->users->is_email_available($email))
			{
			alert('이미 존재하는 이메일 입니다. 다른 이메일로 수정 하세요.');
			$this->error = array('email' => 'auth_email_in_use');
			}
		}
		/*/테스트 위해 주석 처리함 정상 서비스 할때 주석 제거할것
		if($mobile != $data['mobile'])
		{
			if (!$this->users->is_mobile_available($mobile))
			{
				alert('이미 존재하는 핸드폰 번호 입니다. 다른 핸드폰 번호로 수정 하세요.');
				$this->error = array('mobile' => 'auth_mobile_in_use');
			}
		}
		*/

			//기존 파일명을 가져온다.
			$data = $this->member_model->edit_form();
			$uploadfile = $data['file1'];
			//저장 디렉토리
			$dir="./file/$this->table/";
			//파일 업로드
			include('include/upload/upload.php');
			$data2 = $this->input->post(NULL, TRUE);
			$data2['file1'] = $uploadfile;
			$this->db->where('id', $this->id);
			unset($data2['MAX_FILE_SIZE']);
			$this->db->update($this->table, $data2);
	} 

	//회원정보와 회원이미지 삭제
	function delete()
	{
	  $id = $this->id;
	  $this->db->where('id', $id);
		$query = $this->db->get($this->table);
		$row = $query->row_array();
		if(isset($row['file1']))
		{
			@unlink("file/$this->table/".$row['file1']);
		}
		$this->db->where('id', $id);
		$this->db->delete($this->table);
	}
}
?>