<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Site_config_model extends CI_Model 
{
	// 모델 생성자 호출
	function site_config_model()
	{
		parent::__construct();
	}

	//사이트 설정 수정 폼
	function index()
	{
		$this->db->select("*");
		$this->db->where('site_no', '1');
		$query = $this->db->get('site_config');
		$data = $query->row_array();
		return $data;
	}

	//충돌할시에 사용할려구...
	function site()
	{
		$this->db->select("*");
		$this->db->where('site_no', 1);
		$query = $this->db->get('site_config');
		$site = $query->row_array();
		return $site;
	}

	//사이트 설정 수정
	function site_config()
	{
		//기존 파일명을 가져온다.
		$data = $this->site_config_model->index();
		$uploadfile = $data['site_logo'];
		//파일저장 디렉토리
		$dir="./file/site_logo/";
		include('include/upload/upload.php');
		 //파일 업로드 끝
		$data = $this->input->post(NULL, TRUE);

		//<script>테그가 update될수 있도록 보안 해제
		$data['analytics'] = $this->input->post('analytics');

		$data['site_logo'] = $uploadfile;
		$data['site_ip'] = $this->input->ip_address(NULL, TRUE);
		$data['site_date'] = date("Y-m-d H:i",time());
		unset($data['MAX_FILE_SIZE']);
		$this->db->where('site_no', '1');
		$this->db->update('site_config', $data);
	}
}
?>