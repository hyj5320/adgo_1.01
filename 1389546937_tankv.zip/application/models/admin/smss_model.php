<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Smss_model extends CI_Model 
{

	// 모델 생성자 호출
	function smss_model()
	{
		parent::__construct();
	}

	//SMS발송 리스트
	function sms_list($list_num,$offset,$data)
	{
		$this->db->select('*');
		if($data['key'] && $data['keyword'])
		{
			$this->db->like($data['key'], $data['keyword']); 
		}
		$this->db->order_by('smss_no desc');
		$this->db->limit($offset, $list_num);
		$query = $this->db->get($this->id);
		return $query->result();
	}

	//관리자 sms 발송(관리자일반발송, 회원 전체 발송)
	function process()
	{
		$users_sms = $this->input->post('users_sms', TRUE);
		//관리자 정상 회원 전체 SMS발송
		if($users_sms == 1)
		{
			$this->db->select("mobile");
			$this->db->where('activated =', "1");
			$this->db->where('banned =', "0");
			$this->db->where('users_out =', "1");
			$this->db->where('mobile !=', "");
			$query = $this->db->get('users');
			//메일필드값 전체를 배열로 만듬
			foreach($query->result_array() as $row)
			{
				$sms_array[] = $row['mobile'];
			}
				//메일배열을 , 로 구분된 문장으로 만듬(반대함수:explode)
				$rcv_number  = implode(",", $sms_array);
				//echo $rcv_number; exit;
				$data = array(
					'snd_number' => $this->input->post('snd_number') ,//보내는사람
					'rcv_number' => $rcv_number ,//받는사람
					'sms_content' => $this->input->post('sms_content') ,//메세지
					'reserve_date' => $this->input->post('reserve_date') ,
					'reserve_time' => $this->input->post('reserve_time') ,
				);
		}
		//관리자 일반 메일 발송
		elseif($users_sms == 0) 
		{
				$data = array(
					'snd_number' => $this->input->post('snd_number') ,//보내는사람
					'rcv_number' => $this->input->post('rcv_number') ,//받는사람
					'sms_content' => $this->input->post('sms_content') ,//메세지
					'reserve_date' => $this->input->post('reserve_date') ,
					'reserve_time' => $this->input->post('reserve_time') ,
				);
		}
		//echo print_r($data); exit;
		//SMS 발송 내역 테이블에 저장
		$data['sms_date'] = date("Y-m-d H:i",time());
		$data['sms_ip'] = $this->input->ip_address(NULL, TRUE);
		unset($data['users_sms']);
		$this->db->insert($this->id,$data);
		return $data;  
	}

	//회원가입 축하 메세지 발송
	function smss_member_register()
	{
		$users = $this->member_config_model->users();//관리자/회원설정
		$site = $this->site_config_model->site();//관리자/사이트관리
		$data = array(
			'snd_number' => $users['users_sms_admin'] ,//보내는사람
			'rcv_number' => $this->input->post('mobile') ,//회원관리자 모바일 번호
			'sms_content' => "{$users['users_sms_message']}-♥♥{$site['site_title']}" ,//메세지
		);
		return $data;  
	}

	//관리자에게 게시글 sms 발송
	function smss_board_write()
	{
	  $id = $this->id;
	  $this->db->select("board_title,board_admin_mobile");
	  $this->db->where('id', $id);//게시판테이블=게시판관리자레코드
	  $query = $this->db->get('board_admin');//게시판 관리자 테이블
	  $row = $query->row_array();
			$board_title = $row['board_title'];
			$data['snd_number'] = $this->session->userdata('mobile');//보내는사람 번호(글작성자)
			$data['rcv_number'] = $row['board_admin_mobile'];//받는사람 번호(게시판관리자)
			$data['sms_content'] = "{$board_title} 에 게시글이 등록되었습니다.";//전송 내용
		return $data;
	}

	//게시판 답글 원글작성자에게 sms 발송
	function smss_board_reply()
	{
		$id = $this->id;
		$num = $this->num;
		//원글 작성자 게시판 테이블에서 아이디 가져오기
		$this->db->select("wr_user_id");
		$this->db->where('num', $num);
		$query = $this->db->get($this->id);
		$row1 = $query->row_array();
		//원글 작성자 users테이블에서 핸드폰번호 가져오기
		$this->db->select("mobile,nickname");
		$this->db->where('username', $row1['wr_user_id']);
		$query = $this->db->get('users');
		$row2 = $query->row_array();
			$data['snd_number'] = $this->session->userdata('mobile');//보내는사람 번호(답글작성자)
			$data['rcv_number'] = $row2['mobile'];//받는사람 번호(원글작성자)
			$data['sms_content'] = "{$row2['nickname']}님이 작성하신 게시글에 답글이 등록되었습니다.";//전송 내용
		return $data;
	}

	//발송된 메일 보기
	function sms_read()
	{
		$smss_no = $this->no;
		$this->db->where('smss_no', $this->no);
		$query = $this->db->get($this->id);
		$data = $query->row_array();
		return $data;
	}

	//SMS발송 내력 삭제 및 본문 삽입 이미지 삭제
	function sms_delete()
	{
		$this->db->select("*");
		$this->db->where('smss_no', $this->no);
		$query = $this->db->get($this->id);
		$data = $query->row_array();
		preg_match_all('/<img.*?src="([^"]+)"[^>]*>/i',$data['sms_content'],$matches);//이미지추출
			if($matches[0][0]){
				$unique = array_unique($matches[0]);//중복이미지 제거
				$data['sms_content'] = str_replace($unique,'',$data['sms_content']);//본문이미지테그삭제
				foreach ( $unique as $k=>$str )
				{ 
					$filename = './file/editor/'.basename($matches[1][$k]);
					if ( is_file($filename) ) unlink($filename);
				}
			}
		//레코드 삭제
		$this->db->where('smss_no', $this->no);
		$this->db->delete($this->id);
	}
} 
?>