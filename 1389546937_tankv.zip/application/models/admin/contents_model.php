<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Contents_model extends CI_Model
{

	//모델 생성자 호출
	function contents_model()
	{
		parent::__construct();
	}

	//게시물 총수 (검색용)
	function total_entry()
	{
		$query = $this->db->get($this->id);
		return $query->num_rows();
	}

	//목록
	function select($list_num,$offset,$data)
	{
		$this->db->select('*');
		if($data['key'] && $data['keyword'])
		{
			$this->db->like($data['key'], $data['keyword']); 
		}
		$this->db->order_by('no desc');
		$this->db->limit($offset, $list_num);
		$query = $this->db->get($this->id);
		return $query->result();
	}

	//페이지 생성
	function write()
	{
		$data = $this->input->post(NULL, TRUE);
		$data['con_ip'] = $this->input->ip_address(NULL, TRUE);
		$data['con_wdate'] = date("Y-m-d H:i",time());
		$this->db->insert($this->id,$data);
	}

	//페이지 읽기
	function read()
	{
		$no = $this->no;
		$this->db->where('no', $no);
		$query = $this->db->get($this->id);
		$data = $query->row_array();
		//카운터 증가
		$data2 = array('con_view' => $data['con_view']+1);
		$this->db->where('no', $this->no);
		$this->db->update($this->id, $data2);
		return $data;
	}

	//콘텐츠 수정 폼
	function edit_form()
	{
		$no = $this->no;
		$this->db->select("*");
		$this->db->where('no', $no);
		$query = $this->db->get($this->id);
		$data = $query->row_array();
		return $data;
	}

	//콘텐츠 수정
	function edit()
	{
		$data = $this->input->post(NULL, TRUE);
		$data['con_ip'] = $this->input->ip_address(NULL, TRUE);
		$data['con_wdate'] = date("Y-m-d H:i",time());
		$this->db->where('no', $this->no);
		$this->db->update($this->id, $data);
	}

	//콘텐츠 삭제(이미지들삭제, 레코드삭제)
	function delete()
	{
		//첨부(본문에 있는 이미지 테그 기준) 이미지 삭제
		//smard_editor/.../fileuploader.php의 경로도 같이 변경해줘야 함
		$this->db->select("content");
		$this->db->where('no', $this->no);
		$query = $this->db->get($this->id);
		$data = $query->row_array();
		preg_match_all('/<img.*?src="([^"]+)"[^>]*>/i',$data['content'],$matches);//이미지추출
			if($matches[0][0]){
				$unique = array_unique($matches[0]);//중복이미지 제거
				$data['content'] = str_replace($unique,'',$data['content']);//본문이미지테그삭제
				foreach ( $unique as $k=>$str )
				{ 
					$filename = './file/editor/'.basename($matches[1][$k]);
					if ( is_file($filename) ) unlink($filename);
				}
			}
		//레코드 삭제
		$this->db->where('no', $this->no);
		$this->db->delete($this->id);
	}
}
?>