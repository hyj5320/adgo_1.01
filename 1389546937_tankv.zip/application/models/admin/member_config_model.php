<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class	Member_config_model extends CI_Model 
{

	// 모델 생성자 호출
	function member_config_model()
	{
		parent::__construct();
	}

	//회원관리 설정 정보
	function users()
	{
		$this->db->select("*");
		$this->db->where('users_no', 1);
		$query = $this->db->get('users_config');
		$users = $query->row_array();
		return $users;
	}

	//회원관리설정 수정
	function member_config()
	{
		$data = $this->input->post(NULL, TRUE);
		$data['users_date'] = date("Y-m-d H:i",time());
		$this->db->where('users_no', '1');
		$this->db->update('users_config', $data);
	}
}
?>