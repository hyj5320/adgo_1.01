<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Board_model extends CI_Model {

	// 모델 생성자 호출
	function board_model()
	{
		parent::__construct();
	}

	// 게시물 총수 (검색용)
	function total_entry()
	{
		$query = $this->db->get($this->id);
		return $query->num_rows();
	}

	// 목록
	function select($list_num,$offset,$data)
	{
		$this->db->select('*');
		if($data['key'] && $data['keyword'])
		{
			$this->db->like($data['key'], $data['keyword']); 
		}
		$this->db->order_by('no desc');
		$this->db->limit($offset, $list_num);
		$query = $this->db->get($this->id);
		return $query->result();
	}

	//게시판 관리설정 입력
	function write()
	{
		$data = $this->input->post(NULL, TRUE);
		$data['board_admin_date'] = date("Y-m-d H:i",time());
		$this->db->insert($this->id,$data);

//게시판 원글 테이블 생성
$this->db->query("CREATE TABLE {$this->input->post('id')}(
  `num` int(11) NOT NULL AUTO_INCREMENT,
  `gnum` int(10) unsigned DEFAULT '0',
  `depth` varchar(10) NOT NULL DEFAULT 'A',
  `category` varchar(100) DEFAULT NULL,
  `wr_user_id` varchar(50) NOT NULL,
  `nick_name` varchar(50) NOT NULL,
  `name` varchar(20) NOT NULL,
  `subject` varchar(70) NOT NULL,
  `content` text NOT NULL,
  `file1` varchar(100) NOT NULL,
  `wdate` datetime NOT NULL,
  `ip` varchar(15) NOT NULL,
  `bad_count` int(11) NOT NULL DEFAULT '0' COMMENT '신고카운터',
  `good_count` int(11) NOT NULL DEFAULT '0' COMMENT '추천카운터',
  `view` int(11) NOT NULL DEFAULT '0',
  `comments` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`num`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8");

//게시판 댓글 테이블 생성
$this->db->query("CREATE TABLE {$this->input->post('id')}_comments(
  `num` int(11) NOT NULL AUTO_INCREMENT,
  `gno` int(10) unsigned DEFAULT '0',
  `depth` varchar(20) NOT NULL DEFAULT 'A',
  `co_user_id` varchar(50) NOT NULL,
  `co_nick_name` varchar(50) NOT NULL,
  `co_file1` varchar(50) NOT NULL,
  `name` varchar(20) NOT NULL DEFAULT '',
  `password` varchar(20) NOT NULL DEFAULT '',
  `memo` text NOT NULL,
  `comment_bad_count` int(11) DEFAULT NULL COMMENT '댓글신고카운터',
  `comment_good_count` int(11) DEFAULT NULL COMMENT '댓글추천카운터',
  `regdate` datetime NOT NULL,
  `parent` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`num`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8");
	}

	//게시판 관리 테이블 수정 폼
	function edit_form()
	{
		$no = $this->no;
		$this->db->select("*");
		$this->db->where('no', $no);
		$query = $this->db->get('board_admin');
		$data = $query->row_array();
		return $data;
	}

	//게시판 관리테이블 수정
	function edit()
	{
		$data = $this->input->post(NULL, TRUE);
		$data['board_admin_date'] = date("Y-m-d H:i",time());
		$this->db->where('no', $this->no);
		$this->db->update($this->id, $data);
	}

	//게시판 테이블 삭제
	function delete(){
		$no = $this->no;

		//관리 테이블 레코드 삭제
		$this->db->where('no', $no);
		$this->db->delete('board_admin');

		//게시판 테이블 삭제
		$this->load->dbforge();
		$this->dbforge->drop_table($this->id);

		//게시판 첨부파일과 디렉토리 삭제
		$dir = "./file/board/$this->id/";
		foreach (scandir($dir) as $item)
		{
			if ($item == '.' || $item == '..') continue;
			unlink($dir.DIRECTORY_SEPARATOR.$item);
		}
		rmdir($dir);

		//댓글 테이블 삭제
		$this->dbforge->drop_table("{$this->id}_comments");
	}
}
?>