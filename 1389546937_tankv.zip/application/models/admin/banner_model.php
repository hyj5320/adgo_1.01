<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Banner_model extends CI_Model
{

	//모델 생성자 호출
	function banner_model()
	{
		parent::__construct();
	}

	//베너 총수 (검색용)
	function total_entry()
	{
		$query = $this->db->get($this->id);
		return $query->num_rows();
	}

	//베너 목록
	function select($list_num,$offset,$data)
	{
		$this->db->select('*');
		if($data['key'] && $data['keyword'])
		{
			$this->db->like($data['key'], $data['keyword']); 
		}
		$this->db->order_by('banner_num desc');
		$this->db->limit($offset, $list_num);
		$query = $this->db->get($this->id);
		return $query->result();
	}

	//베너 생성
	function write()
	{
		$uploadfile ="";
		//저장 디렉토리
		$dir="./file/$this->id/";
		//파일 업로드
		include('include/upload/upload.php'); 
		$data = $this->input->post(NULL, TRUE);
		$data['banner_image'] = $uploadfile;
		$data['banner_ip'] = $this->input->ip_address(NULL, TRUE);
		$data['banner_date'] = date("Y-m-d H:i",time());
		unset($data['MAX_FILE_SIZE']);
		$this->db->insert($this->id,$data);
	}

	//베너 수정 폼
	function edit_form()
	{
		$no = $this->no;
		$this->db->select("*");
		$this->db->where('banner_num', $no);
		$query = $this->db->get($this->id);
		$data = $query->row_array();
		return $data;
	}

	//베너 관리테이블 수정
	function edit()
	{

		//기존 파일명을 가져온다.(수정시에 업로드 안할시에 기존이미지  유지)
		$data = $this->banner_model->edit_form();
		$uploadfile = $data['banner_image'];

	  	//파일 저장 디렉토리
		$dir="./file/$this->id/";
		include('include/upload/upload.php');
		$data = $this->input->post(NULL, TRUE);
		$data['banner_image'] = $uploadfile;
		$data['banner_ip'] = $this->input->ip_address(NULL, TRUE);
		$data['banner_date'] = date("Y-m-d H:i",time());
		unset($data['MAX_FILE_SIZE']);
		$this->db->where('banner_num', $this->no);
		$this->db->update($this->id, $data);
	}

	//레코드 삭제와 이미지 삭제
	function delete()
	{
		$no = $this->no;
		$this->db->where('banner_num', $no);
		$query = $this->db->get($this->id);
		$row = $query->row_array();
		if(isset($row['banner_image']))
		{
			@unlink("file/$this->id/".$row['banner_image']);
		}
			$this->db->where('banner_num', $no);
			$this->db->delete($this->id);
	}			
}
?>