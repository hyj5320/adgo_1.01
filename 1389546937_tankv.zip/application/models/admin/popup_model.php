<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Popup_model extends CI_Model
{

	//모델 생성자 호출
	function popup_model()
	{
		parent::__construct();
	}

	//팝업 총수 (검색용)
	function total_entry()
	{
		$query = $this->db->get($this->id);
		return $query->num_rows();
	}

	//팝업목록
	function select($list_num,$offset,$data)
	{
		$this->db->select('*');
		if($data['key'] && $data['keyword'])
		{
			$this->db->like($data['key'], $data['keyword']); 
		}
		$this->db->order_by('popup_no desc');
		$this->db->limit($offset, $list_num);
		$query = $this->db->get($this->id);
		return $query->result();
	}

	//팝업  생성
	function write()
	{
		$start_y= $this->input->post('start_y', TRUE);
		$start_m= sprintf('%02d',$this->input->post('start_m', TRUE));
		$start_d= sprintf('%02d',$this->input->post('start_d', TRUE));
		$start_h= sprintf('%02d',$this->input->post('start_h', TRUE));
		$start_i= sprintf('%02d',$this->input->post('start_i', TRUE));

		$end_y= $this->input->post('end_y', TRUE);
		$end_m= sprintf('%02d',$this->input->post('end_m', TRUE));
		$end_d= sprintf('%02d',$this->input->post('end_d', TRUE));
		$end_h= sprintf('%02d',$this->input->post('end_h', TRUE));
		$end_i= sprintf('%02d',$this->input->post('end_i', TRUE));

		$data = $this->input->post(NULL, TRUE);
		$data['popup_start_date'] = "$start_y$start_m$start_d$start_h$start_i";
		$data['popup_end_date'] = "$end_y$end_m$end_d$end_h$end_i";
		$data['popup_date'] = date("Y-m-d H:i",time());
		unset($data['start_y'],$data['start_m'],$data['start_d'],$data['start_h'],$data['start_i']);
		unset($data['end_y'],$data['end_m'],$data['end_d'],$data['end_h'],$data['end_i']);
		$this->db->insert($this->id,$data);
	}

	//팝업 읽기
	function read()
	{
		$no = $this->no;
		$this->db->where('popup_no', $no);
		$query = $this->db->get($this->id);
		$data = $query->row_array();
		return $data;
	}

	//팝업 수정 폼
	function edit_form()
	{
		$no = $this->no;
		$this->db->select("*");
		$this->db->where('popup_no', $no);
		$query = $this->db->get($this->id);
		$data = $query->row_array();
		return $data;
	}

	//팝업 수정
	function edit()
	{
		$start_y= $this->input->post('start_y', TRUE);
		$start_m= sprintf('%02d',$this->input->post('start_m', TRUE));
		$start_d= sprintf('%02d',$this->input->post('start_d', TRUE));
		$start_h= sprintf('%02d',$this->input->post('start_h', TRUE));
		$start_i= sprintf('%02d',$this->input->post('start_i', TRUE));

		$end_y= $this->input->post('end_y', TRUE);
		$end_m= sprintf('%02d',$this->input->post('end_m', TRUE));
		$end_d= sprintf('%02d',$this->input->post('end_d', TRUE));
		$end_h= sprintf('%02d',$this->input->post('end_h', TRUE));
		$end_i= sprintf('%02d',$this->input->post('end_i', TRUE));

		$data = $this->input->post(NULL, TRUE);
		$data['popup_start_date'] = "$start_y$start_m$start_d$start_h$start_i";
		$data['popup_end_date'] = "$end_y$end_m$end_d$end_h$end_i";
		$data['popup_date'] = date("Y-m-d H:i",time());
		unset($data['start_y'],$data['start_m'],$data['start_d'],$data['start_h'],$data['start_i']);
		unset($data['end_y'],$data['end_m'],$data['end_d'],$data['end_h'],$data['end_i']);

		$this->db->where('popup_no', $this->no);
		$this->db->update($this->id, $data);
	}

	//팝업 삭제(이미지들삭제, 레코드삭제)
	function delete()
	{
		//첨부(본문에 있는 이미지 테그 기준) 이미지 삭제
		//smard_editor/.../fileuploader.php의 경로도 같이 변경해줘야 함
		$this->db->select("popup_content");
		$this->db->where('popup_no', $this->no);
		$query = $this->db->get($this->id);
		$data = $query->row_array();
		preg_match_all('/<img.*?src="([^"]+)"[^>]*>/i',$data['popup_content'],$matches);//이미지추출
			if($matches[0][0]){
				$unique = array_unique($matches[0]);//중복이미지 제거
				$data['content'] = str_replace($unique,'',$data['popup_content']);//본문이미지테그삭제
				foreach ( $unique as $k=>$str )
				{ 
					$filename = './file/editor/'.basename($matches[1][$k]);
					if ( is_file($filename) ) unlink($filename);
				}
			}
		//레코드 삭제
		$this->db->where('popup_no', $this->no);
		$this->db->delete($this->id);
	}
}
?>