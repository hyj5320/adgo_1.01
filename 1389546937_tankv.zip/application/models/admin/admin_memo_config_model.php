<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Admin_memo_config_model extends CI_Model 
{

	// 모델 생성자 호출
	function admin_memo_config_model()
	{
		parent::__construct();
	}

	//사이트 설정 수정 폼
	function index()
	{
		$this->db->select("*");
		$this->db->where('no', '1');
		$query = $this->db->get('memo_admin');
		$data = $query->row_array();
		return $data;
	}

	//사이트 설정 수정
	function edit()
	{
		//기존 파일명을 가져온다.
		$data = $this->admin_memo_config_model->index();

		$data = $this->input->post(NULL, TRUE);
		$data['ip'] = $this->input->ip_address(NULL, TRUE);
		$data['date'] = date("Y-m-d H:i",time());

		$this->db->where('no', '1');
		$this->db->update('memo_admin', $data);
	}
}
?>