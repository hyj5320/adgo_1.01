<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Search_model extends CI_Model {

	function __construct()
	{
		parent::__construct();
		$this->table = '';
	}

	//통합검색
	function search_list($page, $rp, $post)
	{
		$field = " num, content, subject, name, wr_user_id, view, comments, wdate ";
		$where = " WHERE (subject like \"%".$post['s_word']."%\" or content like \"%".$post['s_word']."%\")";

		$sql = "SELECT b.nickname, a.table, a.tbn, a.num, a.content, a.subject, a.name, a.wr_user_id, a.view, a.comments, a.wdate from ( ";

		$this->db->select("id , board_name");
		$query = $this->db->get('board_admin');
		//전체 게시판 통합검색
		foreach($query->result() as $row)
		{
			$sql.= "(SELECT '$row->board_name' as 'table', '$row->id' as 'tbn', ".$field." FROM $row->id ".$where.") UNION "; 
		}
			$sql.= "(SELECT '$row->board_name' as 'table', '$row->id' as 'tbn', ".$field." FROM $row->id ".$where.")";

		$sql.= ") as a, users b where a.wr_user_id=b.username order by view desc limit $page, $rp";
		//echo $this->db->last_query();
			$rs = $this->db->query($sql);
			return $rs->result_array();
	}

	//통합검색 카운터
	function search_total($post)
	{
		//print_r($post);//검색어
		/*
		if ($post) 
		{
			$this->db->like($post["method"], $post["s_word"]);
		}
  		$this->db->where(array('is_delete'=>'N', 'original_no'=>'0'));

		$query = $this->db->get($this->table);
		*/

		$field = " num, content, subject, name, wr_user_id, view, comments, wdate ";
		$where = " WHERE (subject like \"%".$post['s_word']."%\" or content like \"%".$post['s_word']."%\")";

		$sql = "SELECT b.nickname, a.table, a.tbn, a.num, a.content, a.subject, a.name, a.wr_user_id, a.view, a.comments, a.wdate from ( ";

		$this->db->select("id , board_name");
		$query = $this->db->get('board_admin');
		//전체 게시판 통합검색
		foreach($query->result() as $row){
			$sql.= "(SELECT '$row->board_name' as 'table', '$row->id' as 'tbn', ".$field." FROM $row->id ".$where.") UNION "; 
		}
			$sql.= "(SELECT '$row->board_name' as 'table', '$row->id' as 'tbn', ".$field." FROM $row->id ".$where.")";

		$sql.= ") as a, users b where a.wr_user_id=b.username order by view desc";
		$rs = $this->db->query($sql);
		return $rs->num_rows();
	}
}
?>