<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Main_model extends CI_Model 
{

	// 모델 생성자 호출
	function Main_model()
	{
		parent::__construct();
	}

	function index(){
		$this->db->order_by('gnum desc, depth asc');
		$this->db->limit(8,0);
		$query = $this->db->get('notice');
		return $query->result();  
	}
}