<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Board_model extends CI_Model 
{

	//모델 생성자 호출
	function board_model()
	{
		parent::__construct();
	}

	//게시판 관리자 설정
	function board_admin()
	{
		//게시판 설정
		$id = $this->id;
		$this->db->select("*");
		$this->db->where('id', $id);
		$query = $this->db->get('board_admin');
		$data = $query->row_array();
		return $data;
	}

	//게시물 총수 (검색용)
	function total_entry()
	{
		$query = $this->db->get($this->id);
		return $query->num_rows();
	}

	//목록
	function select($list_num,$offset,$data)
	{
		$this->db->select('*');
		if(isset($data['key']) && $data['keyword'])
		{
			$this->db->like($data['key'], $data['keyword']); 
		}
		$category=$this->input->post('category', TRUE);
		if($category)
		{
			$this->db->where('category', $category);
		}
		$this->db->order_by('gnum desc, depth asc, num desc');
		$this->db->limit($offset, $list_num);
		$query = $this->db->get($this->id);
		//echo $this->db->last_query(); exit;
		return $query->result();
	}

	//글읽기
	function read()
	{
		$num = $this->num;
		$this->db->where('num', $num);
		$query = $this->db->get($this->id);
		$data = $query->row_array();
		
		// 카운터 증가
		$admin = $this->board_model->board_admin();
		$cookie_data = $this->id."_".$this->num;
		setcookie($cookie_data,time(),time()+($admin['count_time_limit']*60*60));

		if(!isset($_COOKIE[$cookie_data]))
		{
			$data2 = array('view' => $data['view']+1);
			$this->db->where('num', $this->num);
			$this->db->update($this->id, $data2);
		}
		return $data;
	}

	//글쓰기
	function write()
	{
		
		//파일업로드
		$uploadfile ="";
		
		//파일 저장 디렉토리
		$dir="./file/board/$this->id/";
		
		//디렉토리는 1개만 만들어짐 서브디렉토리는 별도 생성해야함(최초1회 사용)
		$dir2="./file/board/";
		if(!is_dir($dir)){mkdir($dir2,0777);};
		
		//파일 업로드
		include('include/upload/upload.php');
		
		//공지사항 설정   
		if($this->input->post('notice'))
		{
			$gnum = 2000000000;
		}
		else 
		{
			$gnum = $this->input->post('gnum');
		}
		
		//금지어 설정
		//스마트에디터 url수정해야할 파일들-QuickPhotoPopup.js, FileUploader.php
		$data= $this->board_model->board_admin();
		$contents = $this->input->post('content', TRUE);
		$board_limit_word  = $data['board_limit_word'];
		$word = explode ("|", $board_limit_word );
		
		//욕 한글자당 * 한개로 치환
		for($i = 0; $i < count($word); $i++) 
		{
			if(strpos($contents, $word[$i]) > -1) 
			{
				$contents = str_replace($word[$i], str_repeat("*", mb_strlen($word[$i],"utf-8")), $contents);
			}
		}
			//$content = str_replace($limit_word,'***',$content2);
			$data=$this->input->post(NULL, TRUE);
			$data['content']=$contents;
			$data['gnum'] = $gnum;
			$data['file1']=$uploadfile;
			$data['wdate']=date("Y-m-d H:i",time());
			$data['ip']=$this->input->ip_address(NULL, TRUE);
			unset($data['MAX_FILE_SIZE']);
			unset($data['notice']); 
		$this->db->insert($this->id,$data);
	}

	//답글 폼
	function reply_form()
	{
		$num = $this->num;
		$this->db->select("*");
		$this->db->where('num', $num);
		$query = $this->db->get($this->id);
		$data = $query->row_array();
		return $data;
	}

	//답글
	function reply()
	{
		$uploadfile = "";

		//파일 저장 디렉토리
		$dir="./file/board/$this->id/";
		
		//파일 업로드
		include('include/upload/upload.php');

		//금지어 설정
		$data= $this->board_model->board_admin();
		$content2 = $this->input->post('content', TRUE);
		$board_limit_word  = $data['board_limit_word'];
		$limit_word  = explode ("|", $board_limit_word );
		$content = str_replace($limit_word,'***',$content2);

		$data = $this->input->post(NULL, TRUE);
		$data['content']=$content;
		$data['file1'] = $uploadfile;
		$data['ip'] = $this->input->ip_address(NULL, TRUE);
		$data['wdate'] = date("Y-m-d H:i",time());
		unset($data['MAX_FILE_SIZE']);
		$this->db->where('num', $this->num);
		$this->db->insert($this->id, $data);
	}

	//댓글쓰기
	function comment_write()
	{
		
		//금지어 설정
		$data= $this->board_model->board_admin();
		$content2 = $this->input->post('memo', TRUE);
		$board_limit_word  = $data['board_limit_word'];
		$limit_word  = explode ("|", $board_limit_word );
		$memo = str_replace($limit_word,'***',$content2);
		
		//댓글쓰기
		$data = $this->input->post(NULL, TRUE);
		$data['memo']=$memo;
		$data['regdate'] = date("Y-m-d H:i",time());
		$this->db->insert("{$this->id}_comments",$data);
		
		// 카운터 증가
		$data = $this->board_model->read();
		$data2 = array('comments' => $data['comments']+1);
		$this->db->where('num', $this->input->post('parent'));
		$this->db->update($this->id, $data2);
	}

	//댓글 읽기
	function comment_read()
	{
		$num = $this->num;
		$this->db->select("*");
		$this->db->where('num', $num);
		$query = $this->db->get($this->id);
		$data = $query->row_array();
		return $data;
	}

	//글수정 폼
	function edit_form()
	{
	  $num = $this->num;
	  $this->db->select("*");
	  $this->db->where('num', $num);
	  $query = $this->db->get($this->id);
	  $data = $query->row_array();
	  return $data;
	}

	//edit->글수정
	function edit()
	{
		
		//기존 파일명을 가져온다.
		$data = $this->board_model->edit_form();
		$uploadfile = $data['file1'];
		
		//파일 저장 디렉토리
		$dir="./file/board/$this->id/";
		
		//파일 업로드
		include('include/upload/upload.php');
		
		//공지사항 설정   
		if($this->input->post('notice'))
		{
			$gnum = 2000000000;
		}
		else 
		{
			$gnum = $this->input->post('gnum', TRUE);
		}

		//파일 업로드 끝
		$data = $this->input->post(NULL, TRUE);
		$data['gnum'] = $gnum;
		$data['file1'] = $uploadfile;
		$data['ip'] = $this->input->ip_address(NULL, TRUE);
		$data['wdate'] = date("Y-m-d H:i",time());
		unset($data['notice']);//좌측 라인 추가 않하면 오류
		unset($data['MAX_FILE_SIZE']);
		$this->db->where('num', $this->num);
		$this->db->update($this->id, $data);
	}

	//글 신고
	function bad_count()
	{
		$num = $this->num;
		$this->db->where('num', $num);
		$query = $this->db->get($this->id);
		$data = $query->row_array();

		$cookie_bad_count = $this->id."_".$this->num;
		setcookie($cookie_bad_count,time(),time()+(24*60*60));//24시간

		// 신고 카운터(쿠키 생성)
		if(isset($_COOKIE[$cookie_bad_count]))
		{
			alert("{$this->session->userdata('nickname')}님이 이미 신고 하셨습니다. 24시간 동안 1회 만 추천 가능합니다.", '');
		}
		elseif(!isset($_COOKIE[$cookie_bad_count]))
		{
			$data2 = array('bad_count' => $data['bad_count']+1);
			$this->db->where('num', $this->num);
			$this->db->update($this->id, $data2);
		}
		return $data;
	}

	//글 추천
	function good_count()
	{
		$num = $this->num;
		$this->db->where('num', $num);
		$query = $this->db->get($this->id);
		$data = $query->row_array();

		//추천 카운터 증가 (쿠키생성)
		$cookie_good_count = $this->id."_".$this->num;
		setcookie($cookie_good_count,time(),time()+(24*60*60));//24시간

		if(isset($_COOKIE[$cookie_good_count]))
		{
			alert("{$this->session->userdata('nickname')}님이 이미 추천 하셨습니다. 24시간 동안 1회 만 추천 가능합니다.", '');
		}
		 elseif(!isset($_COOKIE[$cookie_good_count]))
		{
			$data2 = array('good_count' => $data['good_count']+1);
			$this->db->where('num', $this->num);
			$this->db->update($this->id, $data2);
		}
		return $data;
	}

	//댓글 신고
	function comment_bad_count()
	{
		$num = $this->num;
		$this->db->where('num', $num);
		$query = $this->db->get($this->id);
		$data = $query->row_array();

		$cookie_comment_bad_count = $this->id."_".$this->num;
		setcookie($cookie_comment_bad_count,time(),time()+(24*60*60));//24시간

		// 신고 카운터(쿠키 생성)
		if(isset($_COOKIE[$cookie_comment_bad_count]))
		{
			alert("{$this->session->userdata('nickname')}님은 이미 신고 하셨습니다. 24시간동안 1회 만 신고 가능합니다.", '');
		}
		elseif(!isset($_COOKIE[$cookie_comment_bad_count]))
		{
			$data['comment_bad_count'] = "";
			$data2 = array('comment_bad_count' => $data['comment_bad_count']+1);
			$this->db->where('num', $this->num);
			$this->db->update("{$this->id}_comments", $data2);
		}
		return $data;
	}

	//댓글 추천
	function comment_good_count()
	{
		$num = $this->num;
		$this->db->where('num', $num);
		$query = $this->db->get($this->id);
		$data = $query->row_array();

		$cookie_comment_good_count = $this->id."_".$this->num;
		setcookie($cookie_comment_good_count,time(),time()+(24*60*60));//24시간

		// 댓글 추천 카운터(쿠키 생성)
		if(isset($_COOKIE[$cookie_comment_good_count]))
		{
			alert("{$this->session->userdata('nickname')}님은 이미 추천 하셨습니다. 24시간 동안 1회 만 추천 가능합니다.", '');
		}
		elseif(!isset($_COOKIE[$cookie_comment_good_count]))
		{
			$data['comment_good_count'] = "";
			$data2 = array('comment_good_count' => $data['comment_good_count']+1);
			$this->db->where('num', $this->num);
			$this->db->update("{$this->id}_comments", $data2);
		}
		return $data;
	}

	//게시판 원글 답글 삭제 제어
	function delete()
	{
		$admin = $this->board_admin();
		
		//삭제 게시물 gnum 값 알아내기
		$this->db->select("gnum, depth");
		$this->db->where('num', $this->num);
		$query1 = $this->db->get($this->id);
		$row = $query1->row_array();
		
		//답글에 답글이 있는 답글 삭제금지
		//엄청 삽질함 답글에 답글에 답글 삭제는 처리 완벽
		//답글에 답글에 답글 중 중간 답글에 답글 삭제는 처리가 완벽하진 않음
		$this->db->select("gnum, depth");
		$this->db->where('gnum',  $row['gnum']);
		$this->db->where('LENGTH(depth) >' ,strlen($row['depth']));
		$query2 = $this->db->get($this->id);
		if($admin['board_admin_replys'] <= $query2->num_rows())
		{
			alert("답글이{$admin['board_admin_replys']}개 이상 게시물은 삭제 금지 입니다.");
		}
		
		//댓글있는 게시물 삭제금지
		 $this->db->select("gno");
		$this->db->where('gno', $this->num);
		$query4 = $this->db->get("{$this->id}_comments");
		if($admin['board_admin_comments'] <= $query4->num_rows())
		{
			alert("댓글이 {$admin['board_admin_comments']}개 이상 게시물은 삭제 금지 입니다.");
		}
		
		//첨부(본문에 있는 이미지 테그 기준) 이미지 삭제
		//smard_editor/.../fileuploader.php의 경로도 같이 변경해줘야 함
		$this->db->select("*");
		$this->db->where('num', $this->num);
		$query = $this->db->get($this->id);
		$data = $query->row_array();
			preg_match_all('/<img.*?src="([^"]+)"[^>]*>/i',$data['content'],$matches);//이미지추출
			//echo '<pre>'.print_r($matches).'</pre>';  exit;
			if(isset($matches[0][0])){
				$unique = array_unique($matches[0]);//중복이미지 제거
				$data['content'] = str_replace($unique,'',$data['content']);//본문이미지테그삭제
				foreach ( $unique as $k=>$str )
				{ 
					$filename = './file/editor/'.basename($matches[1][$k]);
					//echo $filename; exit;
					if ( is_file($filename) ) unlink($filename);
				}
			}

		//첨부파일 삭제
		$file1name = $data['file1'];
		if(isset($file1name))
		{
			$file1 = "./file/board/$this->id/$file1name";
			if ( is_file($file1) ) unlink($file1);
		}
		
		//원글 삭제
		$this->db->where('num', $this->num);
		$this->db->delete($this->id); 
		
		//댓글들 삭제
		$this->db->select("gno");
		$this->db->where('gno', $this->num);
		$this->db->delete("{$this->id}_comments"); 
	}

	//해당 댓글삭제와 원글의 댓글 카운터 -1
	function comment_delete()
	{
		
		//댓글의 parent값구하기(원글 num과 값이 같게 저장되어 있음)
		$this->db->select("num, parent");
		$this->db->where('num', $this->num);
		$query = $this->db->get("{$this->id}_comments");
		$row = $query->row_array();
		$parent =$row['parent'];
		
		//댓글의 부모글 댓글카운터 1 감소
		$this->db->where('num', $parent);
		$query2 = $this->db->get($this->id);
		$data2 = $query2->row_array();
		$data3 = array('comments' => $data2['comments']-1);
		$this->db->where('num', $parent);
		$this->db->update($this->id, $data3); 
		//echo $this->db->last_query(); exit;
		
		//해당 댓글 삭제
		$this->db->select("num");
		$this->db->where('num', $this->num);
		$this->db->delete("{$this->id}_comments");
	}
}
?>