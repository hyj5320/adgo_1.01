<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
	if(isset($site_main_layout))
	{
		include "./layouts/main/$site_main_layout/main_top_layout.php";
	}
	else
	{
		alert('관리자/사이트설정/사이트 메인 레이아웃(top)을 확인하세요.'); 
	}
?>