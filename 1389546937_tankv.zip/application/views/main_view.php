<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
	if(isset($site_main_skin))
	{
		include "./skin/main/$site_main_skin/main_skin.php";
	}
	else
	{
		alert('관리자/사이트설정/사이트 메인 스킨을 확인하세요.'); 
	}
?>