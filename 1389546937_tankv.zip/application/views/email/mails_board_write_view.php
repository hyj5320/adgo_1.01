<?php 
//게시판 글쓰기 관리자에게 메일 발송
//제목 내용에 한글이 없을시에 제대로 포털에 발송 되지 않는 경우가 있습니다.
	$this->email->from($client_email, $client_name);
	$this->email->to($mail_to);
	$this->email->subject($subject); 
	$this->email->message($content);
	$this->email->send();
		//echo $this->email->print_debugger();
		//exit;
?>