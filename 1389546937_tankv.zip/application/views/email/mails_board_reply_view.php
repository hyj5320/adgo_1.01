<?php
//게시판 답글 원글 게시자에게 메일 발송
	$this->email->from($client_email, $client_name);
	$this->email->to($mail_to);
	$this->email->subject($subject);
	$this->email->message($content);
	$this->email->send();
	//echo $this->email->print_debugger();
	//exit;
?>