<SCRIPT LANGUAGE=JAVASCRIPT>  
	function search_confirm()
	{
		if(document.search_form.keyword.value == '')
		{
			alert('검색어를 입력하세요.');
			document.search_form.keyword.focus();
			return;
		}
		document.search_form.submit();
	}
</SCRIPT>

<h1>발송된 메일 리스트</h1>

<table align="center" cellpadding="0" cellspacing="0" width="100%">
	<form name="search_form" method="post" action="<?php echo $act_url?>">
		<tr>
			<td width="60%">
				<select class="span3" name="key">
					<option value="mails_to" <?php if($key == "mails_to") echo "selected"; ?>>받는메일</option>
					<option value="subject" <?php if($key == "subject") echo "selected"; ?>>메일제목</option>
					<option value="content" <?php if($key == "content") echo "selected"; ?>>메일내용</option>
				</select>
				<input class="input-small" type="text" placeholder=".input-small" name="keyword" size="9" value="<?php echo $keyword?>">
				<b><INPUT class="btn btn-small" type=button value="검색" name="formbutton1" onclick="search_confirm();"></b>
			</td>
			<td width="40%">
				<p align="right"> 콘텐츠 : <?php echo $total_record?>개 ( <?php echo $page?> 페이지 / 총 <?php echo $total_page?> 페이지 )</p>
			</td>
		</tr>
	</form>
</table>

<table class="table table-hover" border="0">
		<tr bgcolor="#F6F6F6">
		<td align=center>번호</font>
		<td align=center>보내는사람</font>
		<td align=center>메일제목</font>
		<td align=center>발송시간</font>
		<td align=center>삭제</font>
		<td align=center>보기</font>
	<tr>
<?php foreach($result as $row){ ?>
	<tr>
		<td align=center><?php echo $row->mails_no?>
		<td align=center><?php echo $row->client_name?>
		<td align=center><?php echo $row->subject?>
		<td align=center><?php echo $row->mails_date?>
		<td align=center><a href=<?php echo base_url()?>admin/mails/mails_delete/id/<?php echo $this->id?>/page/<?php echo $this->page?>/no/<?php echo $row->mails_no?> onclick="return confirm('삭제하시겠습니까?')">삭제</a>
		<td align=center><a href=<?php echo base_url()?>admin/mails/mails_read/id/<?php echo $this->id?>/page/<?php echo $this->page?>/no/<?php echo $row->mails_no?>>보기</a>
	<tr>
<?php } ?>
</table>

<table border="0" width="100%">
	<tr>
		<td id="pagination" align="center">
		<?php echo $pagenum?>
</table>

		<div align="center">
			<input class="btn btn-small btn-info" type="button" value="메일 작성" onclick="location.href='<?php echo base_url()?>admin/mails/mails_form/id/<?php echo $this->id?>'";>
			<input class="btn btn-small" type="button" onclick="history.back(1)" value="이전" />
		</div>
