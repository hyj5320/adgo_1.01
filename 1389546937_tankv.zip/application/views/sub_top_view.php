<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
	if(isset($site_sub_layout))
	{
		include "./layouts/sub/$site_sub_layout/sub_top_layout.php";
	}
	else
	{
		alert('관리자/사이트설정/서브레이아웃(top)을 확인하세요.'); 
	}
?>