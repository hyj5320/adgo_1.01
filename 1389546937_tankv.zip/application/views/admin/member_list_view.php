<script>
$.datepicker.regional['ko']= {
closeText:'닫기',
prevText:'이전달',
nextText:'다음달',
currentText:'오늘',
monthNames:['1월(JAN)','2월(FEB)','3월(MAR)','4월(APR)','5월(MAY)','6월(JUM)','7월(JUL)','8월(AUG)','9월(SEP)','10월(OCT)','11월(NOV)','12월(DEC)'],
monthNamesShort:['1월','2월','3월','4월','5월','6월','7월','8월','9월','10월','11월','12월'],
dayNames:['일','월','화','수','목','금','토'],
dayNamesShort:['일','월','화','수','목','금','토'],
dayNamesMin:['일','월','화','수','목','금','토'],
weekHeader:'Wk',

dateFormat:'yy-mm-dd',
showAnim: "slideDown",
changeMonth: true,
changeYear: true,
yearRange: "-60:-0",
showOn: "both",
buttonImage: "<?php echo base_url()?>images/calendar.gif", 
buttonImageOnly: true,

firstDay:0,
isRTL:false,
showMonthAfterYear:true,
yearSuffix:''
};

$(function() 
{
	$.datepicker.setDefaults( $.datepicker.regional[ "" ] ); 
	$( "#datepicker" ).datepicker( $.datepicker.regional[ "ko" ] ); 
});

$(function() 
{
	$.datepicker.setDefaults( $.datepicker.regional[ "" ] ); 
	$( "#datepicker2" ).datepicker( $.datepicker.regional[ "ko" ] ); 
});
</script>

<SCRIPT LANGUAGE=JAVASCRIPT>  
function search_confirm()
{
	if(document.search_form.keyword.value == '')
	{
		alert('검색어를 입력하세요.');
		document.search_form.keyword.focus();
		return;
	}
	document.search_form.submit();
}
</SCRIPT>

<h1>회원 리스트</h1>
<form name="fboardform" method="post" action="<?php echo base_url()?>admin/member/index/table/<?php echo $this->table?>/page/1">
	<select class="span2" name="activated" onchange="document.forms['fboardform'].submit();"> 
		<option value="">회원인증</option>
		<option value="">--------------</option>
		<option value="1">인증</option>
		<option value="0">미인증</option>
	</select>
	<script type="text/javascript">document.fboardform.activated.value="<?php echo $activated?>";</script>

	<select class="span2" name="banned" onchange="document.forms['fboardform'].submit();"> 
		<option value="">불량회원</option>
		<option value="">--------------</option>
		<option value="0">정상회원</option>
		<option value="1">불량회원</option>
	</select>
	<script type="text/javascript">document.fboardform.banned.value="<?php echo $banned?>";</script>

	<select class="span2"  name="users_out" onchange="document.forms['fboardform'].submit();"> 
		<option value="">회원탈퇴</option>
		<option value="">-------------</option>
		<option value="1">정상회원</option>
		<option value="0">탈퇴회원</option>
	</select>
	<script type="text/javascript">document.fboardform.users_out.value="<?php echo $users_out?>";</script>

	<select class="span2" name="level" onchange="document.forms['fboardform'].submit();"> 
		<option value="">레벨</option>
		<option value="">---------</option>
		<option value="1">1레벨</option>
		<option value="2">2레벨</option>
		<option value="3">3레벨</option>
		<option value="4">4레벨</option>
		<option value="5">5레벨</option>
		<option value="6">6레벨</option>
		<option value="7">7레벨</option>
		<option value="8">8레벨</option>
		<option value="9">9레벨</option>
		<option value="10">10레벨</option>
	</select>
	<script type="text/javascript">document.fboardform.level.value="<?php echo $level?>";</script>

	<select class="span2" name="address1" onchange="document.forms['fboardform'].submit();"> 
		<option value="">지역</option>
		<option value="">---------</option>
		<option value="서울">서울</option>
		<option value="경기">경기</option>
		<option value="인천">인천</option>
		<option value="강원">강원</option>
		<option value="충남">충남</option>
		<option value="충북">충북</option>
		<option value="대전">대전</option>
		<option value="전남">전남</option>
		<option value="전북">전북</option>
		<option value="광주">광주</option>
		<option value="경남">경남</option>
		<option value="경북">경북</option>
		<option value="부산">부산</option>
		<option value="대구">대구</option>
		<option value="울산">울산</option>
		<option value="제주">제주</option>
		<option value="해외">해외</option>
		<option value="없음">없음</option>
	</select>
	<script type="text/javascript">document.fboardform.address1.value="<?php echo $address1?>";</script>

	<select class="span2" name="sex" onchange="document.forms['fboardform'].submit();"> 
		<option value="">성별</option>
		<option value="">----</option>
		<option value="남자">남성</option>
		<option value="여자">여성</option>
	</select>
	<script type="text/javascript">document.fboardform.sex.value="<?php echo $sex?>";</script>

	<li>가입일<input class="input-small" type="text" placeholder=".input-small" name="created"  id="datepicker" size="12" onchange="document.forms['fboardform'].submit();"/>
	<script type="text/javascript">document.fboardform.created.value="<?php echo $created?>";</script>

	생일<input class="input-small" type="text" placeholder=".input-small" name="birthday"  id="datepicker2" size="12" onchange="document.forms['fboardform'].submit();"/>
	<script type="text/javascript">document.fboardform.birthday.value="<?php echo $birthday?>";</script>
</form>

<table border="0" align="center" cellpadding="0" cellspacing="0" width="100%">
	<form name="search_form" method="post" action="<?php echo $act_url?>">
	<tr>
		<td width="55%">
<?php
	$key = "";
	$keyword = "";
?>
			<select class="span3" name="key">
				<option value="username" <?php if($key == "username") echo "selected"; ?>>회원 id</option>
				<option value="kname" <?php if($key == "kname") echo "selected"; ?>>이름</option>
				<option value="nickname" <?php if($key == "nickname") echo "selected"; ?>>닉네임</option>
			</select>
			<input class="input-small" type="text" placeholder=".input-small" name="keyword" size="9" value="<?php echo $keyword?>">
			<INPUT class="btn btn-small" type="button" value="검색" name="formbutton1" onclick="search_confirm();">
		</td>
		<td width="45%">
			<p align="right"> 총 회원수 : <?php echo $total_record?>명 ( <?php echo $page?> 페이지 / 총 <?php echo $total_page?> 페이지 )</p>
		</td>
	</tr>
	</form>
</table>

<table class="table table-hover">
	<tr class="success">
		<td>번호</font>
		<td>id</font>
		<td>이름</font>
		<td>이메일</font>
		<td>레벨</font>
		<td>인증</font>
		<td align=center>수정</font>
		<td align=center>삭제</font>
	<tr>
<?php foreach($result as $row){ ?>
	<tr>
		<td><?php echo $row->id?>
		<td><?php echo $row->username?></a>
		<td>
<!--  
<?php if($row->file1){ ?>  
			<img src=<?php echo base_url()?>/file/<?php echo $this->table?>/<?php echo $row->file1?> height='20' border="0"></a>
<?php }?>
-->
<?php echo $row->nickname?>
		<td><?php echo $row->email?>
		<td><?php echo $row->level?>
		<td><?php echo $row->activated?>
		<td align=center><a href=<?php echo base_url()?>admin/member/edit_form/table/<?php echo $this->table?>/page/<?php echo $this->page?>/id/<?php echo $row->id?>>수정</a>
		<td align=center><a href=<?php echo base_url()?>admin/member/delete/table/<?php echo $this->table?>/page/<?php echo $this->page?>/id/<?php echo $row->id?> onclick="return confirm('삭제하시겠습니까?')">삭제</a>
	<tr>
<?php } ?>
</table>
<table border=0 width=100%>
	<tr>
		<td id=pagination align=center>
			<?php echo $pagenum?>
	<tr>
		<td align=center>
			<input class="btn btn-small btn-info" type="button" value="회원 생성" onclick="location.href='<?php echo base_url()?>/admin/member/write_form/table/<?php echo $this->table?>/id/<?php echo $this->id?>'";>
			<input class="btn btn-small" type="button" onclick="history.back(1)" value="이전" />
</table>