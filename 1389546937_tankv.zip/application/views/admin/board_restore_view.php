복구할 파일을 업로드 하시면 자동으로 해당 데이터베이스 테이블을 복구합니다.<br>
<font color="red">※ 이 프로그램에서 백업 받은 sql만 정상복구합니다.</font><br>
<?php echo $error;?>

<?php echo form_open_multipart($this->uri->uri_string());?>

<input type="file" name="userfile" size="20" />

<br /><br />

<input type="submit" value="게시판 복구" />
<?php form_close();?>