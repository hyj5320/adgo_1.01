<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<script type="text/javascript" src="<?php echo base_url()?>editor/smart_editor/js/HuskyEZCreator.js" charset="utf-8"></script>

<script>
$("document").ready(function(){
	$("a").each(function(){
		if ($(this).attr("id")=='board_restore'){
			$(this).click(function() {
				var bd_no = $(this).attr("rev");
				window.open('<?php echo base_url()?>admin/board/board_restore/'+bd_no,'board_restore','scrollbars=yes,toolbar=no,resizable=no,menubar=no,location=no,width=600,height=200,left=0,top=0');
			});
		}
	});
});
</script>

<?php $attributes = array('name' => 'fboardform', 'id' => '');?>
<?php echo form_open_multipart("admin/board/edit_form/id/$this->id/no/$no/",$attributes);?>

<h1><?php echo $board_title?> 설정수정</h1>

최종수정일 : <?php echo $board_admin_date?>

<div align="right">
	<a class="btn btn-mini" href="<?php echo base_url()?>board/index/id/<?php echo $id?>"><i class="icon-eye-open"></i>게시판확인</a>
</div>

<table class="table table-hover" border="0" width="100%">
	<tr>
		<td width=150>게시판 id
		<td width=270> <?php echo $id?> 아이디는 변경 금지
		<td>
	<tr>
		<td>게시판 테이블 백업
			<div id="admin_management_bakgrd">
				<div id="admin_tb_box3">
		<td>
			<a href="<?php echo base_url()?>admin/board/board_backup/id/<?php echo $this->id?>/no/<?php echo $this->no?>" class="btn">게시판 DB백업</button></a>
		<!--  
				&nbsp;&nbsp; <a href="#" id="board_restore">복구</a>
		-->
		<td>
				</div>
	<tr>
		<td>게시판 타이틀
		<td><input type="text" name="board_title" size="40" maxlength="50" value="<?php echo set_value('board_title',$board_title); ?>">
		<td><?php echo form_error('board_title'); ?>
	<tr>
		<td>게시판 폭<li>(예)90%, 1000	
		<td><input type=text name=width size=10 maxlength=10 value="<?php echo set_value('width',$width); ?>"> 
		<td><?php echo form_error('width'); ?>
	<tr>
		<td>게시판 스킨
		<td><select name=board_skin required itemname="스킨 디렉토리">
<?php		//기존 함수를 helper함수로 교체함
			$arr = directory_map("./skin/board/",1);
			//$arr = get_skin_dir("skin");
			for ($i=0; $i<count($arr); $i++) 
			{
				echo "<option value='$arr[$i]'>$arr[$i]</option>\n";
			}
?>
			<!--fboardform과 폼name를 맞춰줘야 value작동함-->
			<script type="text/javascript">document.fboardform.board_skin.value="<?php echo $board_skin?>"</script>
		<td>
	<tr>
		<td>메뉴출력여부
		<td>		
			<select name="board_use"> 
				<option value="1" <?php echo set_select('board_use', '1', TRUE); ?> >사용</option> 
				<option value="0" <?php echo set_select('board_use', '0'); ?> >미사용</option> 
		<td><?php echo form_error('board_use'); ?>
			<script type="text/javascript">document.fboardform.board_use.value="<?php echo $board_use?>";</script>
	<tr>
		<td>메뉴출력순서
		<td><?php echo get_member_level_select('board_sequence', 1, 10, $board_sequence) ?>
		<li>숫자가 높을수록 상단이나 좌측에 노출
		<td>
	<tr>
		<td>메뉴출력위치
		<td>
			<select name="board_place" > 
				<option value="main_top" <?php echo set_select('board_place', 'main_top', TRUE); ?> >메인페이지 상단</option> 
				<option value="main_left" <?php echo set_select('board_place', 'main_left'); ?> >메인페이지 왼쪽</option> 
				<option value="main_right" <?php echo set_select('board_place', 'main_right'); ?> >메인페이지 오른쪽</option> 
				<option value="main_foot" <?php echo set_select('board_place', 'main_foot'); ?> >메인페이지 아래쪽</option> 
				<option value="main_middle" <?php echo set_select('board_place', 'main_middle'); ?> >메인페이지 중간</option> 
				<option value="board_top" <?php echo set_select('board_place', 'board_top'); ?> >게시판 상단</option> 
				<option value="board_left" <?php echo set_select('board_place', 'board_left'); ?> >게시판 왼쪽</option> 
				<option value="board_right" <?php echo set_select('board_place', 'board_right'); ?> >게시판 오른쪽</option> 
				<option value="board_foot" <?php echo set_select('board_place', 'board_foot'); ?> >게시판 아래쪽</option> 
				<option value="board_middle" <?php echo set_select('board_place', 'board_middle'); ?> >게시판 중간</option>
				<option value="board_admin" <?php echo set_select('board_place', 'board_admin'); ?> >관리자페이지</option>
			</select> 
		<td><?php echo form_error('board_place'); ?>
			<script type="text/javascript">document.fboardform.board_place.value="<?php echo $board_place?>";</script>
	<tr>
		<td>페이지당 게시물숫자
		<td><?php echo get_member_level_select('view_article', 1, 50, $view_article) ?>개
		<td>
	<tr>
		<td>New아이콘 출력 설정
		<td><?php echo get_member_level_select('newicon_time_limit', 0, 240, $newicon_time_limit) ?>시간<li>(0:출력안함)
		<td>
	<tr>
		<td>게시글 카운터 증가 간격
		<td><?php echo get_member_level_select('count_time_limit', 0, 240, $count_time_limit) ?>시간<li>(0:제한없음)
		<td>
	<tr>
		<td>이미지 한줄 갯수
		<td><?php echo get_member_level_select('photo_cols', 1, 20, $photo_cols) ?>개
		<li>(gallery 스킨형만 적용됨)
		<td>
	<tr>
		<td>리스트 이미지 높이
		<td><?php echo get_member_level_select('photo_height', 10, 200, $photo_height) ?>픽셀 <li>(gallery 스킨형만 적용됨)
		<td>
	<tr>
		<td>글읽기 권한</td>
		<td><?php echo get_member_level_select('read_level', 1, 10, $read_level) ?>레벨</td>
		<td>
	</tr>
	<tr>
		<td>글쓰기 권한</td>
		<td><?php echo get_member_level_select('write_level', 2, 10, $write_level) ?>레벨 (글수정, 삭제 동일 설정됨)</td>
		<td>
	</tr>
	<tr>
		<td>글답변 권한</td>
		<td><?php echo get_member_level_select('reply_level', 2, 10, $reply_level) ?>레벨</td>
		<td>
	</tr>
	<tr>
		<td>코멘트 권한</td>
		<td><?php echo get_member_level_select('comment_level', 2, 10, $comment_level) ?>레벨
		<td>
	</tr>
	<tr>
		<td>답글</td>
		<td><?php echo get_member_level_select('board_admin_replys', 1, 20, $board_admin_replys) ?>개 이상 게시물 삭제금지</td>
		<td>
	</tr>
	<tr>
		<td>댓글</td>
		<td><?php echo get_member_level_select('board_admin_comments', 0, 20, $board_admin_comments) ?>개 이상 게시물 삭제금지</td>
		<td>
	</tr>
	<tr>
		<td>신고</td>
		<td><?php echo get_member_level_select('board_bad_count', 0, 30, $board_bad_count) ?>개 이상 블럭처리</td>
		<td>
	</tr>
	<tr>
		<td>추천</td>
		<td><?php echo get_member_level_select('board_good_count', 1, 30, $board_good_count)?>개 이상 게시물 추천처리</td>
		<td>
	<tr>
		<td>게시판 관리자 메일
		<td><input type=text name=board_admin_mail size=40 maxlength=50 value="<?php echo set_value('board_admin_mail',$board_admin_mail); ?>">
		<td><?php echo form_error('board_admin_mail'); ?>
	<tr>
	<td>게시글 관리자메일 수신
	<td>		
		<select name="board_mail_receive"> 
			<option value="1" <?php echo set_select('board_mail_receive', '1'); ?> >수신</option> 
			<option value="0" <?php echo set_select('board_mail_receive', '0', TRUE); ?> >미수신</option> 
		<td><?php echo form_error('board_mail_receive'); ?>
			<script type="text/javascript">document.fboardform.board_mail_receive.value="<?php echo $board_mail_receive?>";</script>
	<tr>
		<td>답글 관리자메일 수신
		<td>		
			<select name="board_mail_send"> 
			<option value="1" <?php echo set_select('board_mail_send', '1'); ?> >수신</option> 
			<option value="0" <?php echo set_select('board_mail_send', '0', TRUE); ?> >미수신</option> 
		<td><?php echo form_error('board_mail_send'); ?>
			<script type="text/javascript">document.fboardform.board_mail_send.value="<?php echo $board_mail_send?>";</script>
	<tr>
		<td>게시판 관리자 모바일
		<td><input type=text name=board_admin_mobile size=40 maxlength=50 value="<?php echo set_value('board_admin_mobile',$board_admin_mobile); ?>">
		<td><?php echo form_error('board_admin_mobile'); ?>
	<tr>
		<td>게시글 관리자문자수신
		<td>		
			<select name="board_mobile_receive"> 
				<option value="1" <?php echo set_select('board_mobile_receive', '1'); ?> >수신</option> 
				<option value="0" <?php echo set_select('board_mobile_receive', '0', TRUE); ?> >미수신</option> 
		<td><?php echo form_error('board_mobile_receive'); ?>
			<script type="text/javascript">document.fboardform.board_mobile_receive.value="<?php echo $board_mobile_receive?>";</script>
	<tr>
		<td>답글 관리자 문자수신
		<td>		
			<select name="board_mobile_send"> 
				<option value="1" <?php echo set_select('board_mobile_send', '1'); ?> >수신</option> 
				<option value="0" <?php echo set_select('board_mobile_send', '0', TRUE); ?> >미수신</option> 
		<td><?php echo form_error('board_mobile_send'); ?>
			<script type="text/javascript">document.fboardform.board_mobile_send.value="<?php echo $board_mobile_send?>";</script>
	<tr>
		<td>분류 사용여부
		<td>
			<select name="use_board_category"> 
				<option value="1" <?php echo set_select('use_board_category', '1'); ?> >사용</option> 
				<option value="0" <?php echo set_select('use_board_category', '0', TRUE); ?> >미사용</option> 
		<td><?php echo form_error('use_board_catego'); ?>
			<script type="text/javascript">document.fboardform.use_board_category.value="<?php echo $use_board_category?>";</script>
	<tr>
		<td width=150>분류(정치|경제|문화)
		<td width=270><input type=text name=board_category size="50" maxlength="100" value="<?php echo $board_category?>">
		<td><?php echo form_error('board_category'); ?>
	<tr>
		<td width=150>사용제한 단어(상동)
		<td width=270><input type=text name=board_limit_word size="50" maxlength="100" value="<?php echo $board_limit_word?>">
		<td><?php echo form_error('board_limit_word'); ?>
	<tr>
		<td colspan=3>
		<li>게시판 상단 html
			<!-- 스마트 에디터 시작 -->
			<textarea name="head" id="ir1"style="width:100%; height:150px; display:none;"><?php echo $head?></textarea>
	<tr>
		<td colspan=3>
		<li>게시판 하단 html
			<!-- 복수의 스마트 에디터 시작 -->
			<textarea name="foot" id="ir2"style="width:100%; height:150px; display:none;"><?php echo $foot?></textarea>
	<tr>
		<td colspan=3>		
</table>
	<div align=center>
		<input class="btn btn-small btn-info" type="button" onclick="submitContents(this);" value="게시판수정" />
		<input class="btn btn-small" type="button" onclick="history.back(1)" value="이전" />
	</div>
</form>
<script type="text/javascript">
var oEditors = [];
nhn.husky.EZCreator.createInIFrame({
	oAppRef: oEditors,
	elPlaceHolder: "ir1",
	sSkinURI: "<?php echo base_url()?>editor/smart_editor/SmartEditor2Skin.html",	
	htParams : {bUseToolbar : true,
		fOnBeforeUnload : function(){
			//alert("아싸!");	
		}
	}, //boolean
	fOnAppLoad : function(){
		//예제 코드
		//oEditors.getById["ir1"].exec("PASTE_HTML", ["로딩이 완료된 후에 본문에 삽입되는 text입니다."]);
	},
	fCreator: "createSEditor2"
});

var oEditors2 = [];
nhn.husky.EZCreator.createInIFrame({
	oAppRef: oEditors2,
	elPlaceHolder: "ir2",
	sSkinURI: "<?php echo base_url()?>editor/smart_editor/SmartEditor2Skin.html",	
	htParams : {bUseToolbar : true,
		fOnBeforeUnload : function(){
			//alert("아싸!");	
		}
	}, //boolean
	fOnAppLoad : function(){
		//예제 코드
		//oEditors.getById["ir2"].exec("PASTE_HTML", ["로딩이 완료된 후에 본문에 삽입되는 text입니다."]);
	},
	fCreator: "createSEditor2"
});
	
function submitContents(elClickedObj) {
	oEditors.getById["ir1"].exec("UPDATE_CONTENTS_FIELD", []);
 oEditors2.getById["ir2"].exec("UPDATE_CONTENTS_FIELD", []);
		// 에디터의 내용이 textarea에 적용됩니다.
	
	// 에디터의 내용에 대한 값 검증은 이곳에서 document.getElementById("ir1").value를 이용해서 처리하면 됩니다
	
	try {
		elClickedObj.form.submit();
	} catch(e) {}
}
</script>
<!-- 복수의 스마트 에디터 끝 -->