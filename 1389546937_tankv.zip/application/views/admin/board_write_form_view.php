<!-- 스마트 에디터 시작 -->
<script type="text/javascript" src="<?php echo base_url()?>editor/smart_editor/js/HuskyEZCreator.js" charset="utf-8"></script>
<!-- 스마트 에디터 끝 -->
<h1>게시판 생성</h1>
<table class="table table-hover" border=0 width=100%>
	<?php $attributes = array('name' => 'fboardform', 'id' => '');?>
	<?php echo form_open_multipart("admin/board/write_form/id/$this->id/",$attributes);?>
	<tr>
		<td>게시판 id (한글X)<li>(중복주의)
		<td><input type=text name=id size=40 maxlength=50 value="<?php echo set_value('id'); ?>">
		<td><?php echo form_error('id'); ?>
	<tr>
		<td>게시판 타이틀
		<td><input type=text name="board_title" size="40" maxlength="50" value="<?php echo set_value('board_title'); ?>">
		<td><?php echo form_error('board_title'); ?>
	<tr>
		<td>게시판 폭
		<td><input type=text name=width size=10 maxlength=10 value="100%">
		<li>(예)90%, 1000
		<td><?php echo form_error('width'); ?>
	<tr>
	<!-- 스킨폴더 자동인식 선택-->
	<tr>
		<td>스킨 선택</td>
		<td><select name=board_skin required itemname="스킨 디렉토리">
<?php		//기존 함수를 helper함수로 교체함
			$arr = directory_map("./skin/board/",1);
			//$arr = get_skin_dir("skin");
			for ($i=0; $i<count($arr); $i++) 
			{
				echo "<option value='$arr[$i]'>$arr[$i]</option>\n";
			}
?>		</select>
		<td>
			<script type="text/javascript">document.fboardform.board_skin.value="<?php echo $board_skin?>"</script></script>
	<tr>
		<td>메뉴출력여부
		<td>
			<select name="board_use"> 
				<option value="1" <?php echo set_select('board_use', '1', TRUE); ?> >사용</option> 
				<option value="0" <?php echo set_select('board_use', '0'); ?> >미사용</option> 
		<td><?php echo form_error('board_use'); ?>
	<tr>
		<td>메뉴출력순서
		<td><?php echo get_member_level_select('board_sequence', 1, 10, 1) ?>
		<li>숫자가 높을수록 상단에 노출
		<td>
	<tr>
		<td>메뉴출력위치
		<td>
			<select name="board_place" > 
				<option value="main_top" <?php echo set_select('board_place', 'main_top', TRUE); ?> >메인페이지 상단</option> 
				<option value="main_left" <?php echo set_select('board_place', 'main_left'); ?> >메인페이지 왼쪽</option> 
				<option value="main_right" <?php echo set_select('board_place', 'main_right'); ?> >메인페이지 오른쪽</option> 
				<option value="main_foot" <?php echo set_select('board_place', 'main_foot'); ?> >메인페이지 아래쪽</option> 
				<option value="main_middle" <?php echo set_select('board_place', 'main_middle'); ?> >메인페이지 중간</option> 
				<option value="board_top" <?php echo set_select('board_place', 'board_top'); ?> >게시판 상단</option> 
				<option value="board_left" <?php echo set_select('board_place', 'board_left'); ?> >게시판 왼쪽</option> 
				<option value="board_right" <?php echo set_select('board_place', 'board_right'); ?> >게시판 오른쪽</option> 
				<option value="board_foot" <?php echo set_select('board_place', 'board_foot'); ?> >게시판 아래쪽</option> 
				<option value="board_middle" <?php echo set_select('board_place', 'board_middle'); ?> >게시판 중간</option>
				<option value="board_middle" <?php echo set_select('board_place', 'board_admin'); ?> >관리자페이지</option>
			</select> 
		<td><?php echo form_error('board_place'); ?>
	<tr>
		<td>페이지당 게시물숫자
		<td><?php echo get_member_level_select('view_article', 1, 50, 20) ?>개
		<td>
	<tr>
		<td>New아이콘 출력 설정
		<td><?php echo get_member_level_select('newicon_time_limit', 0, 240, 24) ?>시간
		<li>(0:출력안함) 
		<td>
	<tr>
		<td>게시글 카운터 증가 간격
		<td><?php echo get_member_level_select('count_time_limit', 0, 240, 24) ?>시간
		<li>(0:제한없음) 
		<td>
	<tr>
		<td>이미지 한줄 갯수
		<td><?php echo get_member_level_select('photo_cols', 1, 20, 7) ?>개 
		<li>(gallery 스킨형만 적용됨)
		<td>
	<tr>
		<td>리스트 이미지 높이
		<td><?php echo get_member_level_select('photo_height', 10, 200, 100) ?>픽셀 (gallery 스킨형만 적용됨)
		<td>
	<tr>
		<td>글읽기 권한</td>
		<td><?php echo get_member_level_select('read_level', 1, 10, 1) ?>레벨</td>
		<td>
	<tr>
		<td>글쓰기 권한</td>
		<td><?php echo get_member_level_select('write_level', 2, 10, 2) ?>레벨 (글수정, 삭제 동일설정됨)</td>
		<td>
	<tr>
		<td>글답변 권한</td>
		<td><?php echo get_member_level_select('reply_level', 2, 10, 2) ?>레벨</td>
		<td>
	<tr>
		<td>코멘트 권한</td>
		<td><?php echo get_member_level_select('comment_level', 2, 10, 2) ?>레벨</td>
		<td>
	<tr>
		<td>답글</td>
		<td><?php echo get_member_level_select('board_admin_replys', 1, 20, 10) ?>개 이상 게시물 삭제금지</td>
		<td>
	</tr>
	<tr>
		<td>댓글</td>
		<td><?php echo get_member_level_select('board_admin_comments', 1, 20, 10)?>개 이상 게시물 삭제금지</td>
		<td>
	<tr>
		<td>신고</td>
		<td><?php echo get_member_level_select('board_bad_count', 1, 30, 10) ?>개 이상 블럭처리</td>
		<td>
	</tr>
	<tr>
		<td>추천</td>
		<td><?php echo get_member_level_select('board_good_count', 1, 30, 10)?>개 이상 게시물 추천처리</td>
		<td>
	</tr>
	<tr>
		<td width=150>게시판 관리자 메일
		<td width=270><input type=text name=board_admin_mail size=40 maxlength=50 value="<?php echo $site_mail?>">
		<td><?php echo form_error('board_admin_mail'); ?>
	<tr>
		<td>게시글 관리자메일 수신
		<td>
			<select name="board_mail_receive"> 
			<option value="1" <?php echo set_select('board_mail_receive', '1'); ?> >수신</option> 
			<option value="0" <?php echo set_select('board_mail_receive', '0', TRUE); ?> >미수신</option> 
		<td><?php echo form_error('board_mail_receive'); ?>
 <tr>
		<td>답글 관리자메일 수신
		<td>
			<select name="board_mail_send"> 
				<option value="1" <?php echo set_select('board_mail_send', '1'); ?> >수신</option> 
				<option value="0" <?php echo set_select('board_mail_send', '0', TRUE); ?> >미수신</option> 
		<td><?php echo form_error('board_mail_send'); ?>
	<tr>
		<td width=150>게시판 관리자 모바일
		<td width=270><input type=text name=board_admin_mobile size=40 maxlength=50 value="<?php echo $site_mobile?>">
		<td><?php echo form_error('board_admin_mobile'); ?>
	<tr>
		<td>게시글 관리자 문자수신
		<td>
			<select name="board_mobile_receive"> 
				<option value="1" <?php echo set_select('board_mobile_receive', '1'); ?> >수신</option> 
				<option value="0" <?php echo set_select('board_mobile_receive', '0', TRUE); ?> >미수신</option> 
		<td><?php echo form_error('board_mobile_receive'); ?>
	<tr>
		<td>답글 관리자 문자수신
		<td>
			<select name="board_mobile_send"> 
				<option value="1" <?php echo set_select('board_mobile_send', '1'); ?> >수신</option> 
				<option value="0" <?php echo set_select('board_mobile_send', '0', TRUE); ?> >미수신</option> 
		<td><?php echo form_error('board_mobile_send'); ?>
	<tr>
		<td>분류 사용여부
		<td>
			<select name="use_board_category"> 
				<option value="1" <?php echo set_select('use_board_category', '1'); ?> >사용</option> 
				<option value="0" <?php echo set_select('use_board_category', '0', TRUE); ?> >미사용</option> 
		<td><?php echo form_error('use_board_category'); ?>
	<tr>
		<td width=150>분류(정치|경제|문화)
		<td width=270><input type=text name=board_category size="50" maxlength="100">
		<td><?php echo form_error('board_category'); ?>
	<tr>
		<td width=150>사용제한 단어(상동)
		<td width=270><input type=text name=board_limit_word size="50" maxlength="100">
		<td><?php echo form_error('board_limit_word'); ?>
	<tr>
		<td colspan=3>
		<li>게시판 상단 html
			<!-- 복수 스마트 에디터 시작 -->
			<textarea name="head" id="ir1"  style="width:100%; height:150px; display:none;"></textarea>
	<tr>
		<td colspan=3>
		<li>게시판 하단 html
			<textarea name="foot" id="ir2"  style="width:100%; height:150px; display:none;"></textarea>
	<tr>
		<td colspan=3> 
			<div align=center>
					<input class="btn btn-small btn-info" type="button" onclick="submitContents(this);" value="게시판생성" />
					<input class="btn btn-small" type="button" onclick="history.back(1)" value="이전" />
			</div>
</table>
</form>
<script type="text/javascript">
var oEditors = [];
nhn.husky.EZCreator.createInIFrame({
	oAppRef: oEditors,
	elPlaceHolder: "ir1",
	sSkinURI: "<?php echo base_url()?>editor/smart_editor/SmartEditor2Skin.html",	
	htParams : {bUseToolbar : true,
		fOnBeforeUnload : function(){
			//alert("아싸!");	
		}
	}, //boolean
	fOnAppLoad : function(){
		//예제 코드
		//oEditors.getById["ir1"].exec("PASTE_HTML", ["로딩이 완료된 후에 본문에 삽입되는 text입니다."]);
	},
	fCreator: "createSEditor2"
});

var oEditors2 = [];
nhn.husky.EZCreator.createInIFrame({
	oAppRef: oEditors2,
	elPlaceHolder: "ir2",
	sSkinURI: "<?php echo base_url()?>editor/smart_editor/SmartEditor2Skin.html",	
	htParams : {bUseToolbar : true,
		fOnBeforeUnload : function(){
			//alert("아싸!");	
		}
	}, //boolean
	fOnAppLoad : function(){
		//예제 코드
		//oEditors.getById["ir2"].exec("PASTE_HTML", ["로딩이 완료된 후에 본문에 삽입되는 text입니다."]);
	},
	fCreator: "createSEditor2"
});
	
function submitContents(elClickedObj) {
	oEditors.getById["ir1"].exec("UPDATE_CONTENTS_FIELD", []);
    oEditors2.getById["ir2"].exec("UPDATE_CONTENTS_FIELD", []);
		// 에디터의 내용이 textarea에 적용됩니다.
	
	// 에디터의 내용에 대한 값 검증은 이곳에서 document.getElementById("ir1").value를 이용해서 처리하면 됩니다
	
	try {
		elClickedObj.form.submit();
	} catch(e) {}
}
</script>
<!-- 복수의 스마트 에디터 끝 -->