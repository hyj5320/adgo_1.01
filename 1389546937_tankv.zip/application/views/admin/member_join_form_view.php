<h1>회원가입 폼설정</h1>	최종 수정일시<?php echo $retouch_date?>
<?php
$attributes = array('name' =>'fboardform', 'id' => '');
echo form_open("admin/member_join_form/index/", $attributes); ?>
<br><br>
	<table class="table table-bordered">
			<td>아이디</td>
			<td>
				<select name="" > 
				<option value="2" <?php echo set_select('', '2', TRUE); ?> >필수입력</option> 
		<tr>
			<td>닉네임</td>
			<td>
				<select name="" > 
				<option value="2" <?php echo set_select('', '2', TRUE); ?> >필수입력</option> 
		<tr>
			<td>이메일</td>
			<td>	    
				<select name="" > 
				<option value="2" <?php echo set_select('', '2', TRUE); ?> >필수입력</option> </td>
		<tr>
			<td>비밀번호</td>
			<td>	    
				<select name="" > 
				<option value="2" <?php echo set_select('', '2', TRUE); ?> >필수입력</option> </td>
		<tr>
			<td>이름</td>
			<td>	    
				<select name="kname" > 
				<option value="0" <?php echo set_select('kname', '0', TRUE); ?> >사용안함</option> 
				<option value="1" <?php echo set_select('kname', '1'); ?> >사용</option> 
				<option value="2" <?php echo set_select('kname', '2'); ?> >필수입력</option> </td>
				<script type="text/javascript">document.fboardform.kname.value="<?php echo $form['kname']?>";</script>
		<tr>
			<td>핸드폰</td>
			<td>	    
				<select name="mobile"> 
				<option value="0" <?php echo set_select('mobile ', '0', TRUE); ?> >사용안함</option> 
				<option value="1" <?php echo set_select('mobile ', '1'); ?> >사용</option> 
				<option value="2" <?php echo set_select('mobile ', '2'); ?> >필수입력</option> </td>
				<script type="text/javascript">document.fboardform.mobile .value="<?php echo $form['mobile']?>";</script>
		<tr>
			<td>집전화</td>
			<td>
				<select name="telephone"> 
				<option value="0" <?php echo set_select('telephone ', '0', TRUE); ?> >사용안함</option> 
				<option value="1" <?php echo set_select('telephone ', '1'); ?> >사용</option> 
				<option value="2" <?php echo set_select('telephone ', '2'); ?> >필수입력</option> </td>
				<script type="text/javascript">document.fboardform.telephone .value="<?php echo $form['telephone']?>";</script>
	<tr>
			<td>집주소</td>
			<td>
				<select name="zip_address"> 
				<option value="0" <?php echo set_select('zip_address', '0', TRUE); ?> >사용안함</option> 
				<option value="1" <?php echo set_select('zip_address', '1'); ?> >사용</option> 
				<option value="2" <?php echo set_select('zip_address', '2'); ?> >필수입력</option> </td>
				<script type="text/javascript">document.fboardform.zip_address.value="<?php echo $form['zip_address']?>";</script>
		<tr>
			<td>홈페이지</td>
			<td>
				<select name="homepage"> 
				<option value="0" <?php echo set_select('homepage', '0', TRUE); ?> >사용안함</option> 
				<option value="1" <?php echo set_select('homepage', '1'); ?> >사용</option> 
				<option value="2" <?php echo set_select('homepage', '2'); ?> >필수입력</option> </td>
				<script type="text/javascript">document.fboardform.homepage.value="<?php echo $form['homepage']?>";</script>
		<tr>
			<td>생일</td>
			<td>
				<select name="birthday"> 
				<option value="0" <?php echo set_select('birthday', '0', TRUE); ?> >사용안함</option> 
				<option value="1" <?php echo set_select('birthday', '1'); ?> >사용</option> 
				<option value="2" <?php echo set_select('birthday', '2'); ?> >필수입력</option> </td>
				<script type="text/javascript">document.fboardform.birthday.value="<?php echo $form['birthday']?>";</script>
			<tr>
			<td>성별</td>
			<td>	    
				<select name="sex"> 
				<option value="0" <?php echo set_select('sex', '0', TRUE); ?> >사용안함</option> 
				<option value="1" <?php echo set_select('sex', '1'); ?> >사용</option> 
				<option value="2" <?php echo set_select('sex', '2'); ?> >필수입력</option> </td>
				<script type="text/javascript">document.fboardform.sex.value="<?php echo $form['sex']?>";</script>
		<tr>
			<td>직업</td>
			<td>
				<select name="job"> 
				<option value="0" <?php echo set_select('job', '0', TRUE); ?> >사용안함</option> 
				<option value="1" <?php echo set_select('job', '1'); ?> >사용</option> 
				<option value="2" <?php echo set_select('job', '2'); ?> >필수입력</option> </td>
				<script type="text/javascript">document.fboardform.job.value="<?php echo $form['job']?>";</script>
	</table>
		<div align=center>
			<input class="btn btn-small btn-info" type=submit value=' 회원관리 설정 수정 '>
			<input class="btn btn-small" type=button value=' 이전 ' onclick="history.back(1)">
		</div>

<?php echo form_close(); ?>


