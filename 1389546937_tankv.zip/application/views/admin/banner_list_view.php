<SCRIPT LANGUAGE=JAVASCRIPT>  
	function search_confirm()
	{
		if(document.search_form.keyword.value == '')
		{
			alert('검색어를 입력하세요.');
			document.search_form.keyword.focus();
			return;
		}
		document.search_form.submit();
	}
</SCRIPT>
<h1>베너/이미지 리스트</h1>
<table align="center" cellpadding="0" cellspacing="0" width="100%">
	<form name="search_form" method="post" action="<?php echo $act_url?>">
	<tr>
		<td width="55%">
			<select class="span4" name="key">
				<option value="banner_title" <?php if($key == "banner_title") 
				echo "selected"; ?>>이미지 타이틀</option>
				<option value="banner_place" <?php if($key == "banner_place") 
				echo "selected"; ?>>이미지 위치</option>
				<option value="banner_use" <?php if($key == "banner_use") 
				echo "selected"; ?>>이미지 출력여부</option>
			  </select>
			  <input class="input-small" type="text" placeholder=".input-small" name="keyword" size="9" value="<?php echo $keyword?>">
			  <INPUT class="btn btn-small" type="button" value="검색" name="formbutton1" onclick="search_confirm();">
		</td>
		<td width="45%">
			<p align="right"> 등록이미지 : <?php echo $total_record?>개 ( <?php echo $page?> 페이지 / 총 <?php echo $total_page?> 페이지 )</p>
		</td>
	</tr>
	</form>
</table>
<table class="table table-hover" border=0>
	<tr bgcolor="#F6F6F6">
		<td align=center>번호</font>
		<td align=center>타이틀</font>
		<td align=center>이미지</font>
		<td align=center>출력여부</font>
		<td align=center>카운터</font>
		<td align=center>수정</font>
		<td align=center>삭제</font>
	<tr>
<?php foreach($result as $row){ ?>
	<tr>
		<td align=center><?php echo $row->banner_num?>
		<td><?php echo $row->banner_title?></a>

	<td align=center>

	<?php if($row->banner_image){?>
	  <img src = "<?php echo base_url()?>file/<?php echo $this->id?>/<?php echo $row->banner_image?>"  border="0" width="150">
	 <?php }else{?>
      베너이미지가 없습니다
	  <?php }?>

	 <!-- 이미지 출력여부를 숫자를 문자로 바꾸어서 출력함 -->
<?php
if($row->banner_use==1)
{
	$row->banner_use="출력";
}
else
{
	$row->banner_use="미출력";	
}
?>
		<td align=center><?php echo $row->banner_use?>
		<td align=center><?php echo $row->banner_count  ?>
		<td align=center><a href=<?php echo base_url()?>admin/banner/edit_form/id/<?php echo $this->id?>/page/<?php echo $this->page?>/no/<?php echo $row->banner_num?>>수정</a>
		<td align=center><a href=<?php echo base_url()?>admin/banner/delete/id/<?php echo $this->id?>/page/<?php echo $this->page?>/no/<?php echo $row->banner_num?> onclick="return confirm('삭제하시겠습니까?')">삭제</a>
	<tr>
<?php } ?>
</table>
<table border=0 width=100%>
	<tr>
		<td id=pagination align=center>
<?php echo $pagenum?>
	<tr>
</table>
	<div align="center">
		<input class="btn btn-small btn-info" type="button" value="베너 등록" onclick="location.href='<?php echo base_url()?>admin/banner/write_form/id/<?php echo $this->id?>/no/<?php echo $this->no?>'";>
		<input class="btn btn-small" type="button" onclick="history.back(1)" value="이전" />
	</div>
