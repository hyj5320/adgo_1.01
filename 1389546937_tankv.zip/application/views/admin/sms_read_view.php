<?php
	/* 작성자:통큰아이 모바일팀(sms@goodinternet.co.kr)
	* 작성일자:2012년 11월 20일
	* 작성목적: 본 프로그램은 통큰아이 문자메세지에서 php 웹프로그램 관련 예제입니다.
	*             본 예제에서는 보내는 사람의 핸드폰번호, 받는사람 핸드폰번호,전송내용을 sms_process.php으로
	*             값을 전송하는 모듈입니다.
	*/
?>
<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>
<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>layouts/sub/<?php echo $site_sub_layout?>/css/main.css" media="screen"/>
<script language="javascript">
<!--
function frm_submit() {
	document.frm_sms_process.submit();
}
-->
</script>
<html>
	<div id="pageBox">
    <div class="section">
    <H1>관리자 SMS 발송내용</H1>
<form name="frm_sms_process" method="post" action="<?php echo base_url()?>admin/smss/sms_process/id/<?php echo $this->id?>/">
<table class="table table-bordered" border="1">
	<tr>
		<td align=right width=100>메일 종류 &nbsp;
		<td>
			<select name="users_sms"> 
				<option value="1" <?php echo set_select('users_sms', '1'); ?> >정상회원 전체SMS</option> 
				<option value="0" <?php echo set_select('users_sms', '0',TRUE); ?> >관리자 일반 SMS</option>
<script type="text/javascript">document.frm_sms_process.users_sms.value="<?php echo $users_sms?>";</script>
	<tr>
	<!-- 기본 발신자 번호는 관리자/사이트 관리에서 설정합니다. -->
		<td align="center">발신자번호</td>
		<td align="left">
			&nbsp;&nbsp;
			<input type="text" name="snd_number" size="12" maxlength="12" value="<?php echo $site_mobile?>">
			&nbsp;<font color="red">*</font> 번호를 공백없이 입력
		</td>
	</tr>
	<tr>
		<td align="center">수신자번호</td>
		<td align="left">
			&nbsp;&nbsp;
			<input type="text" name="rcv_number" size="13" value="<?php echo $rcv_number?>">
			&nbsp;<font color="red">*</font> 번호를 공백없이 입력
		</td>
	</tr>
	<tr>
		<td align="center">내용</td>
		<td align="left">
			&nbsp;&nbsp;
			<input type="text" name="sms_content" size="20" value="<?php echo $sms_content?>">
		</td>
	</tr>
	<tr>
		<td align="center">예약1</td>
		<td align="left">
			&nbsp;&nbsp;
			<input type="text" name="reserve_date" size="8" maxlength="8" value="<?php echo $reserve_date?>">
			<br>&nbsp;&nbsp;<font color="red">*</font> 날짜를 공백없이 yyyymmdd형식에 맞게 입력
		</td>
	</tr>
	<tr>
		<td align="center">예약2</td>
		<td align="left">
			&nbsp;&nbsp;
			<input type="text" name="reserve_time" size="6" maxlength="6" value="<?php echo $reserve_time?>">
			<br>&nbsp;&nbsp;<font color="red">*</font> 시간을 공백없이 hhmmss형식에 맞게 입력
		</td>
	</tr>
</table>
</form>
* 동보 전송을 위해서는 수신자번호를 , 로 구분하여 입력하세요.<br>
예)0101234567,0111234567,0121234567,0161234567,0171234567,0191234567<br><br>
	<div align="center">
		<input class="btn btn-small btn-info" type="button" name="frm_submit" value="전송하기" onClick="javascript:frm_submit();">
		<input class="btn btn-small" type=button value=' 이전 ' onclick="history.back(1)">
	</div>
</html>