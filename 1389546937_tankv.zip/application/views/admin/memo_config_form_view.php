<?php
$attributes = array('name' => 'fboardform', 'id' => '');
echo form_open_multipart("admin/admin_memo_config/index/",$attributes);
?>
<h1>쪽지 설정</h1>최종수정일시:<?php echo $memo['date']?> | 아이피:<?php echo $memo['ip']?>
<table class="table table-hover" border=0>
	<tr>
		<td>쪽지기능
		<td>			
			<?php echo get_date_select('level', 2, 10, $memo['level']) ?>레벨 이상 사용가능</td>
		<td>
			<script type="text/javascript">document.fboardform.level.value="<?php echo $memo['level']?>";</script>
	<tr>
		<td>카테고리 사용여부
		<td>			
			<select name="category_use" > 
				<option value="Y" <?php echo set_select('category_use', 'Y', TRUE); ?> >사용</option> 
				<option value="N" <?php echo set_select('category_use', 'N'); ?> >사용안함</option> 
			</select> 
		<td>
			<script type="text/javascript">document.fboardform.category_use.value="<?php echo $memo['category_use']?>";</script>
	<tr>
		<td>카테고리(예: 정치|경제|문화)
		<td><input type="text" name="category" size="40" maxlength="100" value="<?php echo set_value('category',$memo['category']); ?>">
		<td><?php echo form_error('category'); ?>
	<tr>
		<td>금지어(예: 상동)
		<td><input type="text" name="limit_word" size="40" maxlength="100" value="<?php echo set_value('limit_word',$memo['limit_word']); ?>">
		<td><?php echo form_error('limit_word'); ?>
	<tr>
		<td>출력쪽지수
		<td>			
			<?php echo get_date_select('view_article', 2, 50, $memo['view_article']) ?>개</td>
		<td>
			<script type="text/javascript">document.fboardform.view_article.value="<?php echo $memo['view_article']?>";</script>
	<tr>
		<td>폭
		<td><input type="text" name="width" size="10" maxlength="10" value="<?php echo set_value('width',$memo['width']); ?>"> (예: 100% , 1000)
		<td><?php echo form_error('width'); ?>
	<tr>
		<td width=150>신고 블럭수
		<td>			
			<?php echo get_date_select('bad_count', 1, 20, $memo['bad_count']) ?>개이상 쪽지사용 차단</td>
		<td>
			<script type="text/javascript">document.fboardform.bad_count.value="<?php echo $memo['bad_count']?>";</script>
	<tr>
</table>
		<div align="center">
			<input class="btn btn-small btn-info" type=submit value=' 쪽지 설정 '>
			<input class="btn btn-small" type=button value=' 이전 ' onclick="history.back(1)">
		</div>
</form>