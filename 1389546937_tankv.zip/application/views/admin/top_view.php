<!DOCTYPE html>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<html>
<head>
<!-- Bootstrap -->
<link href="<?php echo base_url()?>include/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
<!-- 반응형 네비게이션바 -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="<?php echo base_url()?>include/bootstrap/css/bootstrap-responsive.css" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>include/css/admin.css" media="screen"/>
<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />  
<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>  
<link rel="stylesheet" href="/resources/demos/style.css" />

<title>관리</title>
</head>
<body>

<!-- 상단 공통 네비게이션 시작 -->
			<div class="container">
				<div class="row-fluid">
					<div class="span12">
						<div align=right>
<?php if( $this->session->userdata('user_id') )
{
	if($this->session->userdata('file1')){?>
						<img src = "<?php echo base_url()?>file/users/<?php echo $this->session->userdata('file1')?>" width="15" height="15" border="0" >
<?php }else{?>
						<i class="icon-user"></i>
<?php }?>
<?php echo $this->session->userdata('nickname')?>님 (<?php echo $this->session->userdata('level') ?>레벨) 환영합니다. 
						<a href ="<?php echo base_url()?>auth/modify"  class="btn btn-mini"><i class="icon-pencil"></i>회원정보수정</a>&nbsp;	
						<a href = "<?php echo base_url()?>auth/logout/"  class="btn btn-mini"><i class="icon-share"></i>로그아웃</a>&nbsp;
<?php
}else{?>&nbsp;
						<a href ="<?php echo base_url()?>auth/register1"  class="btn btn-mini"><i class="icon-pencil"></i>회원가입</a>&nbsp;
						<a href ="<?php echo base_url()?>/auth/forgot_password/"  class="btn btn-mini"><i class="icon-wrench"></i>비밀번호찾기</a>&nbsp;
						<a href ="<?php echo base_url()?>auth/login"  class="btn btn-mini"><i class="icon-check"></i>로그인</a>&nbsp;<?php
}
						if($this->session->userdata('level')==10){?>
							<a href ="<?php echo base_url()?>board/index/id/manual/page/1" class="btn btn-mini"><i class="icon-book"></i>매뉴얼</a>&nbsp;
							<a href ="<?php echo base_url()?>auth/unregister"  class="btn btn-mini"><i class="icon-ban-circle"></i>회원탈퇴</a>&nbsp;
							<a class="btn btn-info btn-mini" href ="<?php echo base_url()?>admin/site_config/index/"><i class="icon-cog  icon-white"></i>관리자</a>

<?php }?>
						</div><!-- right -->
					</div><!-- span12 -->
				</div><!-- row-fluid -->
			</div><!-- container -->
<!-- 상단 공통 네비게이션 끝 -->
<div class="container">
	<div class="row-fluid">
		<div class="span3">

<ul class="dropdown-menu" role="menu" aria-labelledby="dLabel" style="display: block; position: static; ">

		<!-- 관리자/사이트관리/로고-->
		<div align= "center">
		<a href="<?php echo base_url()?>"><img src="<?php echo base_url()?>file/site_logo/<?php echo $site_logo?>">HOME</a>
		</div>


	<li class="divider"></li>

	<li><a href="<?php echo base_url()?>admin/site_config/index/"><i class="icon-cog"></i> 사이트 설정</a></li>

	<li class="dropdown-submenu">
		<a href="#">게시판 관리</a>
			<ul class="dropdown-menu">
				<li><a href="<?php echo base_url()?>admin/board/index/id/board_admin/page/1">게시판 리스트</a></li>
				<li><a href="<?php echo base_url()?>/admin/board/write_form/id/board_admin">게시판 생성</a></li>
			</ul>
	</li>

	<li class="dropdown-submenu">
		<a href="#">콘텐츠 관리</a>
			<ul class="dropdown-menu">
				<li><a href="<?php echo base_url()?>admin/contents/index/id/contents/page/1">콘텐츠 리스트</a></li>
				<li><a href="<?php echo base_url()?>admin/contents/write_form/id/contents">콘텐츠 등록</a></li>
			</ul>
	</li>

		<li class="dropdown-submenu">
		<a href="">회원관리</a>
			<ul class="dropdown-menu">
				<li><a href="<?php echo base_url()?>admin/member_config/index/">회원관리 설정</a></li>
				<li><a href="<?php echo base_url()?>admin/member_join_form/index/">회원가입폼 설정</a></li>
				<li><a  href="<?php echo base_url()?>admin/member/index/table/users/page/1">회원리스트</a></li>
			</ul>
	</li>

	<li class="dropdown-submenu">
		<a href="#">베너 관리</a>
			<ul class="dropdown-menu">
				<li><a href="<?php echo base_url()?>admin/banner/index/id/banner/page/1">베너 리스트</a></li>
				<li><a href="<?php echo base_url()?>admin/banner/write_form/id/banner">베너 등록</a></li>
			</ul>
	</li>

	<li class="dropdown-submenu">
		<a href="#">팝업 관리</a>
			<ul class="dropdown-menu">
				<li><a href="<?php echo base_url()?>admin/popup/index/id/popup/page/1">팝업 리스트</a></li>
				<li><a href="<?php echo base_url()?>admin/popup/write_form/id/popup">팝업 등록</a></li>
			</ul>
	</li>

	<li class="dropdown-submenu">
		<a href="#">쪽지 관리</a>
			<ul class="dropdown-menu">
				<li><a href="<?php echo base_url()?>admin/admin_memo_config/index/">쪽지 설정</a></li>
				<li><a href="<?php echo base_url()?>admin/admin_memo/receive_list/id/memo/page">받은쪽지</a></li>
				<li><a href="<?php echo base_url()?>admin/admin_memo/send_list/id/memo/page">보낸쪽지</a></li>
				<li><a href="<?php echo base_url()?>admin/admin_memo/send_form/id/memo/page">쪽지 전송</a></li>
			</ul>
	</li>

	<li class="dropdown-submenu">
		<a href="#">메일 관리</a>
			<ul class="dropdown-menu">
				<li><a href="<?php echo base_url()?>admin/mails/mails_list/id/mails/page/1">메일 리스트</a></li>
				<li><a href="<?php echo base_url()?>admin/mails/mails_form/id/mails">메일 전송</a></li>
			</ul>
	</li>

	<li class="dropdown-submenu">
		<a href="#">SMS 관리</a>
			<ul class="dropdown-menu">
				<li><a href="<?php echo base_url()?>admin/smss/sms_list/id/smss/page/1">SMS 리스트</a></li>
				<li><a href="<?php echo base_url()?>admin/smss/sms_main/id/smss">SMS 전송</a></li>
			</ul>
	</li>

	<li class="dropdown-submenu">
		<a href="#">DB 관리</a>
			<ul class="dropdown-menu">
				<li><a href=<?php echo base_url()?>admin/site_config/site_db_backup/ onclick="return confirm('DB용량이 클 경우 시간이 걸릴 수 있습니다. 사이트 전체 DB백업을 실행 하시겠습니까? ')">DB백업</a></li>
				<li><a href=<?php echo base_url()?>admin/site_config/optimize_database/ onclick="return confirm('데이터베이스 최적화를 실행 하시겠습니까? ')">DB최적화</a></li>
				<li><a href="http://www.tankv.com/myadmin/" target="_blank">phpmyadmin</a></li>
			</ul>
	</li>

	<li><a href="http://www.google.com/analytics/" target="_blank"><i class="icon-briefcase"></i> 웹로그분석</a></li>

<?php
		//좌측 게시판 메뉴 출력
		$this->db->order_by('board_sequence desc');//메뉴출력순서
		$this->db->where('board_place', "board_admin");//메뉴출력위치
		$this->db->where('board_use', 1);//메뉴출력여부
		$query = $this->db->get('board_admin');
		foreach ($query->result() as $row){?>
			<li><a href=<?php echo base_url()?>board/index/id/<?php echo $row->id?>/page/1 target=_blank> <?php echo $row->board_title?></a></li>
<?php }?>
</ul><!-- class="dropdown-menu" -->
</div>


		<div class="span9">