<?php if (!defined('BASEPATH')) exit('No direct script access allowed');?>

<H1>
쪽지 읽기
<?php //=if(isset($category)) echo "($category)";?>
</H1>

<ul class="nav nav-tabs nav-stacked">
	<li><a href="<?php echo base_url()?>admin/admin_memo/receive_list/id/memo/page">받은쪽지</a> 
	<li><a href="<?php echo base_url()?>admin/admin_memo/send_list/id/memo/page">보낸쪽지</a>
	<li><a href="<?php echo base_url()?>admin/admin_memo/send_form/id/memo/page">쪽지 보내기</a>
</ul>

<table border="0" align="center" width="100%">
	<tr>
		<td class="td" colspan="4" bgcolor="#F6F6F6">
			<h2>&nbsp;&nbsp;<?php echo $memo_subject?></h2>
		<td align=right bgcolor="#F6F6F6">
<?php if($memo_file1){?>
			<a href=<?php echo base_url()?>admin/admin_memo/file_down/id/<?php echo $this->id?>/file/<?php echo $memo_file1?>>
			<img src='<?php echo base_url()?>images/button_file.gif' border='0' align='absmiddle'> 
<?php echo substr($memo_file1,11,20)?></a> &nbsp;&nbsp;
<?php }?>
	<tr>
		<td colspan="5" align="center">
			<table class="td" border="0" align="center" width="100%">
				<tr>
					<td> 
						<!--  회원 케릭터이미지 출력 -->
<?php if($this->session->userdata('file1')){?>
						<img src = <?php echo base_url()?>file/users/<?php echo $this->session->userdata('file1')?> width="15" height="15" border="0" >
<?php }else{?>
						<img src = <?php echo base_url()?>images/character.gif width="15" height="15" border="0" >
<?php }?>  
						보낸아이디 :  <?php echo $memo_send_id?> (<?php echo $memo_ip?>)
					<td align=right>보낸날자 : <?php echo $memo_send_date?> | 읽은시간 : <?php echo $memo_receive_date?>
			</table>
			<table border="0" width="100%">
				<tr>
					<td>&nbsp;
				<tr>
					<td><?php echo $memo_contents?></td>
				<tr>
					<td class="td">&nbsp;
				</tr>
			</table>
	<tr>
		<td> 
			<a href=<?php echo base_url()?>admin/admin_memo/bad_count/id/<?php echo $this->id?>/page/<?php echo $this->page?>/no/<?php echo $this->no?>/ onclick="return confirm('신고 하시겠습니까?')">신고(<?php echo $memo_bad_count?>회)</a>
		<td  align=center>
<?php if($this->session->userdata('level') >= $admin['level']){?>
			<a href=<?php echo base_url()?>admin/admin_memo/send_form/id/<?php echo $this->id?>/page/<?php echo $this->page?>/no/<?php echo $this->no?>><img src='<?php echo base_url()?>images/button_write.gif' border='0' align='absmiddle'></a>   
<?php }?>
 <?php if($this->session->userdata('level') == 10 OR $memo_receive_id == $this->session->userdata('username') OR $memo_send_id == $this->session->userdata('username')){?>

<!-- 받은쪽지 보낸쪽지를 구분해서 삭제 하기 위해서... -->
<?php if($memo_send_id == $this->session->userdata('username'))
			{
				$aaa = 'send';
			}
			elseif($memo_receive_id == $this->session->userdata('username'))
			{
				$aaa = 'receive';
			}
?>
			<a href=<?php echo base_url()?>admin/admin_memo/delete/id/<?php echo $this->id?>/page/<?php echo $this->page?>/no/<?php echo $this->no?>/<?php echo $aaa?>/ onclick="return confirm('삭제하시겠습니까?')"><img src='<?php echo base_url()?>images/button_delete.gif' border='0' align='absmiddle'></a> 
<?php }?>	
			<a href=<?php echo base_url()?>admin/admin_memo/receive_list/id/<?php echo $this->id?>/page/<?php echo $this->page?>/><img src='<?php echo base_url()?>images/button_list.gif' border='0' align='absmiddle'></a>
	<tr>
		<td  align=center colspan=5>
			<br>
<?php //베너 출력
	$this->db->order_by('banner_sequence desc');//출력순서
	$this->db->where('banner_place', "board_middle");//베너위치
	$this->db->where('banner_use', 1);//사용여부
	$query = $this->db->get('banner');
	foreach ($query->result() as $row){?>
		<a href=<?php echo base_url()?>admin/banner/read/id/banner/no/<?php echo $row->banner_num?>/ target=<?php echo $row->banner_target?>>
		<img src=<?php echo base_url()?>file/banner/<?php echo $row->banner_image?> width=<?php echo $row->banner_width?> height=<?php echo $row->banner_height?>></a><br>
<?php }?>
	<br>
</table>
<!-- 아랫글 윗글 링크 (답글 무시하고 원글만 링크됨-오류라고 봐야하나????) -->
<table>
	<tr>
		<td>
<?php
	$no = $this->no;
	$this->db->where('memo_no >', $no);
	$this->db->limit(1);
	$query = $this->db->get($this->id);
	$row = $query->row_array();

	if (isset($row['memo_no'])){?>	
	<a href=<?php echo base_url()?>admin/admin_memo/read/id/<?php echo $this->id?>/page/<?php echo $this->page?>/no/<?php echo $row['memo_no']?>>▲윗&nbsp;&nbsp;&nbsp;글 | <?php echo $row['memo_subject']?></a>
<?php }
else
{
	echo"[윗글]";
}
?> 
<br>

<?php
	$no2 = $this->no;
	$this->db->where('memo_no <', $no2);
	$this->db->order_by('memo_no desc');
	$this->db->limit(1);
	$query = $this->db->get($this->id);
	$row2 = $query->row_array();

	if (isset($row2['memo_no'])){?>
	<a href=<?php echo base_url()?>admin/admin_memo/read/id/<?php echo $this->id?>/page/<?php echo $this->page?>/no/<?php echo $row2['memo_no']?>>▼아랫글 | <?php echo $row2['memo_subject']?></a>
<?php }
else
{
echo" [아랫글]";
}
?>
</table>
<br><br>