<SCRIPT LANGUAGE=JAVASCRIPT>  
	function search_confirm()
	{
		if(document.search_form.keyword.value == '')
		{
			alert('검색어를 입력하세요.');
			document.search_form.keyword.focus();
			return;
		}
		document.search_form.submit();
	}
</SCRIPT>
<h1>게시판 관리 리스트</h1>
<table align="center" cellpadding="0" cellspacing="0" width="100%">
	<form name="search_form" method="post" action="<?php echo $act_url?>">
	<tr>
		<td width="60%">

			<select class="span3" name="key">
				<option value="id" <?php if($key == "id") 
				echo "selected"; ?>>게시판 id</option>
				<option value="board_name" <?php if($key == "board_name") 
				echo "selected"; ?>>게시판 명</option>
				<option value="board_skin" <?php if($key == "board_skin") 
				echo "selected"; ?>>스킨명</option>
			</select>

			<input class="input-small" type="text" placeholder=".input-small" name="keyword" size="9" value="<?php echo $keyword?>">
			<b><INPUT class="btn btn-small" type=button value="검색" name=formbutton1 onclick="search_confirm();"></b>

		</td>
		<td width="40%">
			<p align="right"> 게시판 : <?php echo $total_record?>개 ( <?php echo $page?> 페이지 / 총 <?php echo $total_page?> 페이지 )</p>
		</td>
	</tr>
	</form>
</table>

<table class="table table-hover" border=0 width=100%>
	<tr>
	<tr bgcolor="#F6F6F6">
		<td align=center>번호</font>
		<td align=center>메뉴출력</font>
		<td align=center>ID</font>
		<td align=center>타이틀</font>
		<td align=center>수정</font>
		<td align=center>삭제</font>
		<td align=center>백업</font>
		<td align=center>보기</font>
	<tr>
<?php foreach($result as $row){ ?>
	<tr>
		<td align=center><?php echo $row->no?>
<!-- 메뉴에 출력여부를 숫자를 문자로 바꾸어서 출력함 -->
<?php
if($row->board_use==1)
{
	$row->board_use="출력";
}
else
{
	$row->board_use="미출력";	    
}
?>
		<td><?php echo $row->board_use?>
		<td><?php echo $row->id?>
		<td><?php echo $row->board_title?>
		<td align=center><a href=<?php echo base_url()?>admin/board/edit_form/id/<?php echo $this->id?>/page/<?php echo $this->page?>/no/<?php echo $row->no?>>수정</a>
		<td align=center><a href=<?php echo base_url()?>admin/board/delete/id/<?php echo $row->id?>/page/<?php echo $this->page?>/no/<?php echo $row->no?> onclick="return confirm('삭제하시겠습니까?')">삭제</a>
		<td align=center><a href=<?php echo base_url()?>admin/board/board_backup/id/<?php echo $row->id?>/no/<?php echo $row->no?> onclick="return confirm('백업하시겠습니까?')">백업</a>
		<td align=center><a href=<?php echo base_url()?>board/index/id/<?php echo $row->id?>/page/<?php echo $this->page?>/>보기</a>
	<tr>
<?php } ?>
</table>
<table border=0 width=100%>
	<tr>
		<td id=pagination align=center>
<?php echo $pagenum?>
	<tr>
		<td align=center>
			<input class="btn btn-small btn-info" type="button" value="새게시판 만들기" onclick="location.href='<?php echo base_url()?>/admin/board/write_form/id/<?php echo $this->id?>/no/<?php echo $this->no?>'";>
			<input class="btn btn-small" type="button" onclick="history.back(1)" value="이전" />
</table>