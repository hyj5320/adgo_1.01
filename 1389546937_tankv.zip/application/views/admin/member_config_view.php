<script type="text/javascript" src="<?php echo base_url()?>editor/smart_editor/js/HuskyEZCreator.js" charset="utf-8"></script>
<?php $attributes = array('name' => 'fboardform', 'id' => '');?>
<?php echo form_open_multipart("admin/member_config/index/",$attributes);?>
<h1>회원관리 설정</h1>최종 수정 일시 <?php echo $users['users_date']?>
<table class="table table-hover" border=0 width=100%>
	<tr>
		<td width=150>회원가입 작동상태
		<td>
			<select name="users_enable"> 
			<option value="1" <?php echo set_select('users_enable', '1', TRUE); ?> >작동</option> 
			<option value="0" <?php echo set_select('users_enable', '0'); ?> >미작동</option> 
		<td><?php echo form_error('users_enable'); ?>
		<script type="text/javascript">document.fboardform.users_enable.value="<?php echo $users['users_enable']?>";</script>

	<tr>
		<td width=150>회원가입 이메일인증
		<td>
			<select name="users_email_activation"> 
			<option value="1" <?php echo set_select('users_email_activation', '1', TRUE); ?> >인증실행</option> 
			<option value="0" <?php echo set_select('users_email_activation', '0', TRUE); ?> >인증 미실행</option> 
		<td><?php echo form_error('users_email_activation'); ?>
			<script type="text/javascript">document.fboardform.users_email_activation.value="<?php echo $users['$users_email_activation']?>";</script>
		<tr>
		<td width=150>회원 탈퇴 처리
		<td>
			<select name="users_out"> 
			<option value="1" <?php echo set_select('users_out', '1', TRUE); ?> >관리자 확인후 탈퇴</option> 
			<option value="2" <?php echo set_select('users_out', '0'); ?> >즉시탈퇴</option> 
		<td><?php echo form_error('users_out'); ?>
		<script type="text/javascript">document.fboardform.users_out.value="<?php echo $users['users_out']?>";</script>
	 <tr>
		<td>회원 가입 스킨
		<td><select name=users_skin required itemname="회원가입 스킨 디렉토리">
<?php
			$arr = directory_map('./skin/member/',1);
			for ($i=0; $i<count($arr); $i++) 
			{
				echo "<option value='$arr[$i]'>$arr[$i]</option>\n";
			}
?>
	</select>
			<!--fboardform과 폼name를 맞춰줘야 value작동함-->
			<script type="text/javascript">document.fboardform.users_skin.value="<?php echo $users['users_skin']?>";</script>
		<td>
	<tr>
		<td width=150>회원가입 축하 SMS
		<td>
			<select name="users_sms_entry"> 
			<option value="1" <?php echo set_select('users_sms_entry', '1'); ?> >발송</option> 
			<option value="0" <?php echo set_select('users_sms_entry', '0', TRUE); ?> >미발송</option> 
		<td><?php echo form_error('users_sms_entry'); ?>
		<script type="text/javascript">document.fboardform.users_sms_entry.value="<?php echo $users['users_sms_entry']?>";</script>
	<tr>
		<td width=150>회원관리자 회신번호
		<td><input type=text name=users_sms_admin size=20 maxlength=11 value="<?php echo set_value('users_sms_admin',$users['users_sms_admin']); ?>">
		<td><?php echo form_error('users_sms_admin'); ?>
	<tr>
		<td>축하 SMS내용
		<td colspan=2>
			<textarea name="users_sms_message" style=" width: 100%; height: 50px; overflow: visible;"><?php echo set_value('users_sms_message',$users['users_sms_message']); ?></textarea>
		<?php echo form_error('users_sms_message'); ?>
	<tr>
		<td>사용제한 아이디
		<td>
		<input type=text name="users_cut_id" size=70 maxlength=100 value="<?php echo set_value('users_cut_id',$users['users_cut_id']); ?>">
		<td><?php echo form_error('users_cut_id'); ?>
	<tr>
		<td>사용제한 닉네임
		<td><input type=text name="users_cut_nickname" size=70 maxlength=100 value="<?php echo set_value('users_cut_nickname',$users['users_cut_nickname']); ?>">
		<td><?php echo form_error('users_cut_nickname'); ?>
	<tr>
		<td align=right colspan=3>
			<li>약관1
			<textarea name="users_register1" style=" width: 95%; height: 150px; overflow: visible; "><?php echo set_value('users_register1',$users['users_register1']); ?></textarea>
			<?php echo form_error('users_register1'); ?>
	<tr>
		<td align=right colspan=3>
			<li>약관2
			<textarea name="users_register2" style=" width: 95%; height: 150px; overflow:  visible;"><?php echo set_value('users_register2',$users['users_register2']); ?></textarea>
			<?php echo form_error('users_register2'); ?>
	<tr>
 </table>
		<div align=center>
			<input class="btn btn-small btn-info" type=submit value=' 회원관리 설정 수정 '>
			<input class="btn btn-small" type=button value=' 이전 ' onclick="history.back(1)">
		</div>
</form>
<!--
	<tr>
      <td>회원가입약관1
      <td colspan=2>
	  스마트 에디터 시작 
<textarea name="users_register1" id="ir1"  style="width:100%; height:150px; display:none;"><?php echo $users_register1?></textarea>
	<tr>
      <td>회원가입약관2
      <td colspan=2>   
<textarea name="users_register2" id="ir2"  style="width:100%; height:100px; display:none;"><?php echo $users_register2?></textarea>
      <div align=center>
	  		<input type="button" onclick="submitContents(this);" value="회원가입 설정" />
		  	<input type="button" onclick="history.back(1)" value="이전" />
      </div>
<script type="text/javascript">
var oEditors = [];
nhn.husky.EZCreator.createInIFrame({
	oAppRef: oEditors,
	elPlaceHolder: "ir1",
	sSkinURI: "<?php echo base_url()?>editor/smart_editor/SmartEditor2Skin.html",	
	htParams : {bUseToolbar : true,
		fOnBeforeUnload : function(){
			//alert("아싸!");	
		}
	}, //boolean
	fOnAppLoad : function(){
		//예제 코드
		//oEditors.getById["ir1"].exec("PASTE_HTML", ["로딩이 완료된 후에 본문에 삽입되는 text입니다."]);
	},
	fCreator: "createSEditor2"
});

var oEditors2 = [];
nhn.husky.EZCreator.createInIFrame({
	oAppRef: oEditors2,
	elPlaceHolder: "ir2",
	sSkinURI: "<?php echo base_url()?>editor/smart_editor/SmartEditor2Skin.html",	
	htParams : {bUseToolbar : true,
		fOnBeforeUnload : function(){
			//alert("아싸!");	
		}
	}, //boolean
	fOnAppLoad : function(){
		//예제 코드
		//oEditors.getById["ir2"].exec("PASTE_HTML", ["로딩이 완료된 후에 본문에 삽입되는 text입니다."]);
	},
	fCreator: "createSEditor2"
});
	
function submitContents(elClickedObj) {
	oEditors.getById["ir1"].exec("UPDATE_CONTENTS_FIELD", []);
    oEditors2.getById["ir2"].exec("UPDATE_CONTENTS_FIELD", []);
		// 에디터의 내용이 textarea에 적용됩니다.
	
	// 에디터의 내용에 대한 값 검증은 이곳에서 document.getElementById("ir1").value를 이용해서 처리하면 됩니다
	
	try {
		elClickedObj.form.submit();
	} catch(e) {}
}
</script>
복수의 스마트 에디터 끝 -->
