<script type="text/javascript" src="<?php echo base_url()?>editor/smart_editor/js/HuskyEZCreator.js" charset="utf-8"></script>
<?php
$attributes = array('name' => 'fboardform', 'id' => '');
echo form_open_multipart("admin/site_config/index/",$attributes);
?>

<div class="alert alert-block">
<button type="button" class="close" data-dismiss="alert">&times;</button>
<h4>Warning!</h4>허가 없이 변경, 삭제, 열람 할 시에 민 형사 상 의 책임을 져야 할 수 도 있습니다.
</div>

<h1><?php echo $site_title?> 사이트 설정</h1><?php echo $site_date?>

<table class="table table-hover" border=0 width=100%>
	<tr>
		<td width=150>사이트 타이틀
		<td>
					<input type="text" name="site_title" size="40" maxlength="50" value="<?php echo set_value('site_title',$site_title); ?>">
			</div>
		<td>
<?php echo form_error('site_title'); ?>
	<tr>
		<td>사이트 메인 레이아웃
		<td><select name=site_main_layout required itemname="메인 레이아웃 디렉토리">
<?php
			$arr = directory_map('./layouts/main/',1);
			for ($i=0; $i<count($arr); $i++) 
			{
				echo "<option value='$arr[$i]'>$arr[$i]</option>\n";
			}
?>
			</select>
			<!--fboardform과 폼name를 맞춰줘야 value작동함-->
			<script type="text/javascript">document.fboardform.site_main_layout.value="<?php echo $site_main_layout?>";</script>
		<td><?php echo form_error('site_main_layout'); ?>
	<tr>
		<td>사이트 서브 레이아웃
		<td><select name=site_sub_layout required itemname="서브 레이아웃 디렉토리">
<?php
			$arr = directory_map('./layouts/sub/',1);
			for ($i=0; $i<count($arr); $i++) 
			{
				echo "<option value='$arr[$i]'>$arr[$i]</option>\n";
			}
?>
				</select>
			<!--fboardform과 폼name를 맞춰줘야 value작동함-->
			<script type="text/javascript">document.fboardform.site_sub_layout.value="<?php echo $site_sub_layout?>";</script>
		<td><?php echo form_error('site_sub_layout'); ?>
	<tr>
		<td>사이트 메인 스킨
		<td><select name="site_main_skin" required itemname="메인 스킨 디렉토리">
<?php
			$arr = directory_map('./skin/main/',1);
			for ($i=0; $i<count($arr); $i++) 
			{
				echo "<option value='$arr[$i]'>$arr[$i]</option>\n";
			}
?>
			</select>
			<!--fboardform과 폼name를 맞춰줘야 value작동함-->
			<script type="text/javascript">document.fboardform.site_main_skin.value="<?php echo $site_main_skin?>";</script>
		<td><?php echo form_error('site_main_skin'); ?>
	<tr>
		<td>사이트 메일
		<td><input type=text name="site_mail" size="40" maxlength="40" value="<?php echo set_value('site_mail',$site_mail); ?>">
		<td><?php echo form_error('site_mail'); ?>
	<tr>
		<td>sms 발송회사
		<td><a class="btn btn-mini" href="http://sms.tongkni.co.kr/build/sms_php.asp" target=_blank>SMS발송 가입안내</a> 
		<td>
	<tr>
		<td>sms아이디
		<td><input type=text name=site_mobile_id size=40 maxlength=40 value="<?php echo set_value('site_mobile_id',$site_mobile_id); ?>">
		<td><?php echo form_error('site_mobile_id'); ?>
	<tr>
		<td>sms패스워드
		<td><input type=text name=site_mobile_password size=40 maxlength=40 value="<?php echo set_value('site_mobile_password',$site_mobile_password); ?>">
		<td><?php echo form_error('site_mobile_password'); ?>	
	<tr>
		<td>사이트 모바일
		<td><input type=text name=site_mobile size=40 maxlength=40 value="<?php echo set_value('site_mobile',$site_mobile); ?>">
		<td><?php echo form_error('site_mobile'); ?>	
	<tr>
		<td>사이트 정렬
		<td>
			<select name="site_align" > 
				<option value="left" <?php echo set_select('site_align', '왼쪽정렬', TRUE); ?> >왼쪽정렬</option> 
				<option value="center" <?php echo set_select('site_align', '중앙정렬'); ?> >중앙정렬</option> 
				<option value="right" <?php echo set_select('site_align', '우측정렬'); ?> >우측정렬</option> 
			</select> 
		<td><?php echo form_error('site_align'); ?>
			<script type="text/javascript">document.fboardform.site_align.value="<?php echo $site_align?>";</script>
	<tr>
		<td>사이트 넓이
		<td>
			<?php echo get_member_level_select('site_width', 50, 100, $site_width) ?>%
		<td><?php echo form_error('site_width'); ?>	
	<tr>
		<td>사이트 로고
		<td>
<?php if($site_logo){ ?>  
			<img  src=<?php echo base_url()?>file/site_logo/<?php echo $site_logo?> height='55' border="0"></a><br> 
<?php }else{ ?>  
			이미지가 없습니다.<br> 
<?php } ?>
			<input type="hidden" name="MAX_FILE_SIZE" value="1000000">
			<input type=file name="assa">
		<td>
	<tr>
		<td>메타 테그 keywords
		<td colspan=2>
			<textarea name="site_keywords" style=" width: 100%; height: 50px; overflow: visible;"><?php echo set_value('site_keywords',$site_keywords); ?></textarea>
		<td><?php echo form_error('site_keywords'); ?>
	<tr>
		<td>메타 테그 descriptio
		<td colspan=2>
			<textarea name="site_description" style=" width: 100%; height: 50px; overflow: visible;"><?php echo set_value('site_description',$site_description); ?></textarea>
		<td><?php echo form_error('site_description'); ?>
	<tr>
		<td>구글 로그분석 코드
		<li><a class="btn btn-mini" href="http://www.google.com/analytics/" target=_blank>구글 analytics 가입</a> 
		<td colspan=2>
			<textarea name="analytics" style=" width: 100%; height: 50px; overflow: visible;"><?php echo set_value('analytics',$analytics); ?></textarea>
		<td><?php echo form_error('analytics'); ?>
	<tr>
		<td colspan=4>
			<!-- 스마트 에디터 시작 -->
			<li>copyright(html)
			<textarea name="site_copyright" id="ir1"  style="width:100%; height:150px; display:none;"><?php echo $site_copyright?></textarea>
</table>
		</div>
			<div align=center>
				<input class="btn btn-small" type="button" onclick="submitContents(this);" value="사이트 설정" /> 
				<input class="btn btn-small" type="button" onclick="history.back(1)" value="이전" />

<script type="text/javascript">
var oEditors = [];
nhn.husky.EZCreator.createInIFrame({
	oAppRef: oEditors,
	elPlaceHolder: "ir1",
	sSkinURI: "<?php echo base_url()?>editor/smart_editor/SmartEditor2Skin.html",	
	htParams : {bUseToolbar : true,
		fOnBeforeUnload : function(){
			//alert("아싸!");	
		}
	}, //boolean
	fOnAppLoad : function(){
		//예제 코드
		//oEditors.getById["ir1"].exec("PASTE_HTML", ["로딩이 완료된 후에 본문에 삽입되는 text입니다."]);
	},
	fCreator: "createSEditor2"
});

function pasteHTML() {
	var sHTML = "<span style='color:#FF0000;'>이미지도 같은 방식으로 삽입합니다.<\/span>";
	oEditors.getById["ir1"].exec("PASTE_HTML", [sHTML]);
}

function showHTML() {
	var sHTML = oEditors.getById["ir1"].getIR();
	alert(sHTML);
}
	
function submitContents(elClickedObj) {
	oEditors.getById["ir1"].exec("UPDATE_CONTENTS_FIELD", []);	// 에디터의 내용이 textarea에 적용됩니다.
	
	// 에디터의 내용에 대한 값 검증은 이곳에서 document.getElementById("ir1").value를 이용해서 처리하면 됩니다.
	
	try {
		elClickedObj.form.submit();
	} catch(e) {}
}

function setDefaultFont() {
	var sDefaultFont = '궁서';
	var nFontSize = 24;
	oEditors.getById["ir1"].setDefaultFont(sDefaultFont, nFontSize);
}
</script>
<!-- 스마트 에디터 끝 -->
</form>