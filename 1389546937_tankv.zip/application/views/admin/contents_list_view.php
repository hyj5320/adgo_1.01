<SCRIPT LANGUAGE=JAVASCRIPT>  
	function search_confirm()
	{
		if(document.search_form.keyword.value == '')
		{
			alert('검색어를 입력하세요.');
			document.search_form.keyword.focus();
			return;
		}
		document.search_form.submit();
	}
</SCRIPT>
<h1>콘텐츠 리스트</h1>
<table align="center" cellpadding="0" cellspacing="0" width="100%">
	<form name="search_form" method="post" action="<?php echo $act_url?>">
		<tr>
			<td width="60%">
				<select class="span3" name="key">
					<option value="con_id" <?php if($key == "con_id") echo "selected"; ?>>콘텐츠 id</option>
					<option value="con_name" <?php if($key == "con_name") echo "selected"; ?>>콘텐츠 명</option>
					<option value="con_layout" <?php if($key == "con_layout") echo "selected"; ?>>콘텐츠 레이아웃</option>
				</select>
				<input class="input-small" type="text" placeholder=".input-small" name="keyword" size="9" value="<?php echo $keyword?>">
				<INPUT class="btn btn-small" type="button" value="검색" name="formbutton1" onclick="search_confirm();">
			</td>
			<td width="40%">
				<p align="right"> 콘텐츠 : <?php echo $total_record?>개 ( <?php echo $page?> 페이지 / 총 <?php echo $total_page?> 페이지 )</p>
			</td>
		</tr>
	</form>
</table>
<table class="table table-hover" border=0 width=100%>
	<tr>
		<tr bgcolor="#F6F6F6">
		<td align=center>번호</font>
		<td align=center>id</font>
		<td align=center>메뉴명</font>
		<td align=center>스킨명</font>
		<td align=center>출력여부</font>
		<td align=center>메뉴위치</font>
		<td align=center>카운트</font>
		<td align=center>수정</font>
		<td align=center>삭제</font>
		<td align=center>보기</font>
	<tr>
<?php foreach($result as $row){ ?>
	<tr>
		<td align=center><?php echo $row->no?>
		<td align=center><?php echo $row->con_id?>
		<td align=center><?php echo $row->con_name?>
		<td align=center><?php echo $row->con_skin?>
<!-- 메뉴에 출력여부를 숫자를 문자로 바꾸어서 출력함 -->
<?php if($row->con_use==1){
	$row->con_use="출력";
	}else{
		$row->con_use="미출력";
	}?>
		<td align=center><?php echo $row->con_use?>
		<td align=center><?php echo $row->con_place?>
		<td align=center><?php echo $row->con_view?>
		<td align=center><a href=<?php echo base_url()?>admin/contents/edit_form/id/<?php echo $this->id?>/page/<?php echo $this->page?>/no/<?php echo $row->no?>>수정</a>
		<td align=center><a href=<?php echo base_url()?>admin/contents/delete/id/<?php echo $this->id?>/page/<?php echo $this->page?>/no/<?php echo $row->no?> onclick="return confirm('삭제하시겠습니까?')">삭제</a>
		<td align=center><a href=<?php echo base_url()?>admin/contents/read/id/<?php echo $this->id?>/page/<?php echo $this->page?>/no/<?php echo $row->no?>>보기</a>
	<tr>
<?php } ?>
</table>
<table border=0 width=100%>
	<tr>
		<td id=pagination align=center>
		<?php echo $pagenum?>
	<tr>
		<td align=center>
			<input class="btn btn-small btn-info" type="button" value="페이지 생성" onclick="location.href='<?php echo base_url()?>admin/contents/write_form/id/<?php echo $this->id?>/no/<?php echo $this->no?>'";>
			<input class="btn btn-small" type="button" onclick="history.back(1)" value="이전" />
</table>