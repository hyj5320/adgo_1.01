
<br><br>

</div>
	<div class="row-fluid">
		<div class="span12">
<!-- 카피라이터 부분 레이아웃 설정에 따라 변경됨 -->
<?php echo $site_copyright; ?>
		</div>
	</div>

	<script src="<?php echo base_url()?>include/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
