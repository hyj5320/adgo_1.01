<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<title><?php echo $popup_title?></title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>include/css/admin.css" media="screen"/>
	<script type="text/javascript"  src="http://code.jquery.com/jquery-latest.js"></script>
</head>
<body>

	<div id="popclose">
		<button id="p_close"> 닫기 </button>
	</div>

	<div id="popupbody">
		<p><?php echo $popup_content?></p>
	</div>

	<script type="text/javascript">
	$('#p_close').click(function(){
	javascript:window.close()
	parent.p<?php echo $this->uri->segment(9)?>.close() 
	});
	</script>

</body>
</html>