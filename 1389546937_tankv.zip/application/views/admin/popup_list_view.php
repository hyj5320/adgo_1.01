<SCRIPT LANGUAGE=JAVASCRIPT>  
	function search_confirm()
	{
		if(document.search_form.keyword.value == '')
		{
			alert('검색어를 입력하세요.');
			document.search_form.keyword.focus();
			return;
		}
		document.search_form.submit();
	}
</SCRIPT>
<h1>팝업 리스트</h1>

<table align="center" cellpadding="0" cellspacing="0" width="100%">
	<form name="search_form" method="post" action="<?php echo $act_url?>">
		<tr>
			<td width="60%">
				<select class="span4" name="key">
					<option value="popup_title" <?php if($key == "popup_title") echo "selected"; ?>>타이틀</option>
					<option value="popup_type" <?php if($key == "popup_type") echo "selected"; ?>>타입</option>
					<option value="popup_content" <?php if($key == "popup_content") echo "selected"; ?>>내용</option>
				</select>
				<input class="input-small" type="text" placeholder=".input-small" name="keyword" size="9" value="<?php echo $keyword?>">
				<INPUT class="btn btn-small" type="button" value="검색" name="formbutton1" onclick="search_confirm();">
			</td>
			<td width="40%">
				<p align="right"> 팝업 : <?php echo $total_record?>개 ( <?php echo $page?> 페이지 / 총 <?php echo $total_page?> 페이지 )</p>
			</td>
		</tr>
	</form>
</table>

<table class="table table-hover" border=0>
	<tr bgcolor="#F6F6F6">
		<td align=center>번호</font>
		<td align=center>출력여부</font>
		<td align=center>타이틀</font>
		<td align=center>출력시작일시</font>
		<td align=center>출력종료일시</font>
		<td align=center>수정</font>
		<td align=center>삭제</font>
		<td align=center>보기</font>
	<tr>
<?php foreach($result as $row){ ?>
	<tr>
		<td align=center><?php echo $row->popup_no?>
<?php if($row->popup_hidden==1)
{
	$row->popup_hidden="출력";
}
else
{
	$row->popup_hidden="미출력";
}?>
		<td align=center><?php echo $row->popup_hidden?>
		<td><?php echo $row->popup_title?>
		<td align=center><?php echo $row->popup_start_date?>
		<td align=center><?php echo $row->popup_end_date?>
		<td align=center><a href=<?php echo base_url()?>admin/popup/edit_form/id/<?php echo $this->id?>/page/<?php echo $this->page?>/no/<?php echo $row->popup_no?>>수정</a>
		<td align=center><a href=<?php echo base_url()?>admin/popup/delete/id/<?php echo $this->id?>/page/<?php echo $this->page?>/no/<?php echo $row->popup_no?> onclick="return confirm('삭제하시겠습니까?')">삭제</a>
		<td align=center>
<?php
$atts = array(
					 'width'      => "$row->popup_size_width",
					'height'     => "$row->popup_size_height",
					'scrollbars' => "$row->popup_scroll",
					'status'     => 'yes',
					'resizable'  => 'yes',
					'screenx'    => '0',
					'screeny'    => '0'
					);
?>
<?php echo anchor_popup("admin/popup/read/id/$this->id/page/$this->page/no/$row->popup_no", '보기', $atts); ?>
	<tr>
<?php } ?>
</table>

<table border="0" width="100%">
	<tr>
		<td id="pagination" align="center">
		<?php echo $pagenum?>
	<tr>
</table>

		<div align="center">
			<input class="btn btn-small btn-info" type="button" value="팝업 생성" onclick="location.href='<?php echo base_url()?>admin/popup/write_form/id/<?php echo $this->id?>/no/<?php echo $this->no?>'";>
			<input class="btn btn-small" type=button value=' 이전 ' onclick="history.back(1)">
		</div>