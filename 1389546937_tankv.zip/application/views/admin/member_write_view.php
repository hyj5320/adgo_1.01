<?php
if ($use_username){
	$username = array(
		'name'	=> 'username',
		'id'	=> 'username',
		'value' => set_value('username'),
		'maxlength'	=> $this->config->item('username_max_length', 'tank_auth'),
		'size'	=> 30,
	);
}
//폼별 속성
$kname = array(
	'name'	=> 'kname',//폼네임
	'id'	=> 'kname',//폼 id
	'value' => set_value('kname'),//폼 기본값
	'maxlength'	=> '10',//최대 입력 가능 글자수
	'size'	=> 30,//입력폼 사이즈
);
$nickname = array(
	'name'	=> 'nickname',
	'id'	=> 'nickname',
	'value' => set_value('nickname'),
	'maxlength'	=> '20',
	'size'	=> 30,
);
$email = array(
	'name'	=> 'email',
	'id'	=> 'email',
	'value'	=> set_value('email'),
	'maxlength'	=> 80,
	'size'	=> 30,
);
$mobile = array(
	'name'	=> 'mobile',
	'id'	=> 'mobile',
	'value' => set_value('mobile'),
	'maxlength'	=> '13',
	'size'	=> 30,
);
$telephone = array(
	'name'	=> 'telephone',
	'id'	=> 'telephone',
	'value' => set_value('telephone'),
	'maxlength'	=> '10',
	'size'	=> 30,
);
$zipcode1 = array(
	'class'=>'input-mini',
	'placeholder'=>'.input-mini',
	'name'	=> 'zipcode1',
	'id'	=> 'zipcode1',
	'value' => set_value('zipcode1'),
	'maxlength'	=> '6',
	'size'	=> 6,
	'readonly' => 'readonly',
);
$zipcode2 = array(
	'class'=>'input-mini',
	'placeholder'=>'.input-mini',
	'name'	=> 'zipcode2',
	'id'	=> 'zipcode2',
	'value' => set_value('zipcode2'),
	'maxlength'	=> '6',
	'size'	=> 6,
	'readonly' => 'readonly',
);
$address1 = array(
	'name'	=> 'address1',
	'id'	=> 'address1',
	'value' => set_value('address1'),
	'maxlength'	=> '50',
	'size'	=> 30,
	'readonly' => 'readonly',
);
$address2 = array(
	'name'	=> 'address2',
	'id'	=> 'address2',
	'value' => set_value('address2'),
	'maxlength'	=> '50',
	'size'	=> 30,
);
$homepage = array(
	'name'	=> 'homepage',
	'id'	=> 'homepage',
	'value' => set_value('homepage'),
	'maxlength'	=> '40',
	'size'	=> 30,
);
$birthday = array(
	'name'	=> 'birthday',
	'id'	=> 'datepicker',
	'value' => set_value('birthday'),
	'maxlength'	=> '10',
	'size'	=> 27,
);
$sex = array(
	'name' => 'sex',
	'id'	=> 'sex',
	'value' => set_value('sex'),
	'maxlength'	=> '10',
	'size'	=> 30,
);
$job = array(
	'name' => 'job',
	'id'	=> 'job',
	'value' => set_value('job'),
	'maxlength'	=> '15',
	'size'	=> 30,
);
$password = array(
	'name'	=> 'password',
	'id'	=> 'password',
	'value' => set_value('password'),
	'maxlength'	=> $this->config->item('password_max_length', 'tank_auth'),
	'size'	=> 30,
);
$confirm_password = array(
	'name'	=> 'confirm_password',
	'id'	=> 'confirm_password',
	'value' => set_value('confirm_password'),
	'maxlength'	=> $this->config->item('password_max_length', 'tank_auth'),
	'size'	=> 30,
);
?>
<script>
	function search_zipcode()
	{
		window.open("<?php echo base_url()?>auth/search_zip","우편번호검색"," width=420, height=500"); 
	}
</script>

<script>
$.datepicker.regional['ko']= {
closeText:'닫기',
prevText:'이전달',
nextText:'다음달',
currentText:'오늘',
monthNames:['1월(JAN)','2월(FEB)','3월(MAR)','4월(APR)','5월(MAY)','6월(JUM)','7월(JUL)','8월(AUG)','9월(SEP)','10월(OCT)','11월(NOV)','12월(DEC)'],
monthNamesShort:['1월','2월','3월','4월','5월','6월','7월','8월','9월','10월','11월','12월'],
dayNames:['일','월','화','수','목','금','토'],
dayNamesShort:['일','월','화','수','목','금','토'],
dayNamesMin:['일','월','화','수','목','금','토'],
weekHeader:'Wk',

dateFormat:'yy-mm-dd',
showAnim: "slideDown",
changeMonth: true,
changeYear: true,
yearRange: "-60:-10",
showOn: "both",
buttonImage: "<?php echo base_url()?>images/calendar.gif", 
buttonImageOnly: true,


firstDay:0,
isRTL:false,
showMonthAfterYear:true,
yearSuffix:''
};

$(function() 
{
	$.datepicker.setDefaults( $.datepicker.regional[ "" ] ); 
	$( "#datepicker" ).datepicker( $.datepicker.regional[ "ko" ] ); 
});
</script>

<h1>회원 생성</h1>
<table class="table table-hover" border=0>
<?php $attributes = array('name' => 'tx_editor_form', 'id' => 'tx_editor_form');?>
<?php echo form_open_multipart("admin/member/write_form/table/$this->table/", $attributes);?>
	<tr>
		<td><?php echo form_label('아이디', $username['id']); ?></td>
		<td><?php echo form_input($username); ?></td>
		<td style="color: red;"><?php echo form_error($username['name']); ?><?php echo isset($errors[$username['name']])?$errors[$username['name']]:''; ?></td>
	</tr>
	<tr>
		<td><?php echo form_label('닉네임', $nickname['id']); ?></td>
		<td><?php echo form_input($nickname); ?></td>
		<td style="color: red;"><?php echo form_error($nickname['name']); ?><?php echo isset($errors[$nickname['name']])?$errors[$nickname['name']]:''; ?></td>
	</tr>
	<tr>
		<td><?php echo form_label('이메일', $email['id']); ?></td>
		<td><?php echo form_input($email); ?><br>
		<input type="checkbox" name="re_email" value="1" checked="checked" />뉴스레터, 공지메일을 수신
		<td style="color: red;"><?php echo form_error($email['name']); ?><?php echo isset($errors[$email['name']])?$errors[$email['name']]:''; ?>
	</tr>
	<tr>
		<td><?php echo form_label('비밀번호', $password['id']); ?></td>
		<td><?php echo form_password($password); ?></td>
		<td style="color: red;"><?php echo form_error($password['name']); ?></td>
	</tr>
	<tr>
		<td><?php echo form_label('비밀번호 재입력', $confirm_password['id']); ?></td>
		<td><?php echo form_password($confirm_password); ?></td>
		<td style="color: red;"><?php echo form_error($confirm_password['name']); ?></td>
	</tr>
<!-- 1=사용, 2=필수사용 -->
<?php if($use['kname'] ==1 || $use['kname'] ==2){?>		
	<tr>
		<td><?php echo form_label('이름', $kname['id']); ?></td>
		<td><?php echo form_input($kname); ?></td>
		<td style="color: red;"><?php echo form_error($kname['name']); ?><?php echo isset($errors[$kname['name']])?$errors[$kname['name']]:''; ?></td>
	</tr>
<?php }?>
		<!-- mobile 추가(필드 추가시 참조 nickname-->
<?php if($use['mobile'] ==1 || $use['mobile'] ==2){?>	
	<tr>
		<td><?php echo form_label('핸드폰', $mobile['id']); ?></td>
		<td><?php echo form_input($mobile); ?><br>
		<input type="checkbox" name="re_mobile" value="1" checked="checked" />알림문자 수신
		<td style="color: red;"><?php echo form_error($mobile['name']); ?><?php echo isset($errors[$mobile['name']])?$errors[$mobile['name']]:''; ?></td>
	</tr>
<?php }?>
<?php if($use['telephone'] ==1 || $use['telephone'] ==2){?>	
	<tr>
		<td><?php echo form_label('전화', $telephone['id']); ?></td>
		<td><?php echo form_input($telephone); ?></td>
		<td style="color: red;"><?php echo form_error($telephone['name']); ?><?php echo isset($errors[$telephone['name']])?$errors[$telephone['name']]:''; ?></td>
	</tr>
<?php }?>
<?php if($use['zip_address'] ==1 || $use['zip_address'] ==2){?>	
	<tr> 
		<td>우편번호
	<td><?php echo form_input($zipcode1); ?> - <?php echo form_input($zipcode2); ?>		<input class="btn btn-small" type=button value= ' 검 색 '  onclick="search_zipcode();">
		<td>
  <tr>
		<td><?php echo form_label('주소1', $address1['id']); ?></td>
		<td> <?php echo form_input($address1); ?>
		<td style="color: red;"><?php echo form_error($address1['name']); ?><?php echo isset($errors[$address1['name']])?$errors[$address1['name']]:''; ?></td>
	<tr>
		<td><?php echo form_label('주소2', $address2['id']); ?></td>
		<td><?php echo form_input($address2); ?></td>
		<td style="color: red;"><?php echo form_error($address2['name']); ?><?php echo isset($errors[$address2['name']])?$errors[$address2['name']]:''; ?></td>
	</tr>
<?php }?>
<?php if($use['homepage'] ==1 || $use['homepage'] ==2){?>	
	<tr>
		<td><?php echo form_label('홈페이지', $homepage['id']); ?></td>
		<td><?php echo form_input($homepage); ?></td>
		<td style="color: red;"><?php echo form_error($homepage['name']); ?><?php echo isset($errors[$homepage['name']])?$errors[$homepage['name']]:''; ?></td>
	</tr>
<?php }?>
<?php if($use['birthday'] ==1 || $use['birthday'] ==2){?>	
	<tr>
		<td><?php echo form_label('생일', $birthday['id']); ?></td>
		<td><?php echo form_input($birthday); ?></td>
		<td style="color: red;"><?php echo form_error($birthday['name']); ?><?php echo isset($errors[$birthday['name']])?$errors[$birthday['name']]:''; ?></td>
	</tr>
<?php }?>
<?php if($use['sex'] ==1 || $use['sex'] ==2){?>	
	<tr>
		<td><?php echo form_label('성별', $sex['id']); ?></td>
		<td>
			<select name="sex" >
				<option value="">성별 선택</option>
				<option value="">----------</option>
				<option value="남성" <?php echo set_select('sex', '남성'); ?> >남성</option> 
				<option value="여성" <?php echo set_select('sex', '여성'); ?> >여성</option> 
			</select> 
		<td><?php echo form_error('sex'); ?>
	</tr>
<?php }?>
<?php if($use['job'] ==1 || $use['job'] ==2){?>	
	<tr>
		<td>직업
		<td>
			<select name="job">
				<option value="">직업 선택</option>
				<option value="">------------------</option>
<option value="">직업 선택</option>
				<option value="">------------------</option>
				<option value="주부" <?php echo set_select('job', '주부'); ?>>ㆍ주부</option>
				<option value="중/고생" <?php echo set_select('job', '중/고생'); ?>>ㆍ중/고생</option>
				<option value="대학생" <?php echo set_select('job', '대학생'); ?>>ㆍ대학생</option>
				<option value="대학원생" <?php echo set_select('job', '대학원생'); ?>>ㆍ대학원생</option>
				<option value="회사원" <?php echo set_select('job', '회사원'); ?>>ㆍ회사원</option>
				<option value="공무원" <?php echo set_select('job', '공무원'); ?>>ㆍ공무원</option>
				<option value="자영업" <?php echo set_select('job', '자영업'); ?>>ㆍ자영업</option>
				<option value="교직자" <?php echo set_select('job', '교직자'); ?>>ㆍ교직자</option>
				<option value="의료인" <?php echo set_select('job', '의료인'); ?>>ㆍ의료인</option>
				<option value="법조인" <?php echo set_select('job', '법조인'); ?>>ㆍ법조인</option>
				<option value="금융/증권" <?php echo set_select('job', '금융/증권'); ?>>ㆍ금융/증권</option>
				<option value="보험업" <?php echo set_select('job', '보험업'); ?>>ㆍ보험업</option>
				<option value="언론/방송" <?php echo set_select('job', '언론/방송'); ?>>ㆍ언론/방송</option>
				<option value="종교" <?php echo set_select('job', '종교'); ?>>ㆍ종교</option>
				<option value="농/축산" <?php echo set_select('job', '농/축산'); ?>>ㆍ농/축산</option>
				<option value="수산/광업" <?php echo set_select('job', '수산/광업'); ?>>ㆍ수산/광업</option>
				<option value="서비스업" <?php echo set_select('job', '서비스업'); ?>>ㆍ서비스업</option>
				<option value="군인" <?php echo set_select('job', '군인'); ?>>ㆍ군인</option>
				<option value="건설업" <?php echo set_select('job', '건설업'); ?>>ㆍ건설업</option>
				<option value="제조업" <?php echo set_select('job', '제조업'); ?>>ㆍ제조업</option>
				<option value="유통업" <?php echo set_select('job', '유통업'); ?>>ㆍ유통업</option>
				<option value="부동산업" <?php echo set_select('job', '부동산업'); ?>>ㆍ부동산업</option>
				<option value="인터넷" <?php echo set_select('job', '인터넷'); ?>>ㆍ인터넷</option>
				<option value="경영컨설팅" <?php echo set_select('job', '경영컨설팅'); ?>>ㆍ경영컨설팅</option>
				<option value="문화/예술" <?php echo set_select('job', '문화/예술'); ?>>ㆍ문화/예술</option>
				<option value="스포츠/레져" <?php echo set_select('job', '스포츠/레져'); ?>>ㆍ스포츠/레져</option>
				<option value="정보통신업" <?php echo set_select('job', '정보통신업'); ?>>ㆍ정보통신업</option>
				<option value="프리랜서" <?php echo set_select('job', '프리랜서'); ?>>ㆍ프리랜서</option>
				<option value="무직" <?php echo set_select('job', '무직'); ?>>ㆍ무직</option>
				<option value="기타" <?php echo set_select('job', '기타'); ?>>ㆍ기타</option>
			</select>
		<td><?php echo form_error('job'); ?>
	</tr>
<?php }?>
	<tr>
		<td>레벨
		<td><?php echo get_member_level_select('level', 0, 10 , 2) ?>레벨  (1:손님, 10:관리자)
		<td>
	<tr>
		<td>회원인증
		<td>
			<select name="activated" > 
				<option value="1" <?php echo set_select('activated', '1', TRUE); ?> >인증</option> 
				<option value="0" <?php echo set_select('activated', '0'); ?> >미인증</option> 
			</select> 
		<td><?php echo form_error('activated'); ?>
	<tr>
		<td>불량회원구분
		<td><select name="banned"> 
			<option value="0" <?php echo set_select('banned', '0', TRUE); ?> >정상회원</option> 
			<option value="1" <?php echo set_select('banned', '1'); ?> >불량회원</option> 
		<td><?php echo form_error('banned'); ?>
	<tr>
		<td width=150>불량회원 사유
		<td width=270><input type=text name=ban_reason size=30 maxlength=50 value="<?php echo set_value('ban_reason'); ?>">
		<td><?php echo form_error('ban_reason'); ?>
	<tr>
		<td>탈퇴회원구분
		<td><select name="users_out"> 
			<option value="1" <?php echo set_select('users_out', '1', TRUE); ?> >정상회원</option> 
			<option value="0" <?php echo set_select('users_out', '0'); ?> >탈퇴회원</option> 
		<td><?php echo form_error('users_out'); ?>
	<tr>
		<td width=150>탈퇴 사유
		<td width=270><input type=text name=out_reason size=30 maxlength=50 value="<?php echo set_value('out_reason'); ?>">
		<td><?php echo form_error('out_reason'); ?>
	<tr>
		<td>이미지 업로드
		<td>
<?php if(isset($views['file1'])){ ?>  
			<img  src=<?php echo base_url()?>file/<?php echo $this->table?>/<?php echo $views['file1']?> height='55' border="0"></a><br> 
<?php }else{ ?>  
			이미지가 없습니다.<br> 
<?php } ?>
			<input type="hidden" name="MAX_FILE_SIZE" value="1000000">
			<input type=file name=assa>
		<td>
	<tr>
		<td>회원메모
		<td colspan=3>
			<textarea name="memo" rows="20" cols="60" style=" width: 100%; height: 100px; overflow: visible;"><?php echo set_value('memo'); ?></textarea>
<?php echo form_error('memo'); ?>
</table>
	<div align=center>
			<input class="btn btn-small btn-info" type=submit value=' 회원 생성 '>	
			<input class="btn btn-small" type=button value=' 이전 ' onclick="history.back(1)">
	</div>
</form>