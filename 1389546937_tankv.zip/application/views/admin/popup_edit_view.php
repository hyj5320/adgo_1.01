<!-- 스마트 에디터 시작 -->
<script type="text/javascript" src="<?php echo base_url()?>editor/smart_editor/js/HuskyEZCreator.js" charset="utf-8"></script>
<!-- 스마트 에디터 끝 -->
<?php $attributes = array('name' => 'fboardform', 'id' => 'tx_editor_form');
echo form_open_multipart("admin/popup/edit_form/id/$this->id/no/$popup_no/",$attributes);?>
<h1><?php echo $popup_title?>  팝업 수정</h1>
<table class="table table-hover" border=0>
	<tr>
		<td width=150>팝업타이틀
		<td width=270><input type=text name=popup_title size=35 maxlength=50 value="<?php echo set_value('popup_title', $popup_title); ?>">
		<td><?php echo form_error('popup_title'); ?>
	<tr>
		<td>노출형식
		<td>
			<select name="popup_type" > 
				<option value="">팝업, 레이어 선택</option>
				<option value="">----------</option>
				<option value="browser" <?php echo set_select('popup_type', 'browser'); ?> >팝업창</option> 
				<option value="layer" <?php echo set_select('popup_type', 'layer'); ?> >레이어</option>  
			</select> 
		<td><?php echo form_error('popup_type'); ?>
<script type="text/javascript">document.fboardform.popup_type.value="<?php echo $popup_type?>";</script>
	<tr>
		<td>노출옵션
		<td>
			<select name="popup_scroll" > 
				<option value="">스크롤 선택</option>
				<option value="">----------</option>
				<option value="0" <?php echo set_select('popup_scroll', '0'); ?> >스크롤 사용</option> 
				<option value="1" <?php echo set_select('popup_scroll', '1'); ?> >스크롤 미사용</option>  
			</select> 
		<script type="text/javascript">document.fboardform.popup_scroll.value="<?php echo $popup_scroll?>";</script>

			<select name="popup_hidden" > 
				<option value="">일시중지 선택</option>
				<option value="">----------</option>
				<option value="0" <?php echo set_select('popup_hidden', '0'); ?> >일시중지</option> 
				<option value="1" <?php echo set_select('popup_hidden', '1'); ?> >일시중지 없음</option>  
			</select>
		<script type="text/javascript">document.fboardform.popup_hidden.value="<?php echo $popup_hidden?>";</script>
		<td>
			<?php echo form_error('popup_scroll'); ?>
			<?php echo form_error('popup_hidden'); ?>
	<tr>
		<td width="15%">노출기간
		<td width="30%">
			<select name="popup_term" > 
				<option value="">노출기간 제한 선택</option>
				<option value="">----------</option>
				<option value="1" <?php echo set_select('popup_term', '1'); ?> >노출기간 적용 않함</option> 
				<option value="0" <?php echo set_select('popup_term', '0'); ?> >노출기간 적용 실행</option>  
			</select>
		<script type="text/javascript">document.fboardform.popup_term.value="<?php echo $popup_term?>";</script>
		<td valign=top>
			<?php echo form_error('popup_term'); ?>
	<tr>
		<td>노출기간
		<td colspan=2>
<?php
			$y = date("Y",time());
			$m = date("m",time());
			$d = date("d",time());
?><li><?php
			echo get_date2_select('start_y', 2013, 2015, $y);?>년<?php
			echo get_date2_select('start_m', 01, 12, $m);?>월<?php
			echo get_date2_select('start_d', 01, 31, $d);?>일<?php
			echo get_date2_select('start_h', 00, 24, 00);?>시<?php
			echo get_date2_select('start_i', 00, 59, 00);?>분 부터<br>
<li>
<?php
			echo get_date2_select('end_y', 2013, 2015, $y);?>년<?php
			echo get_date2_select('end_m', 01, 12, $m);?>월<?php
			echo get_date2_select('end_d', 01, 31, $d);?>일<?php
			echo get_date2_select('end_h', 00, 24, 23);?>시<?php
			echo get_date2_select('end_i', 00, 59, 59) ;?>분 까지
	<tr>
		<td>노출크기
		<td>
		<?php echo get_date_select('popup_size_width', 100, 1000, $popup_size_width) ?>	 *
		<?php echo get_date_select('popup_size_height', 100, 1000, $popup_size_height) ?>
		픽셀
		<td>
			<?php echo form_error('popup_size_width'); ?>
			<?php echo form_error('popup_size_height'); ?>
	<tr>
		<td width=150>노출위치
		<td width=270>
		<?php echo get_date_select('popup_position_top', 0, 1000, $popup_position_top) ?>	 *
		<?php echo get_date_select('popup_position_left', 0, 1000, $popup_position_left) ?>
		픽셀
		<td>
			<?php echo form_error('popup_position_top'); ?>
			<?php echo form_error('popup_position_left'); ?>
	<tr>
		<td width=150>출력주소(도메인제외)
		<td width=270><input type="text" name="popup_place" size="35" maxlength="100" value="<?php echo set_value('popup_place',$popup_place); ?>">
		<td><?php echo form_error('popup_place'); ?>	
	<tr>
		<td colspan=3>
			<!-- 스마트 에디터 시작 -->
			<li>팝업 내용
			<textarea name="popup_content" id="ir1"  style="width:100%; height:412px; display:none;"><?php echo $popup_content?></textarea>
</table>
		<div align="center">
				<input class="btn btn-small btn-info" type="button" onclick="submitContents(this);" value="팝업 수정" />
			<input class="btn btn-small" type=button value=' 이전 ' onclick="history.back(1)">
		</div>
</form>
<script type="text/javascript">
var oEditors = [];
nhn.husky.EZCreator.createInIFrame({
	oAppRef: oEditors,
	elPlaceHolder: "ir1",
	sSkinURI: "<?php echo base_url()?>editor/smart_editor/SmartEditor2Skin.html",	
	htParams : {bUseToolbar : true,
		fOnBeforeUnload : function(){
			//alert("아싸!");	
		}
	}, //boolean
	fOnAppLoad : function(){
		//예제 코드
		//oEditors.getById["ir1"].exec("PASTE_HTML", ["로딩이 완료된 후에 본문에 삽입되는 text입니다."]);
	},
	fCreator: "createSEditor2"
});

function pasteHTML() {
	var sHTML = "<span style='color:#FF0000;'>이미지도 같은 방식으로 삽입합니다.<\/span>";
	oEditors.getById["ir1"].exec("PASTE_HTML", [sHTML]);
}

function showHTML() {
	var sHTML = oEditors.getById["ir1"].getIR();
	alert(sHTML);
}
	
function submitContents(elClickedObj) {
	oEditors.getById["ir1"].exec("UPDATE_CONTENTS_FIELD", []);	// 에디터의 내용이 textarea에 적용됩니다.
	
	// 에디터의 내용에 대한 값 검증은 이곳에서 document.getElementById("ir1").value를 이용해서 처리하면 됩니다.
	
	try {
		elClickedObj.form.submit();
	} catch(e) {}
}

function setDefaultFont() {
	var sDefaultFont = '궁서';
	var nFontSize = 24;
	oEditors.getById["ir1"].setDefaultFont(sDefaultFont, nFontSize);
}
</script>
<!-- 스마트 에디터 끝 -->