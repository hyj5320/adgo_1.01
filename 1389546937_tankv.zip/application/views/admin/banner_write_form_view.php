<h1>베너/이미지 등록</h1>
<table class="table table-hover" border=0>
<?php
$attributes = array('name' => 'tx_editor_form', 'id' => 'tx_editor_form');
echo form_open_multipart("admin/banner/write_form/id/$this->id/",$attributes);
?>
	<tr>
		<td width=150>베너 타이틀
		<td width=270><input
		 type=text name=banner_title size=40 maxlength=50 value="<?php echo set_value('banner_title'); ?>">
		<td><?php echo form_error('banner_title'); ?>
		<tr>
		<td>베너 링크
		<td><input type=text name=banner_link size=40 maxlength=50 value="<?php echo set_value('banner_link'); ?>">
		<td><?php echo form_error('banner_link'); ?>
	<tr>
		<td>베너 위치
		<td>
			<select name="banner_place"> 
				<option value="main_top" <?php echo set_select('banner_place', 'main_top', TRUE); ?> >메인페이지 상단</option> 
				<option value="main_left" <?php echo set_select('banner_place', 'main_left'); ?> >메인페이지 왼쪽</option> 
				<option value="main_right" <?php echo set_select('banner_place', 'main_right'); ?> >메인페이지 오른쪽</option> 
				<option value="main_foot" <?php echo set_select('banner_place', 'main_foot'); ?> >메인페이지 아래쪽</option> 
				<option value="main_middle" <?php echo set_select('banner_place', 'main_middle'); ?> >메인페이지 중간</option> 
				<option value="board_top" <?php echo set_select('banner_place', 'board_top'); ?> >게시판 상단</option> 
				<option value="board_left" <?php echo set_select('banner_place', 'board_left'); ?> >게시판 왼쪽</option> 
				<option value="board_right" <?php echo set_select('banner_place', 'board_right'); ?> >게시판 오른쪽</option> 
				<option value="board_foot" <?php echo set_select('banner_place', 'board_foot'); ?> >게시판 아래쪽</option> 
				<option value="board_middle" <?php echo set_select('banner_place', 'board_middle'); ?> >게시판 중간</option> 
			</select> 
		<td>
	<tr>
		<td>사용여부
		<td>   
			<select name="banner_use"> 
				<option value="1" <?php echo set_select('banner_use', '1', TRUE); ?> >사용</option> 
				<option value="0" <?php echo set_select('banner_use', '0'); ?> >미사용</option> 
		<td>
	<tr>
		<td>출력순서
		<td><?php echo get_member_level_select('banner_sequence', 1, 10, 1) ?>
		<li>숫자가 높을수록 상단이나 좌즉 노출
		<td>
	<tr>
		<td>target
		<td>
			<select name="banner_target"> 
				<option value="_blank" <?php echo set_select('banner_target', '_blank', TRUE); ?> >_blank</option> 
				<option value="_self" <?php echo set_select('banner_target', '_self'); ?> >_self</option> 
				<option value="_parent" <?php echo set_select('banner_target', '_parent'); ?> >_parent</option> 
				<option value="_top" <?php echo set_select('banner_target', '_top'); ?> >_top</option> 
			</select> 
		<td>
	<tr>
		<td>베너 폭
		<td><?php echo get_member_level_select('banner_width', 100, 1000, 150) ?>픽셀
		<td>
	<tr>
		<td>베너 높이
		<td><?php echo get_member_level_select('banner_height', 40, 200, 50) ?>픽셀
		<td>
	<tr>
		<td>베너카운터 증가간격
		<td><?php echo get_member_level_select('banner_count_time', 0, 24, 1) ?>시간
		<td>
	<tr>
		<td>베너 업로드
		<td>
			<input type="hidden" name="MAX_FILE_SIZE" value="1000000">
			<input class="btn btn-small" type="file" name="assa" size="10">jpg .png .gif 
		<td>
	<tr>
</table>
		<div align="center">
			<input class="btn btn-small btn-info" type=submit value=' 베너생성 '>
			<input class="btn btn-small" type=button value=' 이전 ' onclick="history.back(1)">
		</div>
</form>