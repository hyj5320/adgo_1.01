<script>
$(document).ready(function(){
	$("#search_btn").click(function(){
		var sfl_val = $(":select:option[name=sfl]:selected").val();
		if($("#q").val() == ''){
			alert('검색어를 입력하세요');
			return false;
		} else {
			var act = './q/'+$("#q").val()+'/sfl/'+sfl_val;
			$("#bd_search").attr('action', act).submit();
    	}
	});
});
</script>
<!--검색후 게시판 스타일  -->
<style>
.board_list { clear:both; width:100%; table-layout:fixed; margin:5px 0 0 0; }
.board_list th { font-weight:bold; font-size:12px; }
.board_list th { white-space:nowrap; height:34px; overflow:hidden; text-align:center; }
.board_list th { border-top:1px solid #ddd; border-bottom:1px solid #ddd; }

.board_list tr.bg1 { background-color:#fafafa; border-bottom:1px solid #ddd; }
.board_list tr.bg0 { background-color:#ffffff; border-bottom:1px solid #ddd; }

.board_list td { padding:.5em; font-family:Tahoma; font-size:12px; color:#808080; }

.board_list td.num { color:#999999; text-align:center; }
.board_list td.checkbox { text-align:center; }
.board_list td.subject { overflow:hidden; }
.board_list td.name { padding:0 0 0 10px; }
.board_list td.datetime { font:normal 12px tahoma; text-align:center; }
.board_list td.hit { font:normal 12px tahoma; text-align:center; }
.board_list td.good { font:normal 12px tahoma; text-align:center; }
.board_list td.nogood { font:normal 12px tahoma; text-align:center; }

.board_list .notice { font-weight:normal; }
.board_list .current { font:bold 11px tahoma; color:#E15916; }
.board_list .comment { font-family:Tahoma; font-size:10px; color:#EE5A00; }

.board_button { clear:both; margin:10px 0 0 0; }

.board_page { clear:both; font:normal 12px tahoma; text-align:center; margin:3px 0 0 0; }
.board_page a:link { color:#777; }

.board_search { text-align:center; margin:10px 0 0 0; }
.board_search .stx { height:18px; border:1px solid #9A9A9A; border-right:1px solid #D8D8D8; border-bottom:1px solid #D8D8D8; }
</style>

<h1>통합검색 결과</h1>검색어 "<?php echo $search_word?>"
<table width="97%" align="center" cellpadding="0" cellspacing="0">
<tr>
	<td>
    <table cellspacing="0" cellpadding="0" class="board_list">
    <col width="100" />
    <col />
    <col width="80" />
    <col width="80" />
	<col width="50" />
	<col width="50" />
    <tr>
	    <th>게시판</th>
	    <th>제&nbsp;&nbsp;&nbsp;목</th>
	    <th>닉네임</th>
	    <th>날짜</th>
	    <th>조회</th>
	</tr>
<?php
if($search_total > '0')
{
	foreach ($search_list as $lt)
	{
		$bubble_title = strip_tags(strcut_utf8($lt['content'], 200));
?>
 	<tr class="bg0">
    	<td class="num"><?php echo  $lt['table'] ?></td>
     	<td class="subject"><a href="<?php echo base_url()?>board/read/id/<?php echo  $lt['tbn'] ?>/page/1/num/<?php echo  $lt['num'] ?>/<?php echo $search_url?>" title="<?php echo  $bubble_title ?>"><?php echo strcut_utf8(strip_tags($lt['subject']), 30) ?></a> [<?php echo $lt['comments']?>]
<?php //24시간내 작성글 new아이콘 출력
    $int_time = strtotime($lt['wdate']);
    if(time()-$int_time<86400) {?>
	&nbsp;<img src="<?php echo base_url()?>images/icon_new.gif" title="24시간내 작성된 글입니다.">
<?php }?>		
		</td>
		<td class="name" align="center"><span class='guest'><?php echo  $lt['nickname']; //  if($lt['nickname']) { echo $lt['nickname']; } else { echo $lt['user_name']; } ?></span></td>
        <td class="datetime"><?php echo  substr($lt['wdate'], 0, 10) ?></td>
        <td class="hit"><?php echo  $lt['view'] ?></td>
  	</tr>
<?php
	}
}
else
{
?>
	<tr>
    	<td colspan="6" align="center"><br>
		검색결과가 없습니다.
		</td>
	</tr>
<?php
}
?>
    </table>
	<br />
  <!-- 페이지 -->
	  	  <div id=pagination>
	<?php echo  $pagination_links ?></div>
	</td>
</tr>
</table>
