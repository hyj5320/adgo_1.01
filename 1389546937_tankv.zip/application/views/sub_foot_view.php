<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
	if(isset($site_sub_layout))
	{
		include "./layouts/sub/$site_sub_layout/sub_foot_layout.php";
	}
	else
	{
		alert('관리자/사이트설정/서브 레이아웃(foot)을 확인하세요.'); 
	}
?>