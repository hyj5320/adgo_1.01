<?php if (!defined('BASEPATH')) exit('No direct script access allowed');?>
<meta http-equiv="content-type" content="text/html; charset=utf-8">

<!-- Bootstrap -->
<link href="<?php echo base_url()?>include/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
<!-- 반응형 네비게이션바 -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="<?php echo base_url()?>include/bootstrap/css/bootstrap-responsive.css" rel="stylesheet">

<a href="<?php echo base_url()?>memo/receive_list/id/memo/page">받은쪽지</a> |
<a href="<?php echo base_url()?>memo/send_list/id/memo/page">보낸쪽지</a> |
<a href="<?php echo base_url()?>memo/send_form/id/memo/page">쪽지 보내기</a>