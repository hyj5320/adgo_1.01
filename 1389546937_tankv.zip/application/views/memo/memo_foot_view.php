<?php if (!defined('BASEPATH')) exit('No direct script access allowed');?>
<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<script src="<?php echo base_url()?>include/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>