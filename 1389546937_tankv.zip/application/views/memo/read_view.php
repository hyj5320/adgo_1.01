<?php if (!defined('BASEPATH')) exit('No direct script access allowed');?>
<!DOCTYPE html>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<html>
<head>
<!-- Bootstrap -->
<link href="<?php echo base_url()?>include/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
<!-- 반응형 네비게이션바 -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="<?php echo base_url()?>include/bootstrap/css/bootstrap-responsive.css" rel="stylesheet">
</head>
<body>
<div align="right">
	<a href="<?php echo base_url()?>memo/receive_list/id/memo/page" class="btn btn-mini"><i class="icon-th-list"></i>받은쪽지</a>
	<a href="<?php echo base_url()?>memo/send_list/id/memo/page" class="btn btn-mini"><i class="icon-list-alt"></i>보낸쪽지</a>
	<a href="<?php echo base_url()?>memo/send_form/id/memo/page" class="btn btn-mini"><i class="icon-envelope"></i>쪽지 보내기</a>
</div>

<H4>쪽지 읽기
<?php //=if(isset($category)) echo "($category)";?>
</H4>
<table class="table table-striped" border="0" align="center" width="100%">
	<tr>
		<td class="span6">
			<h4>&nbsp;&nbsp;<?php echo $memo_subject?></h4>
		<td class="span3" align="right">
<?php if($memo_file1){?>
			<a href=<?php echo base_url()?>memo/file_down/id/<?php echo $this->id?>/file/<?php echo $memo_file1?>>
<i class="icon-download-alt"></i>...<?php echo substr($memo_file1,-20,20)?></a> &nbsp;&nbsp;
<?php }?>
</table>
						<!--  회원 케릭터이미지 출력 -->
<?php if($this->session->userdata('file1')){?>
			<img src = "<?php echo base_url()?>file/users/<?php echo $this->session->userdata('file1')?>" width="15" height="15" border="0" >
<?php }else{?>
			<img src = "<?php echo base_url()?>images/character.gif" width="15" height="15" border="0" >
<?php }?>  
			보낸아이디 :  <?php echo $memo_send_id?> | 
			보낸날자 : <?php echo $memo_send_date?> | 
			읽은시간 : 
<?php if($memo_receive_date)
{
 echo $memo_receive_date;
}else 
{
 echo "읽지 않음";
}
?>
<br><br>
			<table class="table table-bordered"  border="0" width="100%">
				<tr>
					<td><?php echo $memo_contents?></td>
			</table>
<div align="center">
			<a href="<?php echo base_url()?>memo/bad_count/id/<?php echo $this->id?>/page/<?php echo $this->page?>/no/<?php echo $this->no?>/" class="btn btn-small" onclick="return confirm('신고 하시겠습니까?')"><i class="icon-pencil"></i>신고(<?php echo $memo_bad_count?>회)</a>
		<td  align=center>
<?php if($this->session->userdata('level') >= $admin['level']){?>
			<a href="<?php echo base_url()?>memo/send_form/id/<?php echo $this->id?>/page/<?php echo $this->page?>/no/<?php echo $this->no?>" class="btn btn-small"><i class="icon-pencil"></i>쪽지쓰기</a>
<?php }?>
 <?php if($this->session->userdata('level') == 10 OR $memo_receive_id == $this->session->userdata('username') OR $memo_send_id == $this->session->userdata('username')){?>

 <!-- 받은쪽지 보낸쪽지를 구분해서 삭제 하기 위해서... -->
<?php if($memo_send_id == $this->session->userdata('username'))
			{
				$aaa = 'send';
			}
			elseif($memo_receive_id == $this->session->userdata('username'))
			{
				$aaa = 'receive';
			}
?>
			<a href="<?php echo base_url()?>memo/delete/id/<?php echo $this->id?>/page/<?php echo $this->page?>/no/<?php echo $this->no?>/<?php echo $aaa?>/" class="btn btn-small" onclick="return confirm('삭제하시겠습니까?')"><i class="icon-trash"></i>삭제</a>
<?php }?>	
			<a href="<?php echo base_url()?>/memo/receive_list/id/<?php echo $this->id?>/page/<?php echo $this->page?>/" class="btn btn-small"><i class="icon-list"></i>목록</a>
</div>
			<br>
<!--  
<?php //베너 출력
	$this->db->order_by('banner_sequence desc');//출력순서
	$this->db->where('banner_place', "board_middle");//베너위치
	$this->db->where('banner_use', 1);//사용여부
	$query = $this->db->get('banner');
	foreach ($query->result() as $row){?>
		<a href=<?php echo base_url()?>admin/banner/read/id/banner/no/<?php echo $row->banner_num?>/ target=<?php echo $row->banner_target?>>
		<img src=<?php echo base_url()?>file/banner/<?php echo $row->banner_image?> width=<?php echo $row->banner_width?> height=<?php echo $row->banner_height?>></a><br>
<?php }?>
	<br>
	-->

<!-- 아랫글 윗글 링크 (답글 무시하고 원글만 링크됨-오류라고 봐야하나????) 
<br>
<?php
	$no = $this->no;
	$this->db->where('memo_no >', $no);
	$this->db->limit(1);
	$query = $this->db->get($this->id);
	$row = $query->row_array();

	if (isset($row['memo_no'])){?>	
			<a href=<?php echo base_url()?>memo/read/id/<?php echo $this->id?>/page/<?php echo $this->page?>/no/<?php echo $row['memo_no']?>>▲윗&nbsp;&nbsp;&nbsp;글 | <?php echo $row['memo_subject']?></a>
<?php }
else
{
	echo"[윗글]";
}
?>
<br>
<?php
	$no2 = $this->no;
	$this->db->where('memo_no <', $no2);
	$this->db->order_by('memo_no desc');
	$this->db->limit(1);
	$query = $this->db->get($this->id);
	$row2 = $query->row_array();

	if (isset($row2['memo_no'])){?>
			<a href=<?php echo base_url()?>memo/read/id/<?php echo $this->id?>/page/<?php echo $this->page?>/no/<?php echo $row2['memo_no']?>>▼아랫글 | <?php echo $row2['memo_subject']?></a>
<?php }
else
{
echo" [아랫글]";
}
?>
-->
<br><br>
<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<script src="<?php echo base_url()?>include/bootstrap/js/bootstrap.min.js"></script>