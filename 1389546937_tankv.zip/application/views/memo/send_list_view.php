<?php if (!defined('BASEPATH')) exit('No direct script access allowed');?>
<!DOCTYPE html>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<html>
<head>
<!-- Bootstrap -->
<link href="<?php echo base_url()?>include/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
<!-- 반응형 네비게이션바 -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="<?php echo base_url()?>include/bootstrap/css/bootstrap-responsive.css" rel="stylesheet">

<SCRIPT LANGUAGE=JAVASCRIPT>  
	function search_confirm()
	{
		if(document.search_form.keyword.value == '')
		{
			alert('검색어를 입력하세요.');
			document.search_form.keyword.focus();
			return;
		}
		document.search_form.submit();
	 }
</SCRIPT>
</head>
<body>
<div align="right">
	<a href="<?php echo base_url()?>memo/receive_list/id/memo/page" class="btn btn-mini"><i class="icon-th-list"></i>받은쪽지</a>
	<a href="<?php echo base_url()?>memo/send_list/id/memo/page" class="btn btn-mini"><i class="icon-list-alt"></i>보낸쪽지</a>
	<a href="<?php echo base_url()?>memo/send_form/id/memo/page" class="btn btn-mini"><i class="icon-envelope"></i>쪽지 보내기</a>
</div>

<H4>보낸쪽지</H4>
<!--  
<?php if($admin['category_use'] == 'Y'){?>
<?php 
	$memo_category = explode ("|", $admin['category']);
?>
<form name="fboardform" method="post" action="<?php echo base_url()?>memo/send_list/id/<?php echo $this->id?>/page/1">
	<select name="memo_category" onchange="document.forms['fboardform'].submit();"> 
		<option value="">카테고리</option>
		<option value=''>-------------</option>
<?php foreach($memo_category as $row){ ?>
		<option value="<?php echo $row?>"><?php echo $row?></option>
<?php }?>
	</select>
	<script type="text/javascript">document.fboardform.memo_category.value="<?php echo $row->$memo_category?>";</script>
</form>
<?php }?> 

<table border=0 align="center" cellpadding="0" cellspacing="0" width="100%>">
	<form name="search_form" method="post" action="<?php echo $act_url?>">
	<tr>
		<td width="55%">
<?php
	$key = "";
	$keyword = "";
?>
			<select class="span4" name="key">
				<option value="memo_subject" <?php if($key == "memo_subject") 
				echo "selected"; ?>>제목</option>
				<option value="memo_contents" <?php if($key == "memo_contents") 
				echo "selected"; ?>>내용</option>
				<option value="memo_receive_id" <?php if($key == "memo_receive_id") 
				echo "selected"; ?>>받는아이디</option>
			</select>
			<input class="input-small" type="text" placeholder=".input-small" name="keyword" size="9" value="<?php echo $keyword?>">
			<INPUT class="btn btn-small" type=button value="검색" name=formbutton1 onclick="search_confirm();">
		<td width="45%">
			<p align="right"> 총 쪽지수:<?php echo $total_record?>개(<?php echo $page?>페이지/총<?php echo $total_page?>페이지)</p>
		</td>
	</tr>
	</form>
</table>
-->
<table class="table table-hover" border=0 width="100%">
	<tr bgcolor="#F6F6F6">
		<td align=center>제목</font>
		<td align=center>받는사람</font>
		<td align=center>읽은시간</font>
		<td align=center>삭제</font>
	<tr>
<?php foreach($result as $row){ ?>
	<tr align=center>
		<td align=left>
			<a href=<?php echo base_url()?>memo/read/id/<?php echo $this->id?>/page/<?php echo $this->page?>/no/<?php echo $row->memo_no?>><?php echo $row->memo_subject?></a>
		<td><?php echo $row->memo_receive_id?>
		<td>
<?php 
if($row->memo_receive_date == NULL)
{
	echo '읽지않음';
}
else
{
	echo substr($row->memo_receive_date,5,11);
}
?>
		<td><a href="<?php echo base_url()?>memo/delete/id/<?php echo $this->id?>/page/<?php echo $this->page?>/no/<?php echo $row->memo_no?>/send" onclick="return confirm('삭제하시겠습니까?')">삭제</a>
	<tr>
<?php } ?>
</table>

	<div align="center">
		<div id=pagination>
<?php echo $pagenum?>
		</div>

<?php if($this->session->userdata('level') >= $admin['level']){?>
		<div align="center">
			<input class="btn btn-small btn-info" type="button" value="쪽지쓰기" onclick="location.href='<?php echo base_url()?>memo/send_form/id/<?php echo $this->id?>/no/<?php echo $this->no?>'";>
			<input class="btn btn-small" type=button value=' 이전 ' onclick="history.back(1)">
<?php }?>
		</div>
<br>
<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<script src="<?php echo base_url()?>include/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>