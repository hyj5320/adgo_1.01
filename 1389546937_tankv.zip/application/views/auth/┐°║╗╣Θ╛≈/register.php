<form name="fregister" method="POST" onsubmit="return fregister_submit(this);" autocomplete="off">

<table width=600 cellspacing=0 cellspacing=0 align=center><tr><td align=center>
<br><br>
    <table width="100%" cellspacing="0" cellpadding="0">
    <tr> 
        <td align=center><img src="<?=base_url()?>layouts/<?=$site_layout?>/images/join_title.gif"</td>
    </tr>
    </table>

   <br>
    <table width="100%" cellpadding="4" cellspacing="0" bgcolor=#EEEEEE>
        <tr> 
            <td height=40>&nbsp; <b>회원가입약관</b></td>
        </tr>
        <tr> 
            <td align="center" valign="top"><textarea style="width: 98%" rows=10 readonly class=ed><?=implode("", file("./skin/text/agreement"));?></textarea></td>
        </tr>
        <tr> 
            <td height=40>
                &nbsp; <input type=radio value=1 name=agree id=agree11>&nbsp;<label for=agree11>동의합니다.</label>
                &nbsp; <input type=radio value=0 name=agree id=agree10>&nbsp;<label for=agree10>동의하지 않습니다.</label>
            </td>
        </tr>
    </table>

    <br>
    <table width="100%" cellpadding="4" cellspacing="0" bgcolor=#EEEEEE>
        <tr> 
            <td height=40>&nbsp; <b>개인정보취급방침</b></td>
        </tr>
        <tr> 
            <td align="center" valign="top"><textarea style="width: 98%" rows=10 readonly class=ed><?=implode("", file("./skin/text/private"));?></textarea></td></textarea></td>
        </tr>
        <tr> 
            <td height=40>
                &nbsp; <input type=radio value=1 name=agree2 id=agree21>&nbsp;<label for=agree21>동의합니다.</label>
                &nbsp; <input type=radio value=0 name=agree2 id=agree20>&nbsp;<label for=agree20>동의하지 않습니다.</label>
            </td>
        </tr>
    </table>

</td></tr></table>

<br>
<div align=center>
<input type=image width="66" height="20" src="<?=base_url()?>images/join_ok_btn.gif" border=0>
</div>

</form>


<script type="text/javascript">
function fregister_submit(f) 
{
    var agree1 = document.getElementsByName("agree");
    if (!agree1[0].checked) {
        alert("회원가입약관의 내용에 동의하셔야 회원가입 하실 수 있습니다.");
        agree1[0].focus();
        return false;
    }

    var agree2 = document.getElementsByName("agree2");
    if (!agree2[0].checked) {
        alert("개인정보취급방침의 내용에 동의하셔야 회원가입 하실 수 있습니다.");
        agree2[0].focus();
        return false;
    }

    f.action = "<?=base_url()?>auth/register/";
    return true;
}

if (typeof(document.fregister.username) != "undefined")
    document.fregister.username.focus();
</script>
<br><br>