<meta http-equiv="content-type" content="text/html; charset=utf-8">
<?php 
   @extract($_SERVER);
?>
<!-- opener부모페이지에 입력되는 코드 
tx_editor_form은 폼네임입니다. 폼네임과 필드 네임을 맞춰주면 됨-->
<script language="javascript">
   function send(code1, code2, code3){
       opener.tx_editor_form.zipcode1.value = code1;
       opener.tx_editor_form.zipcode2.value = code2;
       opener.tx_editor_form.address1.value = code3;
	   opener.tx_editor_form.address2.focus();
	   window.close();
   }
</script>
 <table align=center>
    <?php echo form_open("auth/search_zip")?>
<table>
  <tr>
     <td>
  <tr>
     <td>우편번호 검색
  <tr>
     <td>
  <tr>
     <td>							  
  <tr>
     <td> 찾을 주소의 동(읍/면)을 입력하세요 !!!<br><br>	
<input type=text name="search" size=50><input type=submit value= ' 검 색 '>
   <tr>
      <td>
	  <div style="height:330; widht=400; overflow:auto">
         <table align=center>
             <?php
                  if(isset($search)){
					foreach($result as $data){
					  $aa = explode("-",$data->zipcode);
                      $a= $aa['0'];
					  $b= $aa['1'];
              ?>
				 <tr>
				     <td> <a href=# onclick="send('<?php echo $a?>','<?php echo $b?>','<?php echo $data->sido?> <?php echo $data->gugun?> <?php echo $data->dong?> <?php echo $data->ri?>' )"><?php echo $data->zipcode?> <?php echo $data->sido?> <?php echo $data->gugun?> <?php echo $data->dong?> <?php echo $data->ri?> <?php echo $data->bunji?></a>
			 <?php
				   }
              ?>
			<tr>
			   <td>
          <?php
             }
			?>
         </table>
	  </div>
   <tr>
     <td>
</table>
<table align=center>
   <tr>
      <td height=30><a href="javascript:window.close()">[닫기]</a>
</table>
</form>