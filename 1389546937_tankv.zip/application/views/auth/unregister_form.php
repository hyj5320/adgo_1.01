<?php if (!defined('BASEPATH')) exit('No direct script access allowed');?>
<div class="span9">
<?php
$password = array(
	'name'	=> 'password',
	'id'	=> 'password',
	'size'	=> 30,
);
?>
<h1>회원탈퇴</h1>

<div class="alert alert-block">
	<button type="button" class="close" data-dismiss="alert">&times;</button>
	<h4>Warning!</h4>
		<li>회원 탈퇴 시 재 가입이 거부될 수 있으니 신중 한 결정 부탁 합니다.
		<li>회원정보의 일부는 회원가입 약관의 내용대로 일정기간 보관 후 삭제 됩니다. 
		<li>기타 문의 사항이 있으신 회원님은 관리자에게 연락 바랍니다. 감사합니다.
</div>

<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<?php echo form_open($this->uri->uri_string()); ?>
<table align="center">
	<tr>
		<td><?php echo form_label('비밀번호', $password['id']); ?></td>
		<td><?php echo form_password($password); ?></td>
		<td style="color: red;"><?php echo form_error($password['name']); ?><?php echo isset($errors[$password['name']])?$errors[$password['name']]:''; ?></td>
	</tr>
</table>
	<div align=center>
			<input class="btn btn-small btn-info" type=submit value=' 회원탈퇴 '>	
			<input class="btn btn-small" type=button value=' 이전 ' onclick="history.back(1)">
	</div>
<?php echo form_close(); ?>
</div>
