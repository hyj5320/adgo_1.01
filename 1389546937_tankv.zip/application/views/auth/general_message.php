<?php
alert($message);
?>