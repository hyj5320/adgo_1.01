<!-- view에서 업로드 용량을 적게 잡으면 업로드는 되지 않고 필드만 입력됨 -->
<?php
	 if($_FILES['assa'] ['name'])
	 { 
		
		//확장자 구함
		$ext = strpos($_FILES['assa']['name'],'.')!==false ? strtolower(strrchr($_FILES['assa']['name'],'.')) : '.unknown';
		
		//지정한 확장자 방지 
		$ext_check = explode(' ','.php .html .cgi .unknown');
		if ( in_array($ext,$ext_check) ) alert('사용 불가 확장자입니다.');
		
		//지정한 확장자 허용 
		$ext_check = explode(' ','.zip .jpg .png .gif'); 
		if ( !in_array($ext,$ext_check) ) alert('.zip .jpg .png .gif 파일만 업로드 가능합니다.'); 
		
		//저장될 디렉토리 생성 및 파일업로드
		if(!is_dir($dir))
		{
			mkdir($dir,0777);
		};

		//업로드 파일이 있다면 기존 파일 삭제
		@unlink("$dir".$uploadfile);

		//파일 확장장 앞에 시간값을 붙여 중복 방지
		$uploadfile =time()."_".$_FILES['assa'] ['name'];
		move_uploaded_file($_FILES['assa']['tmp_name'],"$dir".$uploadfile);
	}
?>