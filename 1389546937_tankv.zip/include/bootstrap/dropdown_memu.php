<!DOCTYPE html>
<html>
<head>
<title>Bootstrap 101 Template</title>
<!-- Bootstrap -->
<link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
<!-- 반응형 네비게이션바 -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="css/bootstrap-responsive.css" rel="stylesheet">

</head>
<body>
<h1>부트스트렙 예제</h1>
<div class="pagination">
<ul>
<li><a href="#">Prev</a></li>
<li><a href="#">1</a></li>
<li><a href="#">2</a></li>
<li><a href="#">3</a></li>
<li><a href="#">4</a></li>
<li><a href="#">5</a></li>
<li><a href="#">Next</a></li>
</ul>
</div>





버튼그룹<br>
<div class="btn-group">
	<button class="btn">Left</button>
	<button class="btn">Middle</button>
	<button class="btn">Right</button>
</div>

<br><br>왼쪽 서브메뉴 드랍다운메뉴<br>
<ul class="dropdown-menu" role="menu" aria-labelledby="dLabel" style="display: block; position: static; ">
	<li><a tabindex="-1" href="#">Action</a></li>
	<li><a tabindex="-1" href="#">Another action</a></li>
	<li><a tabindex="-1" href="#">Something else here</a></li>
	<li class="divider"></li>

	<li class="dropdown-submenu">
		<a tabindex="-1" href="#">More options</a>
			<ul class="dropdown-menu">
				<li><a tabindex="-1" href="#">Action</a></li>
				<li><a tabindex="-1" href="#">Action</a></li>
				<li><a tabindex="-1" href="#">Action</a></li>
	</li>
</ul>

<br><br><br><br><br><br><br><br>수직 메뉴<br>
<ul class="nav nav-tabs nav-stacked">
		<li><a href="#">서브메뉴1</a></li>
		<li><a href="#">Action</a></li>
		<li><a href="#">Action</a></li>
</ul>

<br><br>상단 드랍다운메뉴<br>
<div class="btn-group">
	<a class="btn dropdown-toggle" data-toggle="dropdown" href="#"> Action4. <span class="caret"></span></a>
	<ul class="dropdown-menu">
		<li><a tabindex="-1" href="#">서브메뉴1</a></li>
		<li><a tabindex="-1" href="#">Action</a></li>
		<li><a tabindex="-1" href="#">Action</a></li>
	</ul>
</div>

<br><br>왼쪽 서브메뉴 드랍다운메뉴2<br>
<div class="btn-group">
	<button class="btn">Action</button>
	<button class="btn dropdown-toggle" data-toggle="dropdown">
		<span class="caret"></span>
	</button>
	<ul class="dropdown-menu">
		<li><a tabindex="-1" href="#">Action</a></li>
		<li><a tabindex="-1" href="#">Action</a></li>
		<li><a tabindex="-1" href="#">Action</a></li>
	</ul>
</div>

<br><br>Basic navnar<br>
<div class="navbar">
	<div class="navbar-inner">
		<a class="brand" href="#">제목</a>
		<ul class="nav">
			<li class="active"><a href="#">Home</a></li>
			<li><a href="#">Link</a></li>
			<li><a href="#">Link</a></li>

<div class="btn-group">
	<a class="btn dropdown-toggle" data-toggle="dropdown" href="#"> Action4. <span class="caret"></span></a>
	<ul class="dropdown-menu">
		<li><a href="#">서브메뉴1</a></li>
		<li><a href="#">Action</a></li>
		<li><a href="#">Action</a></li>
	</ul>
</div>

<div class="btn-group">
	<a class="btn dropdown-toggle" data-toggle="dropdown" href="#"> Action4. <span class="caret"></span></a>
	<ul class="dropdown-menu">
		<li><a href="#">서브메뉴1</a></li>
		<li><a href="#">Action</a></li>
		<li><a href="#">Action</a></li>
	</ul>
</div>

	<form class="navbar-form pull-left">
		<input type="text" class="span2">
			<button type="submit" class="btn">Submit</button>
	</form>

		</ul>
	</div>
</div>

<br><br>Navbar(반응형 네비게이션바)<br>
<div class="navbar navbar-inner">
					<div class="container">
						<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
						</a>

							<div class="nav-collapse collapse">
								<ul class="nav pull-right">
									<li class="dropdown">
										<a href="about_01.html" class="dropdown-toggle" data-toggle="dropdown">회사소개</a>
											 <ul class="dropdown-menu">
												<li><a href="about_01.html">잉글리시토토 소개</a></li>
												<li><a href="about_02.html">교육시스템</a></li>
												<li><a href="about_03.html">강사채용</a></li>
												<li><a href="news.html">잉글리시토토 뉴스</a></li>
												</ul>
									</li>
									<li class="dropdown">
										<a href="curriculum_01.html" class="dropdown-toggle" data-toggle="dropdown">교육과정</a>
											 <ul class="dropdown-menu">
												<li><a href="curriculum_01.html">기본정규 영어</a></li>
												<li><a href="curriculum_02.html">비즈니스 영어</a></li>
												<li><a href="curriculum_03.html">시험대비 영어</a></li>
												<li><a href="curriculum_04.html">인터뷰 영어</a></li>
												</ul>
									</li>
									<li class="dropdown">
										<a href="tuition_01.html" class="dropdown-toggle" data-toggle="dropdown">수강안내</a>
											 <ul class="dropdown-menu">
												<li><a href="tuition_01.html">수강절차</a></li>
												<li><a href="tuition_02.html">수강료</a></li>
												<li><a href="tuition_03.html">수강신청</a></li>
												<li><a href="leveltest.html">레벨테스트신청</a></li>
												</ul>
									</li>
									<li class="dropdown">
										<a href="mypage_01.html" class="dropdown-toggle" data-toggle="dropdown">마이페이지</a>
											 <ul class="dropdown-menu">
												<li><a href="mypage_01.html">회원정보</a></li>
												<li><a href="mypage_02.html">내강의실</a></li>
												<li><a href="mypage_03.html">학습평가서</a></li>
												<li><a href="mypage_04.html">자가위치성적표</a></li>
												<li><a href="mypage_05.html">출석현황</a></li>
												<li><a href="mypage_06.html">영수증출력</a></li>
												</ul>
									</li>
									<li class="dropdown">
										<a href="notice.html" class="dropdown-toggle" data-toggle="dropdown">고객센터</a>
											 <ul class="dropdown-menu">
												<li><a href="notice.html">공지사항</a></li>
												<li><a href="review.html">수강 후기</a></li>
												<li><a href="faq.html">FAQ</a></li>
												<li><a href="agreement.html">이용자약관</a></li>
												<li><a href="privacy.html">개인정보보호정책</a></li>
												</ul>
									</li>
								</ul>
							</div>
					</div><!-- /.navbar -->
</div><!-- /.container -->

<br><br>Thumbnails<br>
<ul class="thumbnails">
	<li class="span3">
		<a href="#" class="thumbnail"><img src=class="media-object" data-src="holder.js/64x64"></a>
	</li>
	<li class="span3">
		<a href="#" class="thumbnail"><img src="http://localhost/board_tank/file/editor/1369068319_1361559517_lovemejuju_2805.jpg" alt=""></a>
	</li>
	<li class="span3">
		<a href="#" class="thumbnail"><img src="http://localhost/board_tank/file/editor/1369068319_1361559517_lovemejuju_2805.jpg" alt=""></a>
	</li>
	<li class="span3">
		<a href="#" class="thumbnail"><img src="http://localhost/board_tank/file/editor/1369068319_1361559517_lovemejuju_2805.jpg" alt=""></a>
	</li>
	<li class="span3">
		<a href="#" class="thumbnail"><img src="http://localhost/board_tank/file/editor/1369068319_1361559517_lovemejuju_2805.jpg" alt=""></a>
	</li>
	<li class="span3">
		<a href="#" class="thumbnail"><img src="http://localhost/board_tank/file/editor/1369068319_1361559517_lovemejuju_2805.jpg" alt=""></a>
	</li>
	<li class="span3">
		<a href="#" class="thumbnail"><img src="http://localhost/board_tank/file/editor/1369068319_1361559517_lovemejuju_2805.jpg" alt=""></a>
	</li>
</ul>

<br><br>동적 modal 팝업<br>  
<a href="#myModal" role="button" class="btn" data-toggle="modal">Launch demo modal</a>         
	<!-- Modal -->
	<div class="modal hide" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-header">                
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true">                    ×                </button> 
			<h3 id="myModalLabel">Modal header</h3>
		</div>
		<div class="modal-body">
			<p>One fine body… </p>
		</div> 
		<div class="modal-footer"> 
			<button class="btn" data-dismiss="modal" aria-hidden="true"> Close   </button>
			<button class="btn btn-primary">Save changes </button>
		</div>
	</div>

<br><br>정적 modal 팝업<br> 
<script type="text/javascript">
	$('#myModal2').modal('show')
</script>

<div class="modal hide fade" id="myModal2">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
		<h3>Modal header</h3>
	</div>
	<div class="modal-body">
		<p>One fine body…</p>
	</div>
	<div class="modal-footer">
		<a href="#" class="btn">Close</a>
		<a href="#" class="btn btn-primary">Save changes</a>
	</div>
</div>

<script src="http://code.jquery.com/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>