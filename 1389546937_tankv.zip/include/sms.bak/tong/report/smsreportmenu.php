<?php
	/***************************************************************************************
	*작성일 : 2011년 4월 14일
	*기  능 : 통큰아이에서 제공하는 SMS 발송 내역 조회
	*작성자 : 통큰아이 SMS 팀(sms@goodinternet.co.kr)
	*주의사항 :월 카운트 조회,상세리스트조회(전체,성공,실패),예약리스트 조회 함수를 사용할 수 있습니다.
	상세리스트 조회의 조회 가능 갯수는 5만개 이며 예약리스트 조회가능 갯수는 1만개 입니다.
	***************************************************************************************/
?>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<html>
<head>
<title>SMS 리포트 조회</title>
<script language="javascript">
<!--

function check_service_kind(e) {
	if (e == "count")	{
		window.menu1.style.display = "block";
		window.menu2.style.display = "none";
		window.menu3.style.display = "none";
	}
	else if (e == "report")	{
		window.menu1.style.display = "none";
		window.menu2.style.display = "block";
		window.menu3.style.display = "block";
	}
	else if(e == "reserve" || e == "remain")	{
		window.menu1.style.display = "none";
		window.menu2.style.display = "none";
		window.menu3.style.display = "none";
	}

	document.getElementById("report_kind").value = e;
}

function check_service_kind2(e) {
	document.getElementById("mode").value = e;
}
function frm_submit() {
	var kind = document.smsReport_process.report_kind.value;
	var askmonth = document.smsReport_process.askmonth.value;
	var firstdate = document.smsReport_process.firstdate.value;
	var seconddate = document.smsReport_process.seconddate.value;
	var mode = document.smsReport_process.mode.value;
	var URL = "./smsReport_process.php?kind="+kind+"&askmonth="+askmonth+"&firstdate="+firstdate+"&seconddate="+seconddate+"&mode="+mode;
	document.getElementById("content").src=URL;
}
-->
</script>
</head>
<body>
	<div id="pageBox">
    <div class="section">
    <H1>SMS 보고서</H1>
<form name="smsReport_process" method="post" >
<input type="hidden" name="report_kind" value="count">
<input type="hidden" name="mode" value="0">
<table width="95%" border="1" id="menu0" style="display:block">
	<tr>
		<td align="center" width="20%">조회 방법</td>
		<td align="center"><input type="radio" name="report_kind1" id="report_kind1" value="count"  onclick="check_service_kind('count')" checked>월 카운트 조회</td>
		<td align="center"><input type="radio" name="report_kind1" id="report_kind1" value="report" onclick="check_service_kind('report')">상세 리스트 조회</td>
		<td align="center"><input type="radio" name="report_kind1" id="report_kind1"  value="reserve" onclick="check_service_kind('reserve')">예약 내역 조회</td>
		<td align="center"><input type="radio" name="report_kind1" id="report_kind1"  value="reserve" onclick="check_service_kind('remain')">잔여일 조회</td>
</tr>
</table>
<table width="95%" border="1" id="menu1" style="display:block">
	<tr>
		<td align="center" width="20%">조회 월</td>
		<td align="center">
			&nbsp;&nbsp;
			<input type="text" name="askmonth" size="6" maxlength="6" value="201304">
			&nbsp;<font color="red">*</font> YYYYMM 형식으로 입력<font color="red">*</font>최근 6개월 이내의 정보만 조회가능합니다.
		</td>
	</tr>
</table>
<table width="95%" border="1" id="menu2" style="display:none">
	<tr>
		<td align="center" width="20%">조회 기간</td>
		<td align="left">
			&nbsp;&nbsp;
			<input type="text" name="firstdate" size="8" maxlength="8" value="20130401">~<input type="text" name="seconddate" size="8" maxlength="8" value="20130430"><font color="red">*</font> YYYYMMDD 형식으로 입력<font color="red">*</font>조회기간은 두개의 입력일자의 월이 같아야 합니다.
		</td>
	</tr>
</table>
<table width="95%" border="1" id="menu3" style="display:none">
	<tr>
		<td align="center" width="20%">조회모드</td>
		<td align="left">
			&nbsp;&nbsp;
			<input type="radio" name="mode1" value="0" onclick="check_service_kind2('0')" checked>전체조회
			<input type="radio" name="mode1" value="1" onclick="check_service_kind2('1')">성공 내역 조회
			<input type="radio" name="mode1" value="2" onclick="check_service_kind2('2')">실패 내역 조회
		</td>
	</tr>
</table>
</form>
<div align= center>
<input type="button" name="frm_submit" value="조회하기" onClick="javascript:frm_submit();">
<iframe name="content" id="content" src="" frameborder="0" width="100%" height="90%">
</body>
</html>