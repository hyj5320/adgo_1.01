<?php header("content-type:text/html; charset=utf-8");?>
<html>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>
</head>
<body>
<?php
	/*************************************************************************

	*작성일 : 2011년 01월 27일
	*기  능 : 통큰아이 모바일팀에서 제공하는 SMS 발송 내역 조회 웹서비스
	*작성자 : 통큰아이 모바일팀(sms@goodinternet.co.kr)

	*************************************************************************/
	include_once('nusoap_tong.php');
	include_once('result.php');

	$mod_select = "2";	// 기본조회모드 1 (일반사용자)
											// 향상된 조회모드 2  (xml-reader,xml writer 기능을 사용하는 고객)

	$kind=$_GET["kind"];										//조회 종류 (count : 월 카운트 조회, report : 상세리스트 조회,reserve : 예약리스트 조회)
	$askmonth=$_GET["askmonth"];			//월 카운트 조회 시 조회 할 월
	$firstdate=$_GET["firstdate"];						//상세 리스트 조회 시 조회 시작 일자
	$seconddate=$_GET["seconddate"];  //상세 리스트 조회 시 조회 마지막 일자
	$mode=$_GET["mode"];								//조회 모드 0 : 전체내역 조회  ,  1 :  발송성공내역조회 ,  2 : 발송실패내역조회
//SMS_ID : 707kib
//Password : 7070
	/******고객님 접속 정보************/
	$sms_id="707kib";					//고객님께서 부여 받으신 sms_id
	$sms_pwd="7070";				//고객님께서 부여 받으신 sms_pwd
	/*************************************/

	$sms = new SMS();								//SMS 객체 생성

	if($kind=="count"){								//월 카운트 조회시
		$result=$sms->CountreportSMS($sms_id,$sms_pwd,$askmonth);
	}
	else if($kind =="report"){				//상세 리스트 조회시
		$result=$sms->reportSMS($sms_id,$sms_pwd,$firstdate,$seconddate,$mode);
	}
	else if($kind =="reserve"){				//예약 리스트 조회시
		$result=$sms->ReservereportSMS($sms_id,$sms_pwd);
	}
	else if($kind =="remain"){
		$result=$sms->RemainSMS($sms_id,$sms_pwd);
	}

	if($mod_select =="1"){
		echo SMSresult($result);
	}
	else {
		if($kind=="count"){								//월 카운트 조회시
				echo "<table border='1' bordercolor='#cccccc' cellpadding='5' cellspacing='0'>";
				echo "<tr>";
				echo "<td>결과</td>";
				echo "<td>발송껀수</td>";
				echo "</tr>";
			}
			else if($kind =="report"){				//상세 리스트 조회시
				echo "<table border='1' bordercolor='#cccccc' cellpadding='5' cellspacing='0'>";
				echo "<tr>";
				echo "<td>발송일</td>";
				echo "<td>결과</td>";
				echo "<td>lmstitle</td>";
				echo "<td>발신번호</td>";
				echo "<td>수신번호</td>";
				echo "<td>발신내용</td>";
				echo "</tr>";
			}
			else if($kind =="reserve"){				//예약 리스트 조회시
				echo "<table border='1' bordercolor='#cccccc' cellpadding='5' cellspacing='0'>";
				echo "<tr>";
				echo "<td>발송일</td>";
				echo "<td>결과</td>";
				echo "<td>gubun</td>";
				echo "<td>lms제목</td>";
				echo "<td>발신번호</td>";
				echo "<td>수신번호</td>";
				echo "<td>발신내용</td>";
				echo "</tr>";
			}
			else if($kind =="remain"){		//잔여일 조회 시
				echo "<table border='1' bordercolor='#cccccc' cellpadding='5' cellspacing='0'>";
				echo "<tr>";
				echo "<td>시작일</td>";
				echo "<td>만기일</td>";
				echo "<td>서비스기간</td>";
				echo "<td>신청갯수</td>";
				echo "<td>남은일</td>";
				echo "<td>남은갯수</td>";
				echo "</tr>";
			}

		$check_emty = SMSresult($result);

		$nodate_alert = iconv('euckr','utf-8','조회 결과가 없습니다.');
		$check_erorr = iconv('euckr','utf-8','실패 에러코드 ').$check_emty.iconv('euckr','utf-8',' 입니다');

			/* 실패 에러코드
			*-- 0 : 잔여량부족
			*  -5 : 해쉬이상
			*  -9 : 조회일자 다름
			*  -10 : 조회 날짜1 이상
			*  -11 : 조회 날짜2 이상
			*  -12 : 조회 가능 일자 벗어남
			*  -13 : 스팸 동의서가 접수되지 않음
			*  -21 : 데이타 베이스 이상
			*/

		if($check_emty == "no_data"){ //조회결과가 없을 때
			echo "<tr>";
			echo "<td colspan='8'>";
			echo $nodate_alert;
			echo "</td>";
			echo "</tr>";
		} 
		else if( $check_emty <= "0"){ //에러발생시
			echo "<tr>";
			echo "<td colspan='8'>";
			echo $check_erorr;
			echo "</td>";
			echo "</tr>";
		} 
		else{
			$xmlDoc = new Domdocument();
			$xmlDoc->loadXML(SMSresult($result));

			foreach($xmlDoc->documentElement->childNodes as $oChildNode){

				echo "<tr>";

				$currNode = $oChildNode;

				foreach($currNode->childNodes as $ocurrNode){
					echo "<td>".$ocurrNode->nodeValue."</td>";
					if($currNode->childNodes->length == 5 & $ocurrNode->nodeName == "result"){
						echo "<td>&nbsp;</td>";
					}
				}
				echo "</tr>";
			}
		}
		echo "</table>";
	}
?>

</body>
</html>