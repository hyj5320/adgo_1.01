				<div class="span9">
						<div id="pageBox">
							<div class="section">
								<H1><?php echo $con_name?></H1>

<?php //콘텐츠 관리
	if($this->session->userdata('level') == 10){?>
<div class="alert alert-block">
	<button type="button" class="close" data-dismiss="alert">&times;</button>

		최종수정일 : <?php echo $con_wdate?>
		<div align="right">
			<a class="btn btn-mini" href="<?php echo base_url()?>admin/contents/edit_form/id/contents/no/<?php echo $no?>"><i class="icon-wrench"></i>콘텐츠 설정</a>
		</div>
</div>
<?php }?>
								<?php echo $content?>
							</div>
						</div>
				</div>
			</div>