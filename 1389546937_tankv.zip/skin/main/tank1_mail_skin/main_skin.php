<?php if (!defined('BASEPATH')) exit('No direct script access allowed');?>
<div class="row-fluid">
	<div class="span12">
		<ul class="thumbnails">
			<div class="span8">
<?php //디렉토리안 이미지들 읽어와 배열에 넣어 랜덤 출력
  $middle_images = directory_map("./images/main/",1);
  shuffle($middle_images);
  for ($i = 0; $i < 1; $i++) {?>
 <a href=<?php echo base_url()?> class="thumbnail">
 <img src="<?php echo base_url()?>/images/main/<?php echo $middle_images[$i]?>" class="img-rounded"></a>
<?php }?>
			</div><!-- span8 -->

	<div class="span4">
		<div class="mini-layout">
				<a class="btn btn-mini" href="<?php echo base_url()?>board/index/id/notice/page/1"><i class="icon-list-alt"></i> <b>공지사항</b></a>
			<hr>

<?php foreach ($result as $row){ ?>
				<li>
					<span class="label label-info">공지</span> 
					<a href="<?php echo base_url()?>board/read/id/notice/page/1/num/<?php echo $row->num?>" class="unstyled"> <?php echo $row->subject?></a>
				</li>
<?php } ?>

		</div><!-- span4-->
	</div><!-- mini-layout -->

			</div><!-- span8-->
		</ul><!-- thumbnails -->
	</div><!-- span12 -->
</div><!-- row-fluid -->

<div class="row-fluid">
	<div class="span12">
		<ul class="thumbnails">
<?php //베너 출력
  $this->db->order_by('banner_sequence desc');//출력순서
  $this->db->where('banner_place', "main_top");//베너위치
  $this->db->where('banner_use', 1);//사용여부
  $query = $this->db->get('banner');
  foreach ($query->result() as $row){?>
		<a href="<?php echo base_url()?>admin/banner/read/id/banner/no/<?php echo $row->banner_num?>" target="<?php echo $row->banner_target?>" class="thumbnail">
		<img src=<?php echo base_url()?>file/banner/<?php echo $row->banner_image?> width=<?php echo $row->banner_width?> height=<?php echo $row->banner_height?>></a>
<?php }?>
		</ul><!-- thumbnails -->
	</div ><!-- span12 -->
</div><!-- row-fluid -->


<ul class="thumbnails">
	<div class="row-fluid">
		<div class="span4">
			<a href="<?php echo base_url()?>" class="thumbnail"><img  src=<?php echo base_url()?>images/main1.gif></a>
		</div>
		<div class="span4">
			<a href=<?php echo base_url()?>  class="thumbnail"><img src=<?php echo base_url()?>images/main2.gif></a>
		</div>
		<div class="span4">
			<a href=<?php echo base_url()?>  class="thumbnail"><img src=<?php echo base_url()?>images/main3.gif></a>
		</div>
	</div><!-- row-fluid -->

	<div class="row-fluid">
			<div class="span4">
			<a href=<?php echo base_url()?>  class="thumbnail"><img  src=<?php echo base_url()?>images/main4.gif></a>
		</div>
		<div class="span4">
			<a href=<?php echo base_url()?>  class="thumbnail"><img src=<?php echo base_url()?>images/main5.gif></a>
		</div>
		<div class="span4">
			<a href=<?php echo base_url()?>  class="thumbnail"><img src=<?php echo base_url()?>images/main6.gif></a>
		</div>
	</div><!-- row-fluid -->

	<div class="row-fluid">
		<div class="span4">
			<a href=<?php echo base_url()?> class="thumbnail"><img  src=<?php echo base_url()?>images/main7.gif></a>
		</div>
		<div class="span4">
			<a href=<?php echo base_url()?>  class="thumbnail"><img src=<?php echo base_url()?>images/main8.gif></a>
		</div>
		<div class="span4">
			<a href=<?php echo base_url()?>  class="thumbnail"><img src=<?php echo base_url()?>images/main9.gif></a>
		</div>
	</div><!-- row-fluid -->

</ul><!-- thumbnails -->