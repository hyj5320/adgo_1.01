				<div class="span9">
<?php //gnum 결정
	$query = $this->db->query("select MAX(gnum) as gnum from $this->id where gnum<2000000000");
	$gnum = current( $query->row_array());
	$gnum += 1; 
?>
<!-- 다음 에디터 작업 시작 -->
<link rel="stylesheet" href="<?php echo base_url()?>editor/daum_editor/css/editor.css" type="text/css" charset="utf-8"/>
<script src="<?php echo base_url()?>editor/daum_editor/js/editor_loader.js" type="text/javascript" charset="utf-8"></script>
<!-- 다음 에디터 작업 끝 -->
<H1><?php echo $admin['board_title']?></H1>	
<table border=0 width=<?php echo $admin['width']?>>
	<!-- 다음에디터 name, id 삽입 -->
	<?php $attributes = array('name' => 'tx_editor_form', 'id' => 'tx_editor_form');?>
	<?php echo form_open_multipart("/board/write_form/id/$this->id/",$attributes);?>
		<input type="hidden" name="gnum" value="<?php echo $gnum?>">
		<input type="hidden" name="wr_user_id" value="<?php echo $this->session->userdata('username')?>">
		<input type="hidden" name="nick_name" value="<?php echo $this->session->userdata('nickname')?>">
		<input type="hidden" name="name" value="<?php echo $this->session->userdata('kname')?>">
	<tr>
		<td align=right>제목 
		<td width=100><input type=text name='subject' size=50 maxlength=100 value="<?php echo set_value('subject'); ?>" >	
		<td ><?php echo form_error('subject'); ?>
<?php if($admin['use_board_category'] == 1){?>
	<tr>
		<?php
		$admin_category = $admin['board_category'];
		$board_category = explode ("|", $admin_category);
		?>
		<td align=right>카테고리 
		<td>
			<select name="category">
				<option value="">카테고리</option>
				<option value=''>-------------</option>
<?php foreach($board_category as $row){ ?>
				<option value="<?php echo $row?>" <?php echo set_select('category', $row); ?> ><?php echo $row?></option> 
<?php }?> </select>
<?php }?>
		<td>
	<tr>
		<td align=right>업로더
		<td colspan=2>
		<input type="hidden" name="MAX_FILE_SIZE" value="1000000">
		<input type="file" name="assa" size="15">( jpg .png .gif )&nbsp;&nbsp;
<?php if($this->session->userdata('level') ==10){?>
		<input type=checkbox name=notice value='1'> 공지글사용
<?php }?>
	<tr>
		<td colspan=3>
<!-- 다음에디터 인쿠르드 및 글쓰기 버튼 -->
<?php include "./editor/daum_editor/editor_edit.php"?>
			<div align=center>
				<button onclick='saveContent()'>글쓰기</button> &nbsp;
				<button onclick="history.back(1)">이전</button> 
</table>
				</div>
			</div>