				<div class="span9">
<?php //depth 결정 - 답글기능
	$gnum = trim($gnum);
	$depth = trim($depth);
	$query = $this->db->query("select MAX(depth) as depth from $this->id where depth like '$depth%' and gnum=$gnum");
	$depth = $depth.chr(ord(substr($depth, -1)) +1);
?>
<!-- 제목 -->
<H1>
<?php echo $admin['board_title']?> 
<?php if(isset($category)) echo "($category)"?>
</H1>
<!-- 다음에디터 작업 시작 -->
<link rel="stylesheet" href="<?php echo base_url()?>editor/daum_editor/css/editor.css" type="text/css" charset="utf-8"/>
<script src="<?php echo base_url()?>editor/daum_editor/js/editor_loader.js" type="text/javascript" charset="utf-8"></script>
<!-- 다음에디터 id name삽입 -->
<table border=0 width=<?php echo $admin['width']?>>
	<?php $attributes = array('name' => 'tx_editor_form', 'id' => 'tx_editor_form');?>
	<?php echo form_open_multipart("/board/reply_form/id/$this->id/page/$this->page/num/$this->num/",$attributes);?>
		<input type="hidden" name="gnum" value="<?php echo $gnum?>">
		<input type="hidden" name="depth" value="<?php echo $depth?>">
		<input type="hidden" name="wr_user_id" value="<?php echo $this->session->userdata('username')?>">
		<input type="hidden" name="nick_name" value="<?php echo $this->session->userdata('nickname')?>">
		<input type="hidden" name="name" value="<?php echo $this->session->userdata('kname')?>">
	<tr>
		<td  width=100 align=right>제목
		<td width=200><input type=text name='subject' size=50 maxlength=100 value="[Re]<?php echo $subject?>" >
		<td><?php echo form_error('subject'); ?>
<?php if($admin['use_board_category'] == 1){?>
	<tr>
<?php
		$admin_category = $admin['board_category'];
		$board_category = explode ("|", $admin_category);
?>
		<td align=right width=100>카테고리 
		<td>
			<select name="category">
		<option value="">카테고리</option>
		<option value=''>-------------</option>
<?php foreach($board_category as $row){ ?>
				<option value="<?php echo $row?>" <?php echo set_select('category', $row); ?> ><?php echo $row?></option> 
<?php }?> </select>
		<td>
			<script type="text/javascript">document.tx_editor_form.category.value="<?php echo $category?>";</script>
<?php }?>
	<tr>
		<td  width=100 align=right>업로더
		<td colspan=2>
			<input type="hidden" name="MAX_FILE_SIZE" value="1000000">
			<input type="file" name="assa" size="15">( jpg .png .gif )
	<tr>
</table>

<!-- 다음에디터  인쿠르드 및 버튼 삽입 -->
<?php include "./editor/daum_editor/editor_edit.php"?>
				<div align=center>
					<button onclick='saveContent()'>답글쓰기</button> &nbsp;
					<button onclick="history.back(1)">이전</button> 
				</div>
			</div>
		</div>