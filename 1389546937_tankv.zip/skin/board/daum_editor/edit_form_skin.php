				<div class="span9">
<H1>
<?php echo  $admin['board_title'];
	if($category) echo "($category)";
?>
</H1>
<!-- 다음에디터 작업 시작 -->
<link rel="stylesheet" href="<?php echo base_url()?>editor/daum_editor/css/editor.css" type="text/css" charset="utf-8"/>
<script src="<?php echo base_url()?>editor/daum_editor/js/editor_loader.js" type="text/javascript" charset="utf-8"></script>
<!-- 다음에디터 작업 끝 -->
<table border=0 width=<?php echo $admin['width']?>>
<!-- 다음에디터 name, id 삽입 -->
<?php $attributes = array('name' => 'tx_editor_form', 'id' => 'tx_editor_form');?>
<?php echo form_open_multipart("/board/edit_form/id/$this->id/num/$this->num/",$attributes);?>
	<input type="hidden" name="wr_user_id" value="<?php echo $this->session->userdata('username')?>">
	<input type="hidden" name="nick_name" value="<?php echo $this->session->userdata('nickname')?>">
	<tr>
		<td width=100 align=right> 제목 
		<td width=200><input type=text name='subject' size=50 maxlength=100 value="<?php echo $subject?>" >
		<td><?php echo form_error('subject'); ?>
<?php if($admin['use_board_category'] == 1){?>
	<tr>
		<?php
		$admin_category = $admin['board_category'];
		$board_category = explode ("|", $admin_category);
		?>
		<td align=right width=100>카테고리 
		<td>
			<select name="category">
		<option value="">카테고리</option>
		<option value=''>-------------</option>
<?php foreach($board_category as $row){ ?>
				<option value="<?php echo $row?>" <?php echo set_select('category', $row); ?> ><?php echo $row?></option> 
<?php }?> </select>
			<script type="text/javascript">document.tx_editor_form.category.value="<?php echo $category?>";</script>
<?php }?>
	<tr>  
		<td width=100 align=right> 업로더 
		<td>
			<input type="hidden" name="MAX_FILE_SIZE" value="1000000">
			<input type="file" name="assa" size="15">&nbsp;(허용파일 : .zip .tar .gz .rar .pdf .ppt .xls .docx .xlsx .pptx)&nbsp;&nbsp;
<?php if($this->session->userdata('level') ==10){?>
			<input type=checkbox name=notice value='1'> 공지글사용
<?php }?>
		<td>
	<tr>
		<td colspan=3>
<!-- 다음에디터 인쿠르드 및 버튼 -->
<?php include "./editor/daum_editor/editor_edit.php"?>
			<div align=center>
				<button onclick='saveContent()'>글수정</button> &nbsp;
				<button onclick="history.back(1)">이전</button> 
			</div>
</table>
				</div>
			</div>