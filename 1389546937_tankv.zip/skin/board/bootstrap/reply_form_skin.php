				<div class="span9">
<?php //depth 결정 - 답글기능
	$gnum = trim($gnum);
	$depth = trim($depth);
	$query = $this->db->query("select MAX(depth) as depth from $this->id where depth like '$depth%' and gnum=$gnum");
	 $depth = $depth.chr(ord(substr($depth, -1)) +1);
?>
<div id="pageBox">
	<div class="section">
<H1>
<?php echo  $admin['board_title'];
	if($category) echo "($category)";
?>
</H1>
<script type="text/javascript" src="<?php echo base_url()?>editor/smart_editor/js/HuskyEZCreator.js" charset="utf-8"></script>
<table border=0 width=<?php echo $admin['width']?>>
<?php $attributes = array('name' => 'tx_editor_form', 'id' => 'tx_editor_form');?>
<?php echo form_open_multipart("/board/reply_form/id/$this->id/page/$this->page/num/$this->num/",$attributes);?>
	<input type="hidden" name="gnum" value="<?php echo $gnum?>">
	<input type="hidden" name="depth" value="<?php echo $depth?>">
	<input type="hidden" name="wr_user_id" value="<?php echo $this->session->userdata('username')?>">
	<input type="hidden" name="nick_name" value="<?php echo $this->session->userdata('nickname')?>">
	<input type="hidden" name="name" value="<?php echo $this->session->userdata('kname')?>">
	<tr>
		<td align=right>제목
		<td width=100><input type=text name='subject' size=30 maxlength=40 value="[Re]<?php echo $subject?>" >
		<td><?php echo form_error('subject'); ?>
<?php if($admin['use_board_category'] == 1){?>
	<tr>  
		<?php
		$admin_category = $admin['board_category'];
		$board_category = explode ("|", $admin_category);
		?>
		<td align=right width=100>카테고리 
		<td>
			<select name="category">
				<option value="">카테고리 선택</option>
				<option value=''>-------------</option>
<?php foreach($board_category as $row){ ?>
				<option value="<?php echo $row?>" <?php echo set_select('category', $row); ?> ><?php echo $row?></option> 
<?php }?> </select>
			<script type="text/javascript">document.tx_editor_form.category.value="<?php echo $category?>";</script>
<?php }?>
	<tr>
		<td align=right>업로더 
		<td colspan=2>
			<input type="hidden" name="MAX_FILE_SIZE" value="1000000">
			<input type="file" name="assa" size="15">&nbsp;(허용파일 : .zip .tar .gz .rar .pdf .ppt .xls .docx .xlsx .pptx)
	<tr>
		<td colspan=3>
			<textarea name="content" id="ir1" style="width:100%; height:412px; display:none;"><?php echo $content?></textarea>
			<div align=center>
				<input type="button" onclick="submitContents(this);" value="답글쓰기" />
				<input type="button" onclick="history.back(1)" value="이전" />
				<!-- 
				<input type="button" onclick="pasteHTML();" value="본문에 내용 넣기" />
				<input type="button" onclick="showHTML();" value="본문 내용 가져오기" />
				<input type="button" onclick="setDefaultFont();" value="기본 폰트 지정하기 (궁서_24)" />
				-->
			</div>
<script type="text/javascript">
var oEditors = [];
nhn.husky.EZCreator.createInIFrame({
	oAppRef: oEditors,
	elPlaceHolder: "ir1",
	sSkinURI: "<?php echo base_url()?>editor/smart_editor/SmartEditor2Skin.html",	
	htParams : {bUseToolbar : true,
		fOnBeforeUnload : function(){
			//alert("아싸!");	
		}
	}, //boolean
	fOnAppLoad : function(){
		//예제 코드
		//oEditors.getById["ir1"].exec("PASTE_HTML", ["로딩이 완료된 후에 본문에 삽입되는 text입니다."]);
	},
	fCreator: "createSEditor2"
});

function pasteHTML() {
	var sHTML = "<span style='color:#FF0000;'>이미지도 같은 방식으로 삽입합니다.<\/span>";
	oEditors.getById["ir1"].exec("PASTE_HTML", [sHTML]);
}

function showHTML() {
	var sHTML = oEditors.getById["ir1"].getIR();
	alert(sHTML);
}
	
function submitContents(elClickedObj) {
	oEditors.getById["ir1"].exec("UPDATE_CONTENTS_FIELD", []);	// 에디터의 내용이 textarea에 적용됩니다.
	
	// 에디터의 내용에 대한 값 검증은 이곳에서 document.getElementById("ir1").value를 이용해서 처리하면 됩니다.
	
	try {
		elClickedObj.form.submit();
	} catch(e) {}
}

function setDefaultFont() {
	var sDefaultFont = '궁서';
	var nFontSize = 24;
	oEditors.getById["ir1"].setDefaultFont(sDefaultFont, nFontSize);
}
</script>
	</table>
				</div>
			</div>