<div class="span9">
<H1>
<?php echo  $admin['board_title'];
	if($category) echo "($category)";
?>
</H1>
<table border="0" align="center" width="<?php echo $admin['width']?>">
	<tr>
		<td class="td" colspan="4" bgcolor="#F6F6F6">
			<h2>&nbsp;&nbsp;<?php echo $subject?></h2>
		<td align="right" bgcolor="#F6F6F6">
<?php if($file1){?>
			<a href="<?php echo base_url()?>board/file_down/id/<?php echo $this->id?>/file/<?php echo $file1?>">
			<img src='<?php echo base_url()?>skin/board/<?php echo $admin['board_skin']?>/images/button_file.gif' border='0' align='absmiddle'> 
<?php echo substr($file1,11,20)?></a> &nbsp;&nbsp;
<?php }?>
	<tr>
		<td colspan="5" align="center">
			<table class="td" border="0" align="center" width="<?php echo $admin['width']?>">
				<tr>
					<td> 
						<!--  회원 케릭터이미지 출력 -->
<?php if($this->session->userdata('file1')){?>
						<img src = <?php echo base_url()?>file/users/<?php echo $this->session->userdata('file1')?> width="15" height="15" border="0" >
<?php }else{?>
						<img src = "<?php echo base_url()?>skin/board/<?php echo $admin['board_skin']?>/images/character.gif" width="15" height="15" border="0" >
<?php }?>  
						글쓴이 :  <i class="icon-user"></i><?php echo $nick_name?> (<?php echo $ip?>)
					<td align=right>글쓴날자 : <?php echo $wdate?> | 조회수 : <?php echo $view?>
			</table>
			<table border=0 width=<?php echo $admin['width']?>>
				<tr>
					<td>&nbsp;
				<tr>
					<td>
						<img src='<?php echo base_url()?>file/board/<?php echo $this->id?>/<?php echo $file1?>' border='0' align='absmiddle'> 
						<li><?php echo $content?>
					</td>
				<tr>
					<td class="td">&nbsp;
				</tr>
			</table>
	<tr>
		<td>
			<a href=<?php echo base_url()?>board/bad_count/id/<?php echo $this->id?>/page/<?php echo $this->page?>/num/<?php echo $this->num?>/ onclick="return confirm('신고 하시겠습니까?')"><i class="icon-thumbs-down"></i>신고(<?php echo $bad_count?>회)</a>
		<td  align="center">
<?php if($this->session->userdata('level') >= $admin['write_level']){?>
			<a href=<?php echo base_url()?>/board/write_form/id/<?php echo $this->id?>/page/<?php echo $this->page?>/num/<?php echo $this->num?>><img src='<?php echo base_url()?>skin/board/<?php echo $admin['board_skin']?>/images/button_write.gif' border='0' align='absmiddle'></a>   
<?php }?>
<?php if($this->session->userdata('level') >= $admin['reply_level']){?>
			<a href=<?php echo base_url()?>/board/reply_form/id/<?php echo $this->id?>/page/<?php echo $this->page?>/num/<?php echo $this->num?>><img src='<?php echo base_url()?>skin/board/<?php echo $admin['board_skin']?>/images/button_reply.gif' border='0' align='absmiddle'></a>
<?php }?>
<?php if($this->session->userdata('level') == 10 || $wr_user_id == $this->session->userdata('username')){?>
			<a href=<?php echo base_url()?>/board/edit_form/id/<?php echo $this->id?>/page/<?php echo $this->page?>/num/<?php echo $this->num?>/><img src='<?php echo base_url()?>skin/board/<?php echo $admin['board_skin']?>/images/button_modify.gif' border='0' align='absmiddle'></a> 
<?php }?>
 <?php if($this->session->userdata('level') == 10 || $wr_user_id == $this->session->userdata('username')){?>
			<a href=<?php echo base_url()?>/board/delete/id/<?php echo $this->id?>/page/<?php echo $this->page?>/num/<?php echo $this->num?>/ onclick="return confirm('삭제하시겠습니까?')"><img src='<?php echo base_url()?>skin/board/<?php echo $admin['board_skin']?>/images/button_delete.gif' border='0' align='absmiddle'></a> 
<?php }?>	
			<a href=<?php echo base_url()?>/board/index/id/<?php echo $this->id?>/page/<?php echo $this->page?>/><img src='<?php echo base_url()?>skin/board/<?php echo $admin['board_skin']?>/images/button_list.gif' border='0' align='absmiddle'></a>
		<td align="right" colspan="3">
			<a href=<?php echo base_url()?>board/good_count/id/<?php echo $this->id?>/page/<?php echo $this->page?>/num/<?php echo $this->num?>/ onclick="return confirm('추천 하시겠습니까?')"><i class="icon-thumbs-up"></i>추천(<?php echo $good_count?>회)</a>
	<tr>
		<td  align=center colspan=5>
			<br>
<?php //베너 출력
	$this->db->order_by('banner_sequence desc');//출력순서
	$this->db->where('banner_place', "board_middle");//베너위치
	$this->db->where('banner_use', 1);//사용여부
	$query = $this->db->get('banner');
	foreach ($query->result() as $row){?>
		<a href=<?php echo base_url()?>admin/banner/read/id/banner/no/<?php echo $row->banner_num?>/ target=<?php echo $row->banner_target?>>
		<img src=<?php echo base_url()?>file/banner/<?php echo $row->banner_image?> width=<?php echo $row->banner_width?> height=<?php echo $row->banner_height?>></a><br>
<?php }?>
	<br>
</table>
<!-- 짧은 댓글 출력 입력 시작 -->
<?php 
  $query=$this->db->query("select * from {$this->id}_comments  where parent=$this->num order by regdate asc ");
?>
<br>
<?php foreach ($query->result() as $row){ ?> 
	<table border=0 width=100% align=center bgcolor="#F6F6F6">
		<tr> 
			<td align=center valign=top width=10% rowspan="2" class="td">
				<!--  회원 케릭터이미지 출력 (결합도 줄이기 위해.. 답글필드에서 가져옮) -->
<?php if($row->co_file1){?>
				<img src = <?php echo base_url()?>file/users/<?php echo $row->co_file1?> width="50" height="50" border="0" >
<?php }else{?>
				<img src = <?php echo base_url()?>file/character.gif width="50" height="50" border="0" >
<?php }?>
			<td width=75% align=left>
<?php echo $row->co_nick_name?> 
<?php echo $row->co_user_id?> | 
<?php echo substr($row->regdate,5,11)?> | 
<?php if(isset($row->comment_bad_count)){?>
	신고<?php echo $row->comment_bad_count?>회 |
<?php }?>
<?php if(isset($row->comment_good_count)){?>
추천<?php echo $row->comment_good_count?>회
<?php }?>
<?php if($this->session->userdata('level') == 10 or $row->co_user_id == $this->session->userdata('username')){ ?>
			<td width=15% align=right>
				<a href="<?php echo base_url()?>board/comment_good_count/id/<?php echo $this->id?>/page/<?php echo $this->page?>/num/<?php echo $row->num?>/" onclick="return confirm('추천 하시겠습니까?')"><i class="icon-thumbs-up"></i>추천</a>
				<a href="<?php echo base_url()?>board/comment_bad_count/id/<?php echo $this->id?>/page/<?php echo $this->page?>/num/<?php echo $row->num?>/" onclick="return confirm('신고 하시겠습니까?')"><i class="icon-thumbs-down"></i>신고</a>
				<a href="<?php echo base_url()?>/board/comment_delete/id/<?php echo $this->id?>/page/<?php echo $this->page?>/num/<?php echo $row->num?>/" onclick="return confirm('삭제하시겠습니까?')"><i class="icon-trash icon-red"></i></a>&nbsp;&nbsp;
<?php } ?>
		<tr>
			<td colspan=2  class="td">
<?php echo nl2br($row->memo)?> 
	</table>
<?php } ?>
<!-- 댓글 권한에 따른 입력폼 버튼 출력 시작-->
<?php if($this->session->userdata('level') >= $admin['reply_level']){?>
<?php if($this->session->userdata('level')) { ?>  
	<table border=0 width=<?php echo $admin['width']?> align=center bgcolor="#F6F6F6">
	<?php echo form_open_multipart("/board/comment_write/id/$this->id/page/$this->page/num/$this->num");?> 
		<input type=hidden name=parent  value=<?php echo $this->num?>>
		<input type=hidden name=name  value=<?php echo $this->session->userdata('kname')?>>
		<input type=hidden name=co_user_id value=<?php echo $this->session->userdata('username')?>>
		<input type=hidden name=co_nick_name value=<?php echo $this->session->userdata('nickname')?>>
		<input type=hidden name=co_file1 value=<?php echo $this->session->userdata('file1')?>>
		<tr> 
			<td width=10%  valign=top align=center>
<!--  회원 케릭터이미지 출력 (재로그인 해야 변경 적용됨-결합도 최소화 위해서 세션 사용함) -->
<?php if($this->session->userdata('file1')){?>
				<img src = <?php echo base_url()?>file/users/<?php echo $this->session->userdata('file1')?> width="50" height="50" border="0" >
<?php }else{?>
				<img src = <?php echo base_url()?>file/character.gif width="50" height="50" border="0" >
<?php }?>
			<td width=80%>
<?php echo form_error('memo'); ?> 
				<textarea name="memo" style='width: 100%; height: 70px;' onkeyup='this.style.height = this.scrollHeight'><?php echo set_value('memo'); ?></textarea>
			<td width=10%> 
				<button type="submit" style="width:81px;height:54px;border:0px"><img src="<?php echo base_url()?>skin/board/<?php echo $admin['board_skin']?>/images/button_comment_write.gif"></button>
<?php }?>
<!-- 댓글 권한에 따른 입력폼 버튼 출력 끝 -->
		</tr> 
	</form> 
	</table>
<?php } ?>
<!-- 아랫글 윗글 링크 (답글 무시하고 원글만 링크됨-오류라고 봐야하나????) -->
<table>
	<tr>
		<td>
<?php
	$num = $this->num;
	$this->db->where('num >', $num);
	$this->db->limit(1);
	$query = $this->db->get($this->id);
	$row = $query->row_array();

	if (isset($row['num'])){?>	
	<a href=<?php echo base_url()?>board/read/id/<?php echo $this->id?>/page/<?php echo $this->page?>/num/<?php echo $row['num']?>>▲윗&nbsp;&nbsp;&nbsp;글 | <?php echo $row['subject']?></a>
<?php $int_time = strtotime($row['wdate']);
	if(time()-$int_time<86400) {?>
	&nbsp;<img src="<?php echo base_url()?>skin/board/<?php echo $admin['board_skin']?>/images/icon_new.gif" title="24시간내 작성된 글입니다.">
<?php }
}
else
{
echo"[윗글]";
 }
?> 
<br>

<?php
	$num2 = $this->num;
	$this->db->where('num <', $num2);
	$this->db->order_by('num desc');
	$this->db->limit(1);
	$query = $this->db->get($this->id);
	$row2 = $query->row_array();

	if (isset($row2['num'])){?>
	<a href=<?php echo base_url()?>board/read/id/<?php echo $this->id?>/page/<?php echo $this->page?>/num/<?php echo $row2['num']?>>▼아랫글 | <?php echo $row2['subject']?></a>
<?php $int_time = strtotime($row2['wdate']);
	if(time()-$int_time<86400){?>
	&nbsp;<img src="<?php echo base_url()?>skin/board/<?php echo $admin['board_skin']?>/images/icon_new.gif" title="24시간내 작성된 글입니다.">
<?php }
}
else
{
echo" [아랫글]";
}
?>
</table>
<br><br>
				</div>
			</div>