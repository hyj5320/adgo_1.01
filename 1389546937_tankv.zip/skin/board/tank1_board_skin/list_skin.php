<!--  게시판 상단 html(게시판설정)-->
<?php echo $admin['head']?>

				<div class="span9">
<SCRIPT LANGUAGE=JAVASCRIPT>  
	function search_confirm()
	{
		if(document.search_form.keyword.value == '')
		{
			alert('검색어를 입력하세요.');
			document.search_form.keyword.focus();
			return;
		}
		document.search_form.submit();
	 }
</SCRIPT>

<H1><?php echo $admin['board_title']?></H1>
<table border=0 align="center" cellpadding="0" cellspacing="0" width="<?php echo $admin['width']?>">
	<tr>
		<td width="40%">
<?php
	$key = "";
	$keyword = "";
?>
			<form name="search_form" method="post" action="<?php echo $act_url?>">
			<select class="span4" name="key" size="1">
				<option value="subject" <?php if($key == "subject") 
				echo "selected"; ?>>제목</option>
				<option value="content" <?php if($key == "content") 
				echo "selected"; ?>>내용</option>
				<option value="nick_name" <?php if($key == "nick_name") 
				echo "selected"; ?>>닉네임</option>
			</select>
				<input class="input-small" placeholder=".input-small" type="text" name="keyword" size="9" value="<?php echo $keyword?>">
				<b><INPUT class="btn" type=button value="검색" name=formbutton1 onclick="search_confirm();"></b>
	</form>
		<td width="20%">
<?php if($admin['use_board_category'] == 1){?>
<?php 
	$board_category = explode ("|", $admin['board_category']);
?>
<form name="fboardform" method="post" action="<?php echo base_url()?>board/index/id/<?php echo $this->id?>/page/1">
	<select class="span8" name="category" onchange="document.forms['fboardform'].submit();"> 
		<option value="">카테고리</option>
		<option value=''>-------------</option>
<?php foreach($board_category as $row){ ?>
		<option value="<?php echo $row?>"><?php echo $row?></option>
<?php }?>
	</select>
	<script type="text/javascript">document.fboardform.category.value="<?php echo $category?>";</script>
</form>
<?php }?> 
		<td width="40%">
			<p align="right"> 총 게시물:<?php echo $total_record?>개(<?php echo $page?>페이지/총<?php echo $total_page?>페이지)
			
<?php //게시판 관리
	if($this->session->userdata('level') == 10){?>
		<a class="btn btn-mini" href="<?php echo base_url()?>admin/board/edit_form/id/board_admin/no/<?php echo $admin['no']?>"><i class="icon-cog"></i>게시판설정</a>
<?php }?>

			</p>
		</td>
	</tr>
</table>

<table class="table table-hover" border=0 width=<?php echo $admin['width']?>>
	<tr>
	<tr bgcolor="#F6F6F6">
		<td align=center>번호</font>
		<td align=center>제목</font>
		<td align=center>닉네임</font>
		<td align=center>날짜</font>
		<td align=center>조회수</font>
	<tr>
<?php foreach($result as $row){ ?>
	<tr align=center>
		<td>
		<!-- 공지사항 아이콘 출력 -->
<?php
	if($row->gnum == 2000000000){?>
	<img src = "<?php echo base_url()?>images/notice.gif">
<?php
}
else
{
echo $row->num;
};
?>
		<td align=left>
<?php echo str_repeat("&nbsp;&nbsp;", strlen($row->depth))?>
			<a href=<?php echo base_url()?>board/read/id/<?php echo $this->id?>/page/<?php echo $this->page?>/num/<?php echo $row->num?>><?php echo $row->subject?></a>
<!--  짧은탯글 카운터($query 에 comments 추가할것) -->
<?php if($row->comments){ ?>[<?php echo $row->comments?>]<?php } ?> 
<!-- 게시판 관리자 설정 시간내 작성글 new 아이콘 출력 -->
<?php
	$int_time = strtotime($row->wdate);
	if(time()-$int_time<($admin['newicon_time_limit']*60*60)) {?>
	&nbsp;<img src="<?php echo base_url()?>images/icon_new.gif" title="<?php echo $admin['newicon_time_limit']?>시간내 작성된 글입니다.">
<?php }?>

<td>
<?php //쪽지보내기
if($row->nick_name) 
{
								$atts = array(
									'width'      => '630',
									'height'     => '520',
									'scrollbars' => 'no',
									'status'     => 'yes',
									'resizable'  => 'yes',
									'screenx'    => '0',
									'screeny'    => '0'
								);
								echo anchor_popup("./memo/send_form/id/memo/user_id/$row->wr_user_id", "$row->nick_name", $atts);
}
?>
		<td><?php echo substr($row->wdate,5,11)?>
		<td><?php echo $row->view?>
		<tr>
<?php } ?>
	<tr>
</table>

<!--  <div id=pagination>-->
<div class="pagination pagination-centered">
<ul>
<?php echo $pagenum?>
</ul>
</div>

<div align="center">
<?php if($this->session->userdata('level') >= $admin['write_level']){?>
			<a href="<?php echo base_url()?>/board/write_form/id/<?php echo $this->id?>/num/<?php echo $this->num?>" class="btn btn-small btn-info"><i class="icon-pencil icon-white"></i>글쓰기</a>
<?php }?>
</div>

<!--  게시판 하단 html(게시판설정)-->
<?php echo $admin['foot']?>

			</div>
	</div>