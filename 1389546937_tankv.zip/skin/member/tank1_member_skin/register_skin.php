<?php if (!defined('BASEPATH')) exit('No direct script access allowed');?>
				<div class="span9">
<form name="fregister" method="POST" onsubmit="return fregister_submit(this);" autocomplete="off">
<br>
<h1>회원가입 약관동의</h1>
	
	<table width="100%" cellpadding="4" cellspacing="0" bgcolor=#EEEEEE>
		<tr> 
			<td height=40>&nbsp; <b>회원가입약관</b></td>
		</tr>
		<tr> 
			<td align="center" valign="top"><textarea style="width: 98%" rows=10 readonly><?php echo $users_register1?></textarea></td>
		</tr>
		<tr> 
			<td height=40>
				<div class="controls">
					<label class="radio">
					<input type="radio" name="agree" id="agree11" value="1" checked>동의합니다.</label>
					<label class="radio">
					<input type="radio" name="agree" id="agree11" value="0" >동의하지 않습니다.</label>
				</div>
			</td>
		</tr>
	</table>

	<br>
	<table width="100%" cellpadding="4" cellspacing="0" bgcolor=#EEEEEE>
		<tr> 
			<td height=40>&nbsp; <b>개인정보취급방침</b></td>
		</tr>
		<tr> 
			<td align="center" valign="top"><textarea style="width: 98%" rows=10 readonly><?php echo $users_register2?></textarea></td></textarea></td>
		</tr>
		<tr> 
			<td height=40>
				<div class="controls">
					<label class="radio">
					<input type="radio" name="agree2" id="agree21" value="1" checked>동의합니다.</label>
					<label class="radio">
					<input type="radio" name="agree2" id="agree21" value="0" >동의하지 않습니다.</label>
				</div>
			</td>
		</tr>
	</table>
</td></tr></table>
<br>
<div align=center>
			<button class="btn btn-small btn-info" type="submit" class="btn btn-info">확인</button>
			<input class="btn btn-small" type="button" onclick="history.back(1)" value="이전" />
</div>
</form>

<script type="text/javascript">
function fregister_submit(f) 
{
	var agree1 = document.getElementsByName("agree");
	 if (!agree1[0].checked) 
	{
		alert("회원가입약관의 내용에 동의하셔야 회원가입 하실 수 있습니다.");
		agree1[0].focus();
		return false;
	}

	var agree2 = document.getElementsByName("agree2");
	if (!agree2[0].checked) 
	{
		alert("개인정보취급방침의 내용에 동의하셔야 회원가입 하실 수 있습니다.");
		agree2[0].focus();
		return false;
	}

	f.action = "<?php echo base_url()?>auth/register/";
	return true;
}

if (typeof(document.fregister.username) != "undefined")
	document.fregister.username.focus();
</script>
<br><br>
	</div>
</div>