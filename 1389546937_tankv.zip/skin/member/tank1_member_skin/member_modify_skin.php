<?php if (!defined('BASEPATH')) exit('No direct script access allowed');?>
				<div class="span9">
<?php
$username = array(
	'name'	=> 'username',
	'id'	=> 'username',
	'value' => set_value('username'),
	'maxlength'	=> $this->config->item('username_max_length', 'tank_auth'),
	'size'	=> 30,
);
$nickname = array(
	'name'	=> 'nickname',
	'id'	=> 'nickname',
	'value' => set_value('nickname', $views['nickname']),
	'maxlength'	=> '10',
	'size'	=> 30,
);
$email = array(
	'name'	=> 'email',
	'id'	=> 'email',
	'value'	=> set_value('email', $views['email']),
	'maxlength'	=> 80,
	'size'	=> 30,
);
$password = array(
	'name'	=> 'password',
	'id'	=> 'password',
	'value' => set_value('password'),
	'maxlength'	=> $this->config->item('password_max_length', 'tank_auth'),
	'size'	=> 30,
);
$confirm_password = array(
	'name'	=> 'confirm_password',
	'id'	=> 'confirm_password',
	'value' => set_value('confirm_password'),
	'maxlength'	=> $this->config->item('password_max_length', 'tank_auth'),
	'size'	=> 30,
);
$kname = array(
	'name'	=> 'kname',
	'id'	=> 'kname',
	'value' => set_value('kname', $views['kname']),
	'maxlength'	=> '10',
	'size'	=> 30,
);
$mobile = array(
	'name'	=> 'mobile',
	'id'	=> 'mobile',
	'value'	=> set_value('mobile', $views['mobile']),
	'maxlength'	=> 13,
	'size'	=> 30,
);
$telephone = array(
	'name'	=> 'telephone',
	'id'	=> 'telephone',
	'value' => set_value('telephone', $views['telephone']),
	'maxlength'	=> '10',
	'size'	=> 30,
);
$zipcode1 = array(
	'name'	=> 'zipcode1',
	'id'	=> 'zipcode1',
	'value' => set_value('zipcode1', $views['zipcode1']),
	'maxlength'	=> '6',
	'size'	=> 10,
	'readonly' => 'readonly',
);
$zipcode2 = array(
	'name'	=> 'zipcode2',
	'id'	=> 'zipcode2',
	'value' => set_value('zipcode2', $views['zipcode2']),
	'maxlength'	=> '6',
	'size'	=> 10,
	'readonly' => 'readonly',
);
$address1 = array(
	'name'	=> 'address1',
	'id'	=> 'address1',
	'value' => set_value('address1', $views['address1']),
	'maxlength'	=> '50',
	'size'	=> 30,
	'readonly' => 'readonly',
);
$address2 = array(
	'name'	=> 'address2',
	'id'	=> 'address2',
	'value' => set_value('address2', $views['address2']),
	'maxlength'	=> '50',
	'size'	=> 30,
);
$homepage = array(
	'name'	=> 'homepage',
	'id'	=> 'homepage',
	'value' => set_value('homepage', $views['homepage']),
	'maxlength'	=> '30',
	'size'	=> 30,
);
$birthday = array(
	'name'	=> 'birthday',
	'id'	=> 'datepicker',//달력출력
	'value' => set_value('birthday', $views['birthday']),
	'maxlength'	=> '10',
	'size'	=> 30,
);
$sex = array(
	'name' => 'sex',
	'id'	=> 'sex',
	'value' => set_value('sex', $views['sex']),
	'maxlength'	=> '10',
	'size'	=> 30,
);
$job = array(
	'name' => 'job',
	'id'	=> 'job',
	'value' => set_value('job', $views['job']),
	'maxlength'	=> '15',
	'size'	=> 30,
);
$file1 = array(
	'name'	=> 'file1',
	'id'	=> 'file1',
	'value' => set_value('file1', $views['file1']),
	'maxlength'	=> '30',
	'size'	=> 30,
);
$captcha = array(
	'name'	=> 'captcha',
	'id'	=> 'captcha',
	'maxlength'	=> 8,
);
?>
<script>
  function search_zipcode(){
     window.open("<?php echo base_url()?>auth/search_zip","우편번호검색"," width=420, height=500"); 
  }
</script>

<!--jquery Datepicker  -->
<script>
$.datepicker.regional['ko']= {
closeText:'닫기',
prevText:'이전달',
nextText:'다음달',
currentText:'오늘',
monthNames:['1월(JAN)','2월(FEB)','3월(MAR)','4월(APR)','5월(MAY)','6월(JUM)','7월(JUL)','8월(AUG)','9월(SEP)','10월(OCT)','11월(NOV)','12월(DEC)'],
monthNamesShort:['1월','2월','3월','4월','5월','6월','7월','8월','9월','10월','11월','12월'],
dayNames:['일','월','화','수','목','금','토'],
dayNamesShort:['일','월','화','수','목','금','토'],
dayNamesMin:['일','월','화','수','목','금','토'],
weekHeader:'Wk',

dateFormat:'yy-mm-dd',
showAnim: "slideDown",
changeMonth: true,
changeYear: true,
yearRange: "-60:-10",
showOn: "both",
buttonImage: "<?php echo base_url()?>images/calendar.gif", 
buttonImageOnly: true,

firstDay:0,
isRTL:false,
showMonthAfterYear:true,
yearSuffix:''
};

$(function() 
{
	$.datepicker.setDefaults( $.datepicker.regional[ "" ] ); 
	$( "#datepicker" ).datepicker( $.datepicker.regional[ "ko" ] ); 
});
</script>
<?php 
	$attributes = array('name' => 'tx_editor_form', 'id' => 'tx_editor_form');
	echo form_open_multipart($this->uri->uri_string(), $attributes); 
?>
<br>
<h1>회원정보 수정</h1>

<table align="center">
	<tr>
		<td><?php echo form_label('아이디', $username['id']); ?></td>
		<td><?php echo $views['username']?></td>
		<td style="color: red;"><?php echo form_error($username['name']); ?><?php echo isset($errors[$username['name']])?$errors[$username['name']]:''; ?></td>
	</tr>
	<tr>
		<td><?php echo form_label('닉네임', $nickname['id']); ?></td>
		<td><?php echo $views['nickname']?></td>
		<td style="color: red;"><?php echo form_error($nickname['name']); ?><?php echo isset($errors[$nickname['name']])?$errors[$nickname['name']]:''; ?></td>
	</tr>
	<tr>
		<td><?php echo form_label('이메일', $email['id']); ?></td>
		<td><?php echo form_input($email); ?><br>
		<input type="checkbox" name="re_email" value="1" checked="checked" />뉴스레터, 공지메일을 수신
		<td style="color: red;"><?php echo form_error($email['name']); ?><?php echo isset($errors[$email['name']])?$errors[$email['name']]:''; ?></td>
	</tr>
	<tr>
		<td><?php echo form_label('비밀번호', $password['id']); ?></td>
		<td><?php echo form_password($password); ?></td>
		<td style="color: red;"><?php echo form_error($password['name']); ?></td>
	</tr>
	<tr>
		<td><?php echo form_label('비밀번호 재입력', $confirm_password['id']); ?></td>
		<td><?php echo form_password($confirm_password); ?></td>
		<td style="color: red;"><?php echo form_error($confirm_password['name']); ?></td>
	</tr>
<!-- 1=사용, 2=필수사용 -->
<?php if($use['kname'] ==1 || $use['kname'] ==2){?>
	<tr>
		<td><?php echo form_label('이름', $kname['id']); ?></td>
		<td><?php echo form_input($kname); ?></td>
		<td style="color: red;"><?php echo form_error($kname['name']); ?><?php echo isset($errors[$kname['name']])?$errors[$kname['name']]:''; ?></td>
	</tr>
<?php }?>
<?php if($use['mobile'] ==1 || $use['mobile'] ==2){?>	
	<tr>
		<td><?php echo form_label('핸드폰', $mobile['id']); ?></td>
		<td><?php echo form_input($mobile); ?><br>
		<input type="checkbox" name="re_mobile" value="1" checked="checked" />알림문자 수신
		<td style="color: red;"><?php echo form_error($mobile['name']); ?><?php echo isset($errors[$mobile['name']])?$errors[$mobile['name']]:''; ?></td>
	</tr>
<?php }?>
<?php if($use['telephone'] ==1 || $use['telephone'] ==2){?>	
	<tr>
		<td><?php echo form_label('전화', $telephone['id']); ?></td>
		<td><?php echo form_input($telephone); ?></td>
		<td style="color: red;"><?php echo form_error($telephone['name']); ?><?php echo isset($errors[$telephone['name']])?$errors[$telephone['name']]:''; ?></td>
	</tr>
<?php }?>
<?php if($use['zip_address'] ==1 || $use['zip_address'] ==2){?>	
	<tr> 
		<td>우편번호
		<td> 
			<input name="zipcode1" value="<?php echo $views['zipcode1']?>" class="input-small" type="text" placeholder=".input-small" readonly> -
			<input name="zipcode2" value="<?php echo $views['zipcode2']?>" class="input-small" type="text" placeholder=".input-small" readonly>
		<td>
			&nbsp;<button onclick="search_zipcode();" type="button" class="btn">우편번호검색</button>
	<tr>
		<td><?php echo form_label('주소1', $address1['id']); ?></td>
		<td> <?php echo form_input($address1); ?>
		<td style="color: red;"><?php echo form_error($address1['name']); ?><?php echo isset($errors[$address1['name']])?$errors[$address1['name']]:''; ?></td>
	<tr>
		<td><?php echo form_label('주소2', $address2['id']); ?></td>
		<td><?php echo form_input($address2); ?></td>
		<td style="color: red;"><?php echo form_error($address2['name']); ?><?php echo isset($errors[$address2['name']])?$errors[$address2['name']]:''; ?></td>
	</tr>
<?php }?>
<?php if($use['homepage'] ==1 || $use['homepage'] ==2){?>	
	<tr>
		<td><?php echo form_label('홈페이지', $homepage['id']); ?></td>
		<td><?php echo form_input($homepage); ?></td>
		<td style="color: red;"><?php echo form_error($homepage['name']); ?><?php echo isset($errors[$homepage['name']])?$errors[$homepage['name']]:''; ?></td>
	</tr>
<?php }?>
<?php if($use['birthday'] ==1 || $use['birthday'] ==2){?>	
	<tr>
		<td><?php echo form_label('생일', $birthday['id']); ?></td>
		<td><?php echo form_input($birthday); ?></td>
		<td style="color: red;"><?php echo form_error($birthday['name']); ?><?php echo isset($errors[$birthday['name']])?$errors[$birthday['name']]:''; ?></td>
	</tr>
<?php }?>
<?php if($use['sex'] ==1 || $use['sex'] ==2){?>	
	<tr>
		<td><?php echo form_label('성별', $sex['id']); ?></td>
		<td>
			<select name="sex" > 
				<option value="">성별 선택</option>
				<option value="">----------</option>
				<option value="남성" <?php echo set_select('sex', '남성'); ?> >남성</option> 
				<option value="여성" <?php echo set_select('sex', '여성'); ?> >여성</option>  
			</select> 
		<td style="color: red;"><?php echo form_error($sex['name']); ?><?php echo isset($errors[$sex['name']])?$errors[$sex['name']]:''; ?></td>
			<script type="text/javascript">document.tx_editor_form.sex.value="<?php echo $views['sex']?>";</script>
	</tr>
<?php }?>
<?php if($use['job'] ==1 || $use['job'] ==2){?>	
	<tr>
		<td><?php echo form_label('직업', $job['id']); ?></td>
		<td>
			<select name="job">
				<option value="">직업 선택</option>
				<option value="">------------------</option>
				<option value="주부" <?php echo set_select('job', '주부'); ?>>ㆍ주부</option>
				<option value="중/고생" <?php echo set_select('job', '중/고생'); ?>>ㆍ중/고생</option>
				<option value="대학생" <?php echo set_select('job', '대학생'); ?>>ㆍ대학생</option>
				<option value="대학원생" <?php echo set_select('job', '대학원생'); ?>>ㆍ대학원생</option>
				<option value="회사원" <?php echo set_select('job', '회사원'); ?>>ㆍ회사원</option>
				<option value="공무원" <?php echo set_select('job', '공무원'); ?>>ㆍ공무원</option>
				<option value="자영업" <?php echo set_select('job', '자영업'); ?>>ㆍ자영업</option>
				<option value="교직자" <?php echo set_select('job', '교직자'); ?>>ㆍ교직자</option>
				<option value="의료인" <?php echo set_select('job', '의료인'); ?>>ㆍ의료인</option>
				<option value="법조인" <?php echo set_select('job', '법조인'); ?>>ㆍ법조인</option>
				<option value="금융/증권" <?php echo set_select('job', '금융/증권'); ?>>ㆍ금융/증권</option>
				<option value="보험업" <?php echo set_select('job', '보험업'); ?>>ㆍ보험업</option>
				<option value="언론/방송" <?php echo set_select('job', '언론/방송'); ?>>ㆍ언론/방송</option>
				<option value="종교" <?php echo set_select('job', '종교'); ?>>ㆍ종교</option>
				<option value="농/축산" <?php echo set_select('job', '농/축산'); ?>>ㆍ농/축산</option>
				<option value="수산/광업" <?php echo set_select('job', '수산/광업'); ?>>ㆍ수산/광업</option>
				<option value="서비스업" <?php echo set_select('job', '서비스업'); ?>>ㆍ서비스업</option>
				<option value="군인" <?php echo set_select('job', '군인'); ?>>ㆍ군인</option>
				<option value="건설업" <?php echo set_select('job', '건설업'); ?>>ㆍ건설업</option>
				<option value="제조업" <?php echo set_select('job', '제조업'); ?>>ㆍ제조업</option>
				<option value="유통업" <?php echo set_select('job', '유통업'); ?>>ㆍ유통업</option>
				<option value="부동산업" <?php echo set_select('job', '부동산업'); ?>>ㆍ부동산업</option>
				<option value="인터넷" <?php echo set_select('job', '인터넷'); ?>>ㆍ인터넷</option>
				<option value="경영컨설팅" <?php echo set_select('job', '경영컨설팅'); ?>>ㆍ경영컨설팅</option>
				<option value="문화/예술" <?php echo set_select('job', '문화/예술'); ?>>ㆍ문화/예술</option>
				<option value="스포츠/레져" <?php echo set_select('job', '스포츠/레져'); ?>>ㆍ스포츠/레져</option>
				<option value="정보통신업" <?php echo set_select('job', '정보통신업'); ?>>ㆍ정보통신업</option>
				<option value="프리랜서" <?php echo set_select('job', '프리랜서'); ?>>ㆍ프리랜서</option>
				<option value="무직" <?php echo set_select('job', '무직'); ?>>ㆍ무직</option>
				<option value="기타" <?php echo set_select('job', '기타'); ?>>ㆍ기타</option>
				</select>
		<td style="color: red;"><?php echo form_error($job['name']); ?><?php echo isset($errors[$job['name']])?$errors[$job['name']]:''; ?></td>
			<script type="text/javascript">document.tx_editor_form.job.value="<?php echo $views['job']?>";</script>
	</tr>
<?php }?>
	<tr>
		<td>회원케릭터</td>
		<td>
<?php if($this->session->userdata('file1')){?>
			<img src = <?php echo base_url()?>file/users/<?php echo $views['file1']?> width="50" height="50" border="0" >
<?php }?><br>	
			이미지 / 가로(50픽셀) x 세로(50픽셀) <br>
			용량 10,000 바이트 이하만 등록됩니다.<br>
			<input type="hidden" name="MAX_FILE_SIZE" value="1000000">
			<input class="btn btn-small" type=file name=assa>
		</td>
		<td style="color: red;"></td>
	</tr>
</table>
<br>
		<div align="center">
			<button class="btn btn-small btn-info" type="submit" class="btn btn-info">회원정보 수정</button>
			<input class="btn btn-small" type="button" onclick="history.back(1)" value="이전" />
			<?php echo form_close(); ?>
		</div>
	</div>
</div>