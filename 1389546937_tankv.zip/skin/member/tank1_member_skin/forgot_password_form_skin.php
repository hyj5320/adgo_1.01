<?php if (!defined('BASEPATH')) exit('No direct script access allowed');?>
				<div class="span9">
<?php
$login = array(
	'name'	=> 'login',
	'id'	=> 'login',
	'value' => set_value('login'),
	'maxlength'	=> 80,
	'size'	=> 30,
);
if ($this->config->item('use_username', 'tank_auth')) {
	$login_label = '아이디 또는 이메일';
} else {
	$login_label = 'Email';
}
?>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<?php echo form_open($this->uri->uri_string()); ?>
<br>
<h1>회원 로그인</h1>
<table align="center">
	<tr>
		<td><?php echo form_label($login_label, $login['id']); ?></td>
		<td><?php echo form_input($login); ?></td>
		<td style="color: red;"><?php echo form_error($login['name']); ?><?php echo isset($errors[$login['name']])?$errors[$login['name']]:''; ?></td>
	</tr>
</table>

<div align=center>
			<button name="reset" type="submit" class="btn btn-small btn-info">새 비밀번호 전송</button>
			<input class="btn btn-small" type="button" onclick="history.back(1)" value="이전" />
</div>

<?php echo form_close(); ?>
<br><br><br>
	</div>
</div>